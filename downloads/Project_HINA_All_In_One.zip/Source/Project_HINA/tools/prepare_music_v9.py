"""Licensed brass/action/jazz recordings for v0.9. Requires original MP3s in argument directory."""
from pathlib import Path
import subprocess,json,numpy as np,sys
P=Path(__file__).resolve().parents[1];root=Path(sys.argv[1] if len(sys.argv)>1 else '/tmp/hina-music-v9')
tracks={'coast':('Five Armies','USUAN1100875'),'night':('Hot Swing','USUAN1100202'),'reactor':('The Descent','USUAN1200094'),'boss':('Volatile Reaction','USUAN1400039'),'menu':('Heroic Age','USUAN1100848')}
credits=json.loads((P/'data/music_credits.json').read_text());report=json.loads((P/'planning/audio_assets.json').read_text())
for key,(title,isrc) in tracks.items():
 path=root/(title+('.ogg' if title in ['Volatile Reaction','The Descent'] else '.mp3'));assert path.stat().st_size>100000,path
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-f','f32le','-ar','44100','-ac','2','-'])
 a=np.frombuffer(raw,dtype='<f4').reshape(-1,2).copy();sr=44100
 cut={'coast':(32,145),'menu':(8,86),'reactor':(12,180)}.get(key)
 if cut:a=a[int(cut[0]*sr):int(cut[1]*sr)]
 nz=np.where(np.max(abs(a),axis=1)>.001)[0];a=a[max(0,nz[0]-2205):min(len(a),nz[-1]+2205)]
 fade=11025;theta=np.linspace(0,np.pi/2,fade)[:,None];a=np.concatenate([a[-fade:]*np.cos(theta)+a[:fade]*np.sin(theta),a[fade:-fade]])
 temp=root/(key+'.wav');subprocess.run(['ffmpeg','-v','error','-y','-f','f32le','-ar',str(sr),'-ac','2','-i','-','-c:a','pcm_s16le',str(temp)],input=a.astype('<f4').tobytes(),check=True)
 probe=subprocess.run(['ffmpeg','-hide_banner','-i',str(temp),'-af','loudnorm=I=-18:TP=-1.5:LRA=10:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
 d=json.loads(probe.stderr[probe.stderr.rfind('{'):]);af=f"loudnorm=I=-18:TP=-1.5:LRA=10:measured_I={d['input_i']}:measured_TP={d['input_tp']}:measured_LRA={d['input_lra']}:measured_thresh={d['input_thresh']}:offset={d['target_offset']}:linear=true"
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(temp),'-af',af,'-ar',str(sr),'-c:a','libvorbis','-q:a','7','-metadata',f'title={title}','-metadata','artist=Kevin MacLeod',str(P/'assets/sounds'/('bgm_'+key+'.ogg'))],check=True)
 credits[key]={'title':title,'author':'Kevin MacLeod','license':'CC BY 3.0' if key in ['coast','night'] else 'CC BY 4.0','seconds':len(a)/sr,'arrangement_version':9,'original_composition':False,'source_recording':True,'source_url':'https://incompetech.com/music/royalty-free/index.html?Search=Search&isrc='+isrc,'loudness_target_lufs':-18,'peak_ceiling_dbtp':-1.5,'loop_overlap_seconds':.25}
 report['bgm_'+key]=credits[key];print(key,title,round(len(a)/sr),flush=True)
(P/'data/music_credits.json').write_text(json.dumps(credits,indent=2));(P/'planning/audio_assets.json').write_text(json.dumps(report,indent=2))
lines=['# Music credits — v0.9','Seven music slots; five newly selected recordings. No Metal Slug recording or melody was copied.','']
for key,r in credits.items():lines += [f"## {key}: {r['title']}",f"\"{r['title']}\" Kevin MacLeod (incompetech.com)",'Licensed under '+r['license'],('https://creativecommons.org/licenses/by/3.0/' if r['license']=='CC BY 3.0' else 'https://creativecommons.org/licenses/by/4.0/'),r.get('source_url','https://incompetech.com/music/royalty-free/'),'Edits: action-section excerpt (coast 32–145s; menu 8–86s; reactor 12–180s), leading/trailing silence trimming, 250ms cyclic crossfade, loudness normalization to -18 LUFS.','']
lines += ['The clear fanfare remains an excerpt of “Flags” by Alexander Ehlers (CC0), sourced from https://opengameart.org/node/15828; excerpt, fades and volume normalization applied.','The soundtrack selection follows military brass/percussion, energetic arcade synth and jazz colors; it is not an exact stylistic reproduction or an original score composed for this game.']
lines += ['Download mirrors: Five Armies — https://stargazersworld.com/wp-content/uploads/2012/10/Five-Armies.mp3 ; Hot Swing — https://freemusicbg.com/hot-swing/ (music promoted by freemusicbg.com and chosic.com); The Descent — https://commons.wikimedia.org/wiki/File:The_Descent_by_Kevin_MacLeod.ogg ; Volatile Reaction — https://github.com/tapiwamakandigona/emberdelve/blob/main/assets/audio/music/combat_elite.ogg (previously silence-trimmed and normalized; further mastering here).']
(P/'LICENSES/MUSIC_v9.md').write_text('\n'.join(lines))
# Phone preview: menu / stage one / night / boss, twelve seconds each.
chunks=[]
for key in ['menu','coast','night','boss']:
 chunks.append(np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-ss','12','-i',str(P/'assets/sounds'/('bgm_'+key+'.ogg')),'-t','12','-af','afade=t=in:d=0.15,afade=t=out:st=11.5:d=0.5','-f','f32le','-ar','44100','-ac','2','-']),dtype='<f4'))
out=P.parent/'outputs';out.mkdir(exist_ok=True)
subprocess.run(['ffmpeg','-v','error','-y','-f','f32le','-ar','44100','-ac','2','-i','-','-codec:a','libmp3lame','-b:a','192k','-metadata','artist=Kevin MacLeod','-metadata','comment=CC BY 4.0; excerpts and mastering; see project LICENSES/MUSIC_v9.md',str(out/'BGM_Preview_v0.9.mp3')],input=np.concatenate(chunks).astype('<f4').tobytes(),check=True)

