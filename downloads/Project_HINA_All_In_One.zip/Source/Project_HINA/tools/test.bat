@echo off
setlocal
cd /d "%~dp0.."
set "HINA_GODOT=godot"
if not "%GODOT_BIN%"=="" set "HINA_GODOT=%GODOT_BIN%"
"%HINA_GODOT%" --headless --path . -s res://tests/integration.gd
exit /b %errorlevel%

