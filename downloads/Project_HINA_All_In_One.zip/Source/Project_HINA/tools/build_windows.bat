@echo off
setlocal
cd /d "%~dp0.."
if not exist builds mkdir builds
set "HINA_GODOT=godot"
if not "%GODOT_BIN%"=="" set "HINA_GODOT=%GODOT_BIN%"
"%HINA_GODOT%" --headless --path . --editor --import --quit
if errorlevel 1 exit /b 1
"%HINA_GODOT%" --headless --path . --export-release "Windows Desktop" builds/Project_HINA.exe
if errorlevel 1 exit /b 1
echo Built builds\Project_HINA.exe

