from pathlib import Path
import json
P=Path(__file__).resolve().parents[1]
f=P/'scripts/actors/enemy.gd';s=f.read_text()
s=s.replace('var death_direction := 1.0','var death_direction := 1.0\nvar visual_id := "helmet"\nvar is_tank := false\nvar body_size := Vector2(28,48)\nvar base_sprite_y := -40.0\nvar muzzle_height := -32.0')
s=s.replace('\thome = position.x','\tvisual_id=str(game.enemy_stats.types[kind].get("visual","helmet"))\n\tis_tank=visual_id in ["tank","railgun"]\n\tfaction="automata" if visual_id in ["military","shield","tank","railgun"] else "helmet"\n\tbody_size=Vector2(108,44) if is_tank else Vector2(28,48)\n\thome = position.x')
s=s.replace('shape.size = Vector2(24,43)','shape.size = body_size').replace('collision.position.y = -21.5','collision.position.y = -body_size.y/2')
s=s.replace('res://assets/enemies_v7/%s_%d.png"%[faction,i]','res://assets/enemies_v8/%s_%d.png"%[visual_id,i]').replace('res://assets/enemies_v7/%s_death_%d.png"%[faction,i]','res://assets/enemies_v8/%s_death_%d.png"%[visual_id,i]')
s=s.replace('\tsprite.position.y = -32\n\tif kind in [2,3,6]: sprite.scale=Vector2.ONE*1.12; sprite.position.y=-35.84','\tsprite.position.y = base_sprite_y\n\tsprite.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST')
s=s.replace('sprite.position.y=-32*sprite.scale.y','sprite.position.y=base_sprite_y').replace('velocity.x = sin(clock*.6)*25','velocity.x = sin(clock*.6)*(12 if is_tank else 25)').replace('if absf(distance.x)<300 and visible_player','if absf(distance.x)<(420 if is_tank else 320) and visible_player')
s=s.replace('facing*(100 if melee else 38)','facing*(100 if melee else (22 if is_tank else 38))').replace('(30 if melee else 190)','(30 if melee else (280 if is_tank else 190))').replace('(40 if melee else 280)','(40 if melee else (430 if is_tank else 300))').replace('.65 if kind in [2,6,7] else .4','1.0 if is_tank else (.75 if kind in [2,6,7] else .45)')
s=s.replace('1.5 if kind in [2,6] else 1.05','2.2 if is_tank else (1.5 if kind in [2,6] else 1.05)').replace('if absf(dx)<25:', 'if absf(dx)<(75 if is_tank or other.is_tank else 38):')
s=s.replace('\tgame.sound("enemy_shot")','\tgame.sound("enemy_shot")\n\tif is_tank:\n\t\tvar origin:=position+Vector2(facing*65,muzzle_height)\n\t\tvar aim:Vector2=(game.player.position+Vector2(0,-20)-origin).normalized()\n\t\tgame.fire(origin,aim*(240 if visual_id=="railgun" else 150),false,1)\n\t\tgame.particles(origin,Color("8ae4ff") if visual_id=="railgun" else Color("ffb267"),12,95)\n\t\tgame.sound("explosion");game.shake=2\n\t\treturn')
s=s.replace('position+Vector2(facing*20,-29)','position+Vector2(facing*30,muzzle_height)')
s=s.replace('velocity=Vector2(death_direction*80,-65)','velocity=Vector2.ZERO if is_tank else Vector2(death_direction*80,-65)\n\tif is_tank:game.explode(position+Vector2(0,-25),65,0,self)')
s=s.replace('if state == "ATTACK" and timer<.12:', 'if state=="ATTACK" and is_tank:\n\t\tdraw_line(Vector2(facing*60,muzzle_height),Vector2(facing*190,muzzle_height),Color(1,.3,.2,.4),1)\n\tif state == "ATTACK" and timer<.12:')
s=s.replace('Rect2(facing*23-2,-31,5,4)','Rect2(facing*(65 if is_tank else 31)-2,muzzle_height-2,5,4)')
s=s.replace('\tif kind == 3:\n\t\tdraw_line(Vector2(facing*16,-40),Vector2(facing*16,-8),Color("acb9c7"),5)','')
s+='\nfunc damage_rect() -> Rect2:\n\treturn Rect2(position+Vector2(-body_size.x/2,-body_size.y),body_size)\n'
f.write_text(s)
f=P/'data/enemy_stats.json';d=json.loads(f.read_text());visuals=['helmet','sukeban','sniper','shield','military','military','shield','military']
for t,v in zip(d['types'],visuals):t['visual']=v
d['types']+= [{'id':'kaiser_tank','hp':1,'visual':'tank'},{'id':'railgun_tank','hp':1,'visual':'railgun'}];f.write_text(json.dumps(d,indent=2))
f=P/'data/stages.json';d=json.loads(f.read_text());lineups=[[0,1,2,4,8],[1,2,4,8,0],[4,3,6,8,9],[1,2,0,3,9],[4,5,6,7,9]]
for stage,row in enumerate(d):
 pool=lineups[stage];row['opening']=[pool[0],pool[1],pool[2]]
 for i,w in enumerate(row['waves']):w['kinds']=[pool[(i+n)%len(pool)] for n in range(4)]
 row['props']=[]
 for i,x in enumerate(range(390,int(row['length'])-650,220)):
  style=[0,1,2,8][(i+stage)%4];width,height={0:(40,38),1:(32,48),2:(54,34),8:(48,50)}[style]
  # Keep props on open floor, not overlapping raised decks.
  for plat in row['platforms']:
   if x+width>plat[0] and x<plat[0]+plat[2]:x=plat[0]+plat[2]+35
  if x+width<row['length']-650:row['props'].append({'x':x,'style':style,'width':width,'height':height})
 row['decor']=[{'x':x,'style':[3,6,7,9,10,11][(i+stage)%6]} for i,x in enumerate(range(170,int(row['length'])-640,310))]
f.write_text(json.dumps(d,indent=2))
f=P/'scripts/game.gd';s=f.read_text().replace('var clear_timer := 0.0','const CLEAR_DURATION := 4.8\nvar clear_timer := 0.0\nvar prop_textures: Array=[]\nvar debris: Array=[]')
# Load new assets in existing setup before sound initialization.
s=s.replace('\tfor name in ["shot",','\tfor i in range(12):prop_textures.append(load("res://assets/props_v8/prop_%02d.png"%i))\n\tfor name in ["shot",')
s=s.replace('\tfor n in range(7):\n\t\tobjects.append({"rect":Rect2(550+n*270,282,26,28),"hp":3.0,"barrel":n%3==1,"dead":false})','\tdebris.clear()\n\tfor prop in stage_data[stage_index].props:\n\t\tobjects.append({"rect":Rect2(float(prop.x),310-float(prop.height),float(prop.width),float(prop.height)),"hp":3.0,"barrel":int(prop.style)==1,"style":int(prop.style),"dead":false})')
s=s.replace('STAGE %d / %s\\n선생님, 빨리 끝내죠.','STAGE %d / %s').replace('점수 %d / 최고 기록 %d\\n선생님, 곁에서 조금만 쉬게 해 주세요.','점수 %d / 최고 기록 %d')
s=s.replace('n*48,stage_length-640','n*90,stage_length-640')
s=s.replace('\t\tclear_timer-=delta','\t\tclear_timer-=delta\n\t\tupdate_particles(delta);queue_redraw()')
s=s.replace('Geometry2D.segment_intersects_circle(bullet.pos,segment_end,enemy.position+Vector2(0,-24),22)','segment_rect_time(bullet.pos,segment_end,enemy.damage_rect())')
s=s.replace('clear_timer=3.0; special_fx=0','clear_timer=CLEAR_DURATION; special_fx=0').replace('player.invulnerable=4.0','player.invulnerable=CLEAR_DURATION+.5')
s=s.replace('sound("clear"); message("스테이지 클리어\\n선생님, 이제 곧 쉴 수 있겠네요.",3)','bgm.stop();sound("clear");banner.text="";message_timer=0')
s=s.replace('/   v0.7','/   v0.8')
# Remove old flat platform art. Use detailed authored container/pier geometry instead.
a=s.index('\t\telse:\n\t\t\t# Grounded wreck platforms:');b=s.index('\tfor zone in danger:',a)
s=s[:a]+'''\t\telse:
			var style:=5 if stage_index==0 else (4 if stage_index in [2,4] else 7)
			draw_texture_rect(prop_textures[style],rect,false)
'''+s[b:]
a=s.index('\tfor object in objects:\n\t\tif object.dead: continue',s.index('func _draw'))
b=s.index('\tfor item in items:',a)
s=s[:a]+'''\tfor decor in stage_data[stage_index].decor:
		var style:=int(decor.style)
		var size:=Vector2(88,58) if style!=10 else Vector2(96,110)
		draw_texture_rect(prop_textures[style],Rect2(Vector2(float(decor.x),310)-Vector2(0,size.y),size),false,Color(.8,.82,.88,.85))
	for object in objects:
		if object.dead:
			draw_texture_rect(prop_textures[11],Rect2(object.rect.position.x,300,object.rect.size.x+12,10),false)
		else:draw_texture_rect(prop_textures[int(object.get("style",1 if object.barrel else 0))],object.rect,false)
	for piece in debris:
		draw_set_transform(piece.pos,piece.angle)
		draw_texture_rect_region(prop_textures[piece.style],Rect2(-piece.size/2,piece.size),piece.source)
		draw_set_transform(Vector2.ZERO)
'''+s[b:]
# Physics updates on breakable chunks; floor bounces and fades via lifetime.
s=s.replace('\tupdate_bullets(delta)','\tupdate_debris(delta)\n\tupdate_bullets(delta)')
s=s.replace('\tobject.dead=true\n\tvar origin:', '\tobject.dead=true\n\tvar style:=int(object.get("style",1 if object.barrel else 0))\n\tvar texture:Texture2D=prop_textures[style]\n\tfor n in range(6):\n\t\tdebris.append({"pos":object.rect.get_center(),"velocity":Vector2(randf_range(-100,100),randf_range(-160,-65)),"angle":0.0,"spin":randf_range(-5,5),"life":1.2,"size":Vector2(10,9),"style":style,"source":Rect2(n%3*texture.get_width()/3,n/3*texture.get_height()/2,texture.get_width()/3,texture.get_height()/2)})\n\tvar origin:')
s+='''
func update_debris(delta: float) -> void:
	for piece in debris.duplicate():
		piece.life-=delta
		if piece.life<=0:debris.erase(piece);continue
		piece.velocity.y+=450*delta;piece.pos+=piece.velocity*delta;piece.angle+=piece.spin*delta
		if piece.pos.y>306:piece.pos.y=306;piece.velocity.y*=-.25;piece.velocity.x*=.7

func segment_rect_time(a: Vector2,b: Vector2,rect: Rect2) -> float:
	if rect.has_point(a):return 0.0
	var low:=0.0
	var high:=1.0
	var direction:=b-a
	for axis in range(2):
		if absf(direction[axis])<.00001:
			if a[axis]<rect.position[axis] or a[axis]>rect.end[axis]:return -1.0
		else:
			var enter:float=(rect.position[axis]-a[axis])/direction[axis]
			var leave:float=(rect.end[axis]-a[axis])/direction[axis]
			low=maxf(low,minf(enter,leave));high=minf(high,maxf(enter,leave))
			if low>high:return -1.0
	return low
'''
f.write_text(s)
# Raid automata match new soldier height as well.
f=P/'scripts/actors/raid_target.gd';s=f.read_text().replace('assets/enemies_v7/automata_','assets/enemies_v8/military_').replace('sprite.position.y=-32','sprite.position.y=-40');f.write_text(s)

