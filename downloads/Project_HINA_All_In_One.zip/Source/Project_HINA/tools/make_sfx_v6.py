from pathlib import Path
import numpy as np,wave,json
p=Path(__file__).resolve().parents[1];sr=44100;rng=np.random.default_rng(617)
report=json.loads((p/'planning/audio_assets.json').read_text())
for name,d in [('kick_swing',.18),('kick_hit',.23),('enemy_down',.32),('robot_down',.45)]:
 t=np.arange(int(sr*d))/sr;n=rng.normal(0,1,len(t));smooth=np.convolve(n,np.ones(12)/12,'same')
 if name=='kick_swing':y=(n-np.roll(n,1))*.2*np.sin(np.pi*t/d)**2
 elif name=='kick_hit':y=np.sin(2*np.pi*(65*t+50*.02*(1-np.exp(-t/.02))))*.7*np.exp(-t*22)+smooth*.7*np.exp(-t*30)
 elif name=='enemy_down':y=smooth*.8*np.exp(-t*14)+np.sin(2*np.pi*88*t)*.3*np.exp(-t*20)
 else:y=n*.12*np.exp(-t*15)+(np.sin(2*np.pi*730*t)+np.sin(2*np.pi*1133*t))*.16*np.exp(-t*13)+np.sin(2*np.pi*(300*t-240*t*t))*.2*np.exp(-t*9)
 y*=np.minimum(1,t/.003)*np.minimum(1,(d-t)/.02);y=np.clip(y,-.85,.85)
 with wave.open(str(p/'assets/sounds'/f'{name}.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes((y*32767).astype('<i2').tobytes())
 report[name]={'seconds':d,'peak':float(abs(y).max()),'original_composition':True}
(p/'planning/audio_assets.json').write_text(json.dumps(report,indent=2))

