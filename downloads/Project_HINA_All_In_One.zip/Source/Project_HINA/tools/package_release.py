"""Package existing verified Windows export and reproducible source without editor caches."""
from pathlib import Path
from PIL import Image
import hashlib,json,struct,zipfile
p=Path(__file__).resolve().parents[1];dest=p.parent/'outputs/Project_HINA_v0.9.0.zip'
b=(p/'builds/Project_HINA.exe').read_bytes();pe=struct.unpack_from('<I',b,0x3c)[0];assert b[pe:pe+4]==b'PE\0\0' and struct.unpack_from('<H',b,pe+4)[0]==0x8664
size,magic=struct.unpack_from('<QI',b,len(b)-12);start=len(b)-12-size;assert magic==0x43504447 and b[start:start+4]==b'GDPC'
base=start+struct.unpack_from('<Q',b,start+24)[0];count=struct.unpack_from('<I',b,start+96)[0];cur=start+100;entries=[]
for i in range(count):
 n=struct.unpack_from('<I',b,cur)[0];cur+=4;name=b[cur:cur+n].rstrip(b'\0').decode();cur+=n;off,sz=struct.unpack_from('<QQ',b,cur);md=b[cur+16:cur+32];cur+=36
 assert hashlib.md5(b[base+off:base+off+sz]).digest()==md,name
 entries.append(name)
 if name.startswith('res://data/') and name.endswith('.json'):assert md==hashlib.md5((p/name.removeprefix('res://')).read_bytes()).digest(),name
(p/'planning/export_contents.json').write_text(json.dumps(entries,indent=2))
assert any('bgm_boss' in s for s in entries) and any('bgm_coast' in s for s in entries) and any('bgm_menu' in s for s in entries)
tests=json.loads((p/'planning/test_results.json').read_text());audio=json.loads((p/'planning/audio_test_results.json').read_text());assert tests['failures']==0 and audio['passed']
manifest=json.loads((p/'data/animation_manifest.json').read_text());frames=set(f['file'] for v in manifest.values() for f in v['frames'])
for fn in frames:
 im=Image.open(p/fn);bbox=im.getbbox();assert bbox and bbox[0]>0 and bbox[1]>0 and bbox[2]<im.width and bbox[3]<im.height,(fn,bbox)
raid=json.loads((p/'planning/raid_test_results.json').read_text());assert raid['failures']==0
v8=json.loads((p/'planning/v9_test_results.json').read_text());assert v8['failures']==0
verification={'version':'0.9.0','windows_arch':'x86_64','embedded_resources':count,'all_embedded_md5_valid':True,'functional_tests':len(tests['tests'])+len(raid['tests'])+len(v8['tests']),'raid_tests':len(raid['tests']),'failures':0,'audio_mixer_passed':True,'new_walk_frames':24,'prop_art_revision':9,'tank_hp':[18,26],'continue_seconds':10,'sprite_frames':len(frames),'sprite_edge_check':True,'windows_runtime_tested':False,'exe_sha256':hashlib.sha256(b).hexdigest()}
(p/'planning/build_verification.json').write_text(json.dumps(verification,indent=2))
keep={'v9_test_results.json','v9_test.log','Props_v9.png','map_expansion_v9.json','render_v9.log','menu_v9.png','continue_v9.png','clear_hold_v9.png','enemy_lineup_v9.png',*[f'stage_{i}_v9.png' for i in range(1,6)],*[f'boss_{i}_v9.png' for i in range(1,6)],'v8_test_results.json','v8_test.log','Enemy_SpriteSheet_v0.8.png','enemy_sprite_layout_v8.json','render_v8.log','menu_v8.png','credits_v8.png','clear_hold_v8.png','clear_enter_v8.png','enemy_lineup_v8.png',*[f'stage_{i}_v8.png' for i in range(1,6)],'render_final.log','render_v7.log','raid_test_results.json','raid_test.log','RAID_PATTERNS.md','chesed_open_review.png',*[f'raid_{i}_review.png' for i in range(1,6)],'render_v6.log','kick_review.png',*[f'stage_{i}_review.png' for i in range(1,6)],*[f'boss_{i}_review.png' for i in range(1,6)],*[f'enemy_fall_{i}.png' for i in range(4)],'test_results.json','integration_test.log','audio_test_results.json','audio_test.log','audio_assets.json','audio_mix_review.wav','windows_export.log','build_verification.json','export_contents.json','KNOWN_ISSUES.md','ASSET_NOTES.md','RESUME.md','STATUS.md','sprite_sheet_layout.json','Hina_SpriteSheet_v0.7.png','v4_sprite_review.png','gameplay_review.png','boss_review.png','special_review.png','air_down_review.png','air_shoot_review.png','aim_up_review.png','aim_diagonal_review.png','death_review.png','respawn_review.png','menu_review.png','render_v5.log','wing_flap_preview.gif','wing_phase_0.png','wing_phase_1.png','wing_phase_2.png','wing_phase_3.png'}
dest.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 z.write(p/'builds/Project_HINA.exe','Project_HINA.exe');z.write(p/'README.md','README.md');z.write(p/'planning/Hina_SpriteSheet_v0.7.png','Hina_SpriteSheet_v0.7.png')
 for f in sorted(p.rglob('*')):
  if not f.is_file():continue
  rel=f.relative_to(p)
  if any(x in rel.parts for x in ['.godot','builds','__pycache__']):continue
  if f.suffix in ['.import','.uid']:continue
  if rel.parts[0]=='planning' and f.name not in keep:continue
  if rel.parts[:2] in [('assets','player'),('assets','player_v3')]:continue
  if f.name in ['prepare_assets_legacy.py','prepare_assets.py','bgm_boss.wav']:continue
  z.write(f,'source/Project_HINA/'+str(rel))
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 assert hashlib.sha256(z.read('Project_HINA.exe')).hexdigest()==verification['exe_sha256']
 print(json.dumps({'file':str(dest),'size_bytes':dest.stat().st_size,'entries':len(z.namelist()),'verification':verification},indent=2))

