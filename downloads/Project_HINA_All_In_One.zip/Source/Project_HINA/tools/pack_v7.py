"""Reproducible nearest-neighbour atlas extraction. Explicit cells prevent bleed."""
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np
from scipy.ndimage import label
import json,shutil
P=Path(__file__).resolve().parents[1]
sources={'ground':'은발 히나 4×4 픽셀 스프라이트.png','air':'보라 박쥐 날개와 뿔 픽셀 아틀라스.png','kick':'수영복 히나의 기관총 킥 스프라이트 시트.png','enemy':'헬멧 소녀와 위장 자동인형 4×4 픽셀 아틀라스.png','boss':'투명 배경의 6종 보스 스프라이트.png'}
for folder in ['player_v7','enemies_v7','bosses_v7','atlases']:(P/'assets'/folder).mkdir(exist_ok=True)
for kind,name in sources.items():
 dst=P/'assets/atlases'/f'{kind}_source_v7.png'
 if not dst.exists():shutil.copy(P.parent/'recovered/images'/name,dst)
def clean(im):
 a=np.array(im.convert('RGBA'));a[:,:,3]=np.where(a[:,:,3]>=180,255,0);return Image.fromarray(a)
def isolated(im):
 a=np.array(im);lab,n=label(a[:,:,3]>0);sizes=np.bincount(lab.ravel());a[:,:,3][sizes[lab]<12]=0;return Image.fromarray(a)
frames={}
for kind in ['ground','air']:
 im=clean(Image.open(P/'assets/atlases'/f'{kind}_source_v7.png'))
 if kind=='ground':xs=[0,340,650,970,1254];ys=[0,320,620,940,1254];px=[158,477,791,1115];py=[303,607,912,1223]
 else:xs=[0,380,730,1070,1353];ys=[0,300,640,900,1163];px=[190,548,889,1230];py=[274,538,878,1145]
 arr=[]
 for i in range(16):
  r,c=divmod(i,4);box=[xs[c],ys[r],xs[c+1],ys[r+1]];pivot=[px[c],py[r]]
  if kind=='ground':
   muzzle=[xs[c+1]-5,[190,480,775,1097][r]]
   if i==9:muzzle=[652,755];pivot=[480,910]
   if i==10:muzzle=[963,838]
   if i==12:box[1]=908;muzzle=[112,912]
   if i==14:muzzle=[941,1168]
   if i==15:muzzle=[1249,1212]
  else:
   muzzle=[[359,708,1060,1351][c],[185,599,789,890][r]]
   if r==1:muzzle=[[193,545,887,1230][c],[611,617,617,620][c]]
   if r==3:
    if c<2:box[1]=873;muzzle=[[210,548][c],880]
    else:muzzle=[[1000,1316][c-2],922]
  scale=.23;crop=im.crop(box);crop=crop.resize((round(crop.width*scale),round(crop.height*scale)),Image.Resampling.NEAREST)
  out=Image.new('RGBA',(128,128));out.alpha_composite(crop,(round(64-(pivot[0]-box[0])*scale),round(100-(pivot[1]-box[1])*scale)));out=isolated(out)
  if kind=='ground' or (kind=='air' and r!=1):out.paste((0,0,0,0),(0,102,128,128))
  if kind=='ground' and i==12:out.paste((0,0,0,0),(90,0,128,128))
  path=f'assets/player_v7/{kind}_{i:02d}.png';out.save(P/path)
  arr.append({'file':path,'pivot':[64,100],'muzzle':[round((muzzle[0]-pivot[0])*scale,2),round((muzzle[1]-pivot[1])*scale,2)],'source_rect':box})
 for dest,src in ([(3,2),(7,6),(11,10)] if kind=='ground' else [(3,1),(11,9)]):
  shutil.copy(P/arr[src]['file'],P/arr[dest]['file']);arr[dest]={**arr[src],'file':arr[dest]['file'],'recovered_from':src}
 frames[kind]=arr
im=clean(Image.open(P/'assets/atlases/kick_source_v7.png'));frames['kick']=[]
for i in range(8):
 r,c=divmod(i,4);box=[round(c*im.width/4),round(r*im.height/2),round((c+1)*im.width/4),round((r+1)*im.height/2)]
 crop=im.crop(box);crop=crop.crop(crop.getbbox());crop=crop.resize((round(crop.width*.14),round(crop.height*.14)),Image.Resampling.NEAREST)
 out=Image.new('RGBA',(128,128));out.alpha_composite(crop,(64-crop.width//2,100-crop.height));out=isolated(out)
 path=f'assets/player_v7/kick_{i:02d}.png';out.save(P/path);frames['kick'].append({'file':path,'pivot':[64,100],'muzzle':[38,-23],'source_rect':box})
g,a,k=frames['ground'],frames['air'],frames['kick'];manifest={}
def anim(name,fs,fps=12,loop=True):manifest[name]={'fps':fps,'loop':loop,'frames':fs}
anim('idle',[g[8]],4)
for name in ['walk','walk_shoot']:anim(name,g[:8],14)
for name in ['jump','jump_rise','jump_apex','fall']:anim(name,a[:4])
anim('land',[g[10],g[8]],18,False);anim('shoot',[g[8],g[9]],16)
for name in ['crouch','crouch_shoot']:anim(name,[g[10]])
anim('shoot_up',a[12:14]);anim('shoot_diagonal',a[14:16]);anim('air_down',a[4:8]);anim('air_shoot',a[8:12])
anim('special',[g[12],g[12],g[13],g[13],g[8]],6,False)
anim('hurt',[g[14]],8,False);anim('down',[g[15]],8,False);anim('getup',[g[10],g[8]],8,False);anim('death',g[14:16],8,False)
anim('kick',[k[i] for i in [0,1,2,2,3,4,5]],16,False);anim('air_kick',[k[i] for i in [6,6,7,7,6,6,5]],16,False)
(P/'data/animation_manifest.json').write_text(json.dumps(manifest,indent=2))
im=clean(Image.open(P/'assets/atlases/enemy_source_v7.png'));xs=[0,315,625,930,1262];ys=[0,362,645,953,1246]
for r in range(4):
 for c in range(4):
  crop=im.crop((xs[c],ys[r],xs[c+1],ys[r+1]));crop=crop.crop(crop.getbbox());scale=.145 if r<2 else .16;crop=crop.resize((round(crop.width*scale),round(crop.height*scale)),Image.Resampling.NEAREST)
  out=Image.new('RGBA',(96,80));out.alpha_composite(crop,(48-crop.width//2,72-crop.height));name=('helmet' if r<2 else 'automata')+('_death' if r%2 else '')+f'_{c}.png';out.save(P/'assets/enemies_v7'/name)
im=clean(Image.open(P/'assets/atlases/boss_source_v7.png'))
boxes=[(0,0,515,523),(515,0,1013,527),(1013,0,1536,520),(0,523,529,1024),(529,527,1023,1024),(1023,527,1536,1024)]
for i,box in enumerate(boxes):
 crop=im.crop(box);crop=crop.crop(crop.getbbox());s=min(218/crop.width,202/crop.height);crop=crop.resize((round(crop.width*s),round(crop.height*s)),Image.Resampling.NEAREST);out=Image.new('RGBA',(240,220));out.alpha_composite(crop,(120-crop.width//2,212-crop.height));out.save(P/'assets/bosses_v7'/f'boss_{i}.png')
sheet=Image.new('RGBA',(1024,640),(36,36,52,255));d=ImageDraw.Draw(sheet)
for j,f in enumerate(g+a+k):
 x=j%8*128;y=j//8*128;sheet.alpha_composite(Image.open(P/f['file']),(x,y));d.text((x+4,y+4),Path(f['file']).stem,fill='white')
sheet.save(P/'planning/Hina_SpriteSheet_v0.7.png');(P/'planning/sprite_sheet_layout.json').write_text(json.dumps(frames,indent=2))
print('Packed 40 player, 16 enemy and 6 boss frames')

