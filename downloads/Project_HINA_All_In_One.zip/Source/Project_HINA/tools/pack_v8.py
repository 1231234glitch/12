"""Sprite extraction with explicit atlas bounds, shared actor scale and nearest sampling."""
from pathlib import Path
from PIL import Image,ImageOps,ImageDraw
import numpy as np,json,shutil
from scipy.ndimage import label
P=Path(__file__).resolve().parents[1]
source={'infantry':'exec-5fef4f6b-c803-474b-8ff2-fa23bac3d33d.png','variants':'exec-c69ad563-ee69-4c53-a23f-c570f12c8a50.png','tanks':'exec-8cc9ddcd-e1c9-4bf4-9ab1-863c46d27c7e.png','props':'exec-b28a7859-9d5b-4646-bb38-782a09c4fb25.png'}
for folder in ['enemies_v8','props_v8']:(P/'assets'/folder).mkdir(exist_ok=True)
for key,name in source.items():
 dest=P/'assets/atlases'/f'{key}_source_v8.png'
 if not dest.exists():shutil.copy(P.parent/'generated_images'/name,dest)
def clean(im):
 a=np.array(im.convert('RGBA'));a[:,:,3]=np.where(a[:,:,3]>210,255,0);lab,n=label(a[:,:,3]>0);counts=np.bincount(lab.ravel());a[:,:,3][counts[lab]<8]=0;return Image.fromarray(a)
manifest={}
def actor(name,crops):
 # One fixed scale per type; fallen poses retain the standing body's proportions.
 box=crops[0].getbbox();scale=60/(box[3]-box[1]);records=[]
 for i,crop in enumerate(crops):
  crop=crop.crop(crop.getbbox());crop=crop.resize((max(1,round(crop.width*scale)),max(1,round(crop.height*scale))),Image.Resampling.NEAREST)
  assert crop.width<188 and crop.height<90,(name,i,crop.size)
  out=Image.new('RGBA',(192,96));out.alpha_composite(crop,(96-crop.width//2,88-crop.height))
  fn=f'{name}_{i}.png' if i<4 else f'{name}_death_{i-4}.png';out.save(P/'assets/enemies_v8'/fn)
  records.append({'file':fn,'bbox':out.getbbox(),'scale':scale,'feet':[96,88]})
 manifest[name]=records
for key,names,ys in [('infantry',['sukeban','military'],[0,300,540,780,1024]),('variants',['sniper','shield'],[0,275,515,775,1024])]:
 im=clean(Image.open(P/'assets/atlases'/f'{key}_source_v8.png'))
 for j,name in enumerate(names):
  crops=[im.crop((c*384,ys[r],(c+1)*384,ys[r+1])) for r in [j*2,j*2+1] for c in range(4)]
  actor(name,crops)
# Existing helmet art, enlarged to the identical standing height.
actor('helmet',[clean(Image.open(P/'assets/enemies_v7'/('helmet_%d.png'%i if i<4 else 'helmet_death_%d.png'%(i-4)))) for i in range(8)])
im=clean(Image.open(P/'assets/atlases/tanks_source_v8.png'))
for r,name in enumerate(['tank','railgun']):
 crops=[im.crop((round(c*im.width/4),round(r*im.height/2),round((c+1)*im.width/4),round((r+1)*im.height/2))) for c in range(4)]
 # Idle, tread A, tread B, recoil; wreck held through destruction effect.
 actor(name,[crops[0],crops[1],crops[0],crops[2]]+[crops[3]]*4)
im=clean(Image.open(P/'assets/atlases/props_source_v8.png'))
# The original props atlas uses a regular 4x3 layout with wide gutters.
for r in range(3):
 for c in range(4):
  crop=im.crop((round(c*im.width/4),round(r*im.height/3),round((c+1)*im.width/4),round((r+1)*im.height/3)));crop=crop.crop(crop.getbbox())
  # Keep up to 192 native pixels: pixel clusters stay crisp at the 640x360 viewport.
  scale=min(1,192/max(crop.size));crop=crop.resize((round(crop.width*scale),round(crop.height*scale)),Image.Resampling.NEAREST)
  crop.save(P/'assets/props_v8'/f'prop_{r*4+c:02d}.png')
(P/'planning/enemy_sprite_layout_v8.json').write_text(json.dumps(manifest,indent=2))
# Export a readable sheet with all final runtime animation cells.
out=Image.new('RGBA',(1536,7*110),(30,35,47,255));d=ImageDraw.Draw(out)
for row,(name,records) in enumerate(manifest.items()):
 for col,record in enumerate(records):
  out.alpha_composite(Image.open(P/'assets/enemies_v8'/record['file']),(col*192,row*110+14));d.text((col*192+4,row*110),record['file'],fill='white')
out.save(P/'planning/Enemy_SpriteSheet_v0.8.png')
print('Packed',len(manifest),'enemy designs / 56 frames / 12 props')

