"""Generate original replacement artwork; no external game assets required.

Run from any directory with Python 3 + Pillow + fonttools. All coordinates are
logical pixels; frames intentionally use hard edges for nearest-neighbor scaling.
"""
from pathlib import Path
import json, math, random
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
random.seed(19)
INK = '#182333'

def save(im, name):
    p = ROOT / 'assets' / name
    p.parent.mkdir(parents=True, exist_ok=True)
    im.save(p)

def actor(frame=0, player=True, kind='helmet', pose='ground'):
    im = Image.new('RGBA', (128,128) if player else (96,80))
    d = ImageDraw.Draw(im)
    x, foot = (64,100) if player else (48,80)
    if not player and kind in ('tank','railgun'):
        im = Image.new('RGBA',(144,80));d=ImageDraw.Draw(im)
        d.rounded_rectangle((8,55,137,77),8,fill=INK)
        for i in range(8):
            d.ellipse((14+i*15,59,26+i*15,73),fill='#647776',outline='#a2b4a4',width=2)
        d.polygon([(12,54),(28,39),(113,39),(133,56)],fill='#68837b',outline=INK,width=3)
        d.rectangle((49,27,104,45),fill='#82978b',outline=INK,width=3)
        d.rectangle((4,32,60,39),fill='#bac6ad',outline=INK,width=2)
        d.rectangle((61,30,72,33),fill='#ffb96b')
        for i in range(6): d.rectangle((25+i*16,46,29+i*16,49),fill='#a7b9a3')
        return im
    air = pose.startswith('air')
    crouch = pose=='ground' and frame in (10,11)
    dead = pose=='ground' and frame>=14
    y = foot-(43 if crouch else 61)
    skin='#f1cbb1' if player or kind in ('helmet','sukeban','sniper') else '#acb7a7'
    coat='#40405c' if player else {'helmet':'#819075','military':'#6d8982','shield':'#b39572','sniper':'#7a7891','sukeban':'#a16e84'}.get(kind,'#6d8982')
    light='#777195' if player else '#b5bea0'
    stride = int(math.sin(frame*math.pi/2)*6) if frame<8 else 0
    # Wings and hair form a distinct readable silhouette behind the gun.
    if player:
        if air:
            wing=9 if frame%4<2 else -3
            for s in (-1,1):
                d.polygon([(x+s*5,y+27),(x+s*34,y+10+wing),(x+s*29,y+36),(x+s*18,y+29),(x+s*10,y+40)],fill='#624879',outline=INK,width=2)
        d.polygon([(x-12,y+8),(x-18,y+39),(x-12,y+46),(x-7,y+25),(x+15,y+43),(x+20,y+37),(x+11,y+8)],fill='#c4b9d9',outline=INK,width=2)
    d.line((x-5,y+39,x-7-stride,foot-4),fill=INK,width=8)
    d.line((x+5,y+39,x+7+stride,foot-4),fill=INK,width=8)
    d.line((x-5,y+40,x-7-stride,foot-7),fill='#a1a2b4' if player else '#627168',width=4)
    d.line((x+5,y+40,x+7+stride,foot-7),fill='#a1a2b4' if player else '#627168',width=4)
    d.rectangle((x-12-stride,foot-6,x-3-stride,foot-1),fill=INK)
    d.rectangle((x+3+stride,foot-6,x+13+stride,foot-1),fill=INK)
    d.polygon([(x-9,y+23),(x+9,y+23),(x+12,y+42),(x-12,y+42)],fill=coat,outline=INK,width=2)
    d.line((x-5,y+24,x-4,y+38),fill=light,width=2)
    d.rectangle((x-9,y+37,x+10,y+40),fill='#c6ad77')
    d.rectangle((x-3,y+38,x,y+40),fill='#f6da9c')
    d.rectangle((x-9,y+6,x+10,y+23),fill=skin,outline=INK,width=2)
    if player:
        d.polygon([(x-12,y+14),(x-12,y+3),(x-6,y),(x+8,y),(x+13,y+7),(x+12,y+16),(x+7,y+10),(x+3,y+14),(x-1,y+8),(x-6,y+14)],fill='#ddd6ec',outline=INK,width=2)
        d.polygon([(x-10,y+5),(x-15,y-6),(x-5,y+1)],fill='#4f3c66',outline=INK)
        d.polygon([(x+7,y+2),(x+15,y-7),(x+13,y+8)],fill='#4f3c66',outline=INK)
        d.ellipse((x-14,y-13,x+14,y-6),outline='#d6bfff',width=2)
    else:
        d.rounded_rectangle((x-13,y,x+13,y+12),5,fill=coat,outline=INK,width=2)
        d.rectangle((x-15,y+10,x+15,y+13),fill=light,outline=INK)
    d.rectangle((x+2,y+15,x+4,y+18),fill='#e473b8' if player else '#f9c47c')
    d.rectangle((x+8,y+15,x+10,y+17),fill='#68466d')
    d.line((x-7,y+28,x+6,y+33),fill=skin,width=5)
    d.line((x+7,y+27,x+17,y+30),fill=skin,width=5)
    # Heavy machine gun, with barrel / feed belt / receiver highlights.
    gx=x+5 if player else x-36
    gy=y+29
    d.rectangle((gx,gy-3,gx+29,gy+6),fill='#292e3e',outline=INK,width=2)
    d.rectangle((gx+4,gy-2,gx+19,gy),fill='#8e9ea6')
    d.rectangle((gx+26,gy-1,gx+39,gy+3),fill='#77878c',outline=INK)
    for i in range(4):d.rectangle((gx+7+i*4,gy+4,gx+9+i*4,gy+8),fill='#bea16b')
    if kind=='shield' and not player:
        d.rectangle((10,38,31,76),fill='#72877f',outline=INK,width=3)
        d.rectangle((15,43,27,48),fill='#f5bf72')
    if player and pose=='air' and frame in (4,5,6,7):
        # Gun points below the body for downwards aerial fire.
        d.rectangle((x+3,y+36,x+10,y+62),fill='#343c50',outline=INK,width=2)
    if player and pose=='air' and frame>=12:
        d.line((x+10,y+30,x+18,y-9 if frame<14 else y+5),fill='#364152',width=7)
        d.line((x+17,y+14,x+18,y-17 if frame<14 else y-2),fill='#9daab0',width=3)
    if pose=='kick':
        d.line((x+3,y+38,x+30,y+27),fill=INK,width=9)
        d.line((x+3,y+38,x+29,y+27),fill='#a1a2b4',width=5)
    if dead:
        im=im.rotate(70 if frame==14 else 90,resample=Image.Resampling.NEAREST,center=(x,foot-12))
    return im

def backgrounds():
    palettes=[('#244b66','#7ccac3','#ead7a0'),('#564666','#dbaa80','#d4ac70'),('#282d44','#839b9b','#526669'),('#121c39','#4b4c73','#353c59'),('#132d3b','#497a78','#314e58')]
    for stage,(top,bottom,ground) in enumerate(palettes):
        im=Image.new('RGB',(1536,310));d=ImageDraw.Draw(im)
        from PIL import ImageColor
        a,b=ImageColor.getrgb(top),ImageColor.getrgb(bottom)
        for y in range(310):d.line((0,y,1536,y),fill=tuple(int(a[i]+(b[i]-a[i])*y/310) for i in range(3)))
        d.ellipse((1070,38,1140,108),fill='#f5dca1' if stage<2 else '#92a7b2')
        for x in range(-80,1600,100):
            h=random.randrange(30,100)
            d.polygon([(x,219),(x+60,219-h),(x+150,219)],fill='#547784' if stage==0 else '#5c6275')
        if stage==0:
            d.rectangle((0,223,1536,310),fill='#4d9eaa')
            for i in range(350):
                x=random.randrange(1536);y=random.randrange(226,310)
                d.line((x,y,x+random.randrange(4,25),y),fill=random.choice(['#75b7b7','#9cd0c4','#3d869b']))
        for x in range(50,1536,180):
            if stage==1:
                d.polygon([(x-50,273),(x+35,128),(x+120,273)],fill='#b88a67',outline='#e0b985',width=2)
                for y in range(178,268,18):d.line((x+5-(y-178)//2,y,x+65+(y-178)//2,y),fill='#957a65')
            else:
                h=random.randrange(50,134);base=265 if stage==0 else 295
                d.rectangle((x,base-h,x+100,base),fill='#334f62',outline='#729393',width=2)
                for xx in range(x+9,x+92,18):
                    for yy in range(base-h+12,base-10,19):
                        d.rectangle((xx,yy,xx+6,yy+8),fill=random.choice(['#b7ad86','#4e6d7c','#6f9898']))
                if stage in (2,4):
                    d.line((x+22,base-h,x+22,70,x+125,70),fill='#8b9c92',width=4)
                    d.line((x+125,70,x+125,156),fill='#526975',width=2)
                    d.line((x+22,70,x+60,35,x+125,70),fill='#8b9c92',width=2)
        if stage==4:
            for x in range(0,1536,150):
                d.rectangle((x,0,x+14,310),fill='#263f4d',outline='#7c9c91',width=2)
                d.rectangle((x+4,80,x+10,220),fill='#62d1be')
        save(im,f'backgrounds_v6/stage_{stage}.png')
        tile=Image.new('RGB',(768,60),ground);g=ImageDraw.Draw(tile)
        g.rectangle((0,0,768,5),fill='#ddd4ae');g.line((0,6,768,6),fill=INK,width=3)
        for i in range(700):
            x=random.randrange(768);y=random.randrange(10,60)
            g.rectangle((x,y,x+random.randrange(1,5),y+1),fill=random.choice(['#6c766a','#b4ad86','#535c5d']))
        for x in range(0,768,96):
            g.line((x,8,x,60),fill=INK)
            g.rectangle((x+8,13,x+88,17),fill='#869081')
        save(tile,f'backgrounds_v6/ground_{stage}.png')
    save(Image.open(ROOT/'assets/backgrounds_v6/stage_0.png'),'backgrounds/coast.png')
    save(Image.open(ROOT/'assets/backgrounds_v6/ground_1.png'),'backgrounds/sand.png')

def bosses():
    for i in range(6):
        im=Image.new('RGBA',(256,224));d=ImageDraw.Draw(im)
        metal=['#bba37b','#aeb8b4','#7e9aa1','#9b85a5','#879f91','#acbba2'][i]
        if i==0:
            # Coiled mechanical serpent: armored vertebrae and glowing eye.
            pts=[(190,208),(223,185),(226,147),(200,116),(156,107),(129,87),(142,55),(178,33),(204,49)]
            d.line(pts,fill=INK,width=39,joint='curve');d.line(pts,fill=metal,width=31,joint='curve')
            for a,b in zip(pts,pts[1:]):
                for k in range(3):
                    x=a[0]+(b[0]-a[0])*k/3;y=a[1]+(b[1]-a[1])*k/3
                    d.ellipse((x-14,y-12,x+14,y+12),fill=metal,outline='#514b4c',width=3)
                    d.rectangle((x-5,y-7,x+3,y-3),fill='#e5d3a2')
            d.polygon([(122,37),(170,23),(192,46),(179,70),(127,67),(102,54)],fill=metal,outline=INK,width=3)
            d.rectangle((117,43,139,48),fill='#ff6a77');d.line((106,58,151,61),fill=INK,width=4)
        elif i==1:
            d.ellipse((49,29,215,205),fill=metal,outline=INK,width=4)
            d.ellipse((78,11,109,65),fill=metal,outline=INK,width=3);d.ellipse((160,10,189,64),fill=metal,outline=INK,width=3)
            d.ellipse((80,78,106,107),fill=INK);d.ellipse((157,78,183,107),fill=INK)
            d.polygon([(115,112),(152,112),(133,136)],fill='#e5b46b',outline=INK,width=3)
            for x in (70,163): d.rectangle((x,194,x+35,215),fill='#cbb47e',outline=INK,width=3)
        elif i==3:
            for x in (82,166):d.rectangle((x,150,x+25,213),fill=metal,outline=INK,width=4)
            d.polygon([(68,77),(178,68),(191,159),(79,159)],fill=metal,outline=INK,width=4)
            d.rectangle((94,29,160,81),fill=metal,outline=INK,width=4)
            d.rectangle((99,44,150,52),fill='#f18cbf')
            for x in (44,183): d.rectangle((x,85,x+30,163),fill=metal,outline=INK,width=3)
            d.rectangle((10,113,110,130),fill='#4a5064',outline=INK,width=3)
        else:
            for x in (63,166):
                d.line((128,120,x,173,x-12,214),fill=INK,width=22)
                d.line((128,120,x,173,x-12,214),fill=metal,width=14)
            d.ellipse((48,36,211,186),fill=metal,outline=INK,width=5)
            for r,c in [(53,'#3a4b58'),(39,'#697c7e'),(26,'#f6d88c' if i==5 else '#ed7488')]:
                d.ellipse((128-r,110-r,128+r,110+r),fill=c,outline=INK,width=3)
            for a in range(0,360,45):
                x=128+math.cos(math.radians(a))*68;y=110+math.sin(math.radians(a))*60
                d.rectangle((x-4,y-4,x+4,y+4),fill='#d4d6b8',outline=INK)
        save(im,f'bosses_v7/boss_{i}.png')

def props():
    for i in range(12):
        im=Image.new('RGBA',(96,64));d=ImageDraw.Draw(im)
        color=['#9f8561','#ad655b','#7a9285','#727a89','#677d83','#9d8970','#858e75','#a58d72','#687b82','#8d7b77','#617779','#555d60'][i]
        if i==1:
            d.rounded_rectangle((23,3,73,62),8,fill=color,outline=INK,width=3)
            for y in (12,43):d.rectangle((22,y,74,y+5),fill='#d0a18a',outline=INK)
            d.polygon([(48,22),(57,36),(39,36)],fill='#f0c77b',outline=INK)
        else:
            d.rectangle((1,3,94,63),fill=color,outline=INK,width=3)
            d.rectangle((6,8,89,58),outline='#c5bd99',width=2)
            if i in (0,7):
                d.line((7,9,88,57),fill='#c5bd99',width=5);d.line((88,9,7,57),fill='#c5bd99',width=5)
            else:
                for x in range(13,90,12):d.line((x,12,x,55),fill='#3f535d',width=2)
            for x in (9,85):
                for y in (11,53):d.rectangle((x,y,x+2,y+2),fill=INK)
        save(im,f'props_v9/prop_{i:02}.png')
    for i in range(4):
        im=Image.new('RGBA',(64,64));d=ImageDraw.Draw(im)
        r=12+i*5
        for j in range(12):
            a=j*math.pi/6;x=32+math.cos(a)*r*.6;y=32+math.sin(a)*r*.6
            d.ellipse((x-r*.5,y-r*.5,x+r*.5,y+r*.5),fill='#bd5552' if i==3 else '#ff9752')
        d.ellipse((32-r*.55,32-r*.55,32+r*.55,32+r*.55),fill='#ffe0a0')
        d.ellipse((25,24,39,39),fill='#fff4c7')
        save(im,f'effects/ex_{i}.png')

def title():
    im=Image.open(ROOT/'assets/backgrounds_v6/stage_3.png').crop((0,0,640,310)).convert('RGBA').resize((640,360))
    overlay=Image.new('RGBA',im.size,(9,16,32,135));im=Image.alpha_composite(im,overlay);d=ImageDraw.Draw(im)
    for x in range(18,640,28):d.line((x,0,x-220,360),fill='#263b4c',width=1)
    for y in (25,210,345):d.line((28,y,612,y),fill='#7a847e',width=1)
    def font(size):return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',size)
    def text(y,t,size,color):
        f=font(size);box=d.textbbox((0,0),t,font=f);d.text(((640-(box[2]-box[0]))/2,y),t,font=f,fill=color,stroke_width=1 if size>30 else 0)
    text(43,'G E H E N N A   /   T A C T I C A L   A R C A D E',10,'#c2c7b6')
    text(68,'PROJECT',24,'#eee4c8');text(87,'HINA',82,'#f5d89a')
    text(184,'O P E R A T I O N   G E H E N N A',12,'#cebedf')
    # Framing sprite silhouettes flank the central navigation.
    hero=actor(0,True,pose='air').resize((192,192),Image.Resampling.NEAREST)
    im.alpha_composite(hero,(35,153))
    tank=actor(0,False,'tank').resize((168,94),Image.Resampling.NEAREST)
    im.alpha_composite(tank,(442,248))
    d=ImageDraw.Draw(im);text(349,'5 MISSIONS   /   RUN & GUN   /   ORIGINAL REPLACEMENT ART',8,'#9caaa6')
    save(im,'backgrounds_v9/title.png')

def main():
    manifest=json.loads((ROOT/'data/animation_manifest.json').read_text())
    for anim in manifest.values():
        for f in anim['frames']:
            p=Path(f['file']);stem=p.stem;pose,idx=stem.rsplit('_',1)
            save(actor(int(idx),True,pose=pose),str(p.relative_to('assets')))
    for kind in ('helmet','sukeban','sniper','shield','military','tank','railgun'):
        for i in range(4):
            im=actor(i,False,kind);save(im,f'enemies_v8/{kind}_{i}.png')
            death=im.rotate(30+i*20,resample=Image.Resampling.NEAREST)
            save(death,f'enemies_v8/{kind}_death_{i}.png')
        for i in range(6):save(actor(i,False,kind),f'enemies_v9/{kind}_walk_{i}.png')
    backgrounds();bosses();props();title()
    print('Original pixel assets generated.')

if __name__=='__main__':main()
