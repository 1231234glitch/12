#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
HINA_GODOT="${GODOT_BIN:-godot}"
mkdir -p builds
"$HINA_GODOT" --headless --path . --editor --import --quit
"$HINA_GODOT" --headless --path . --export-release 'Windows Desktop' builds/Project_HINA.exe

