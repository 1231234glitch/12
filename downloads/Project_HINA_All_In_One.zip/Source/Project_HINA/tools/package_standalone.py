"""Package verified standalone builds and source, with hashes and test evidence."""
from pathlib import Path
import hashlib,json,struct,zipfile
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/'outputs';OUT.mkdir(exist_ok=True)
results={}
for name in ['test_results','raid_test_results','v9_test_results']:
    d=json.loads((ROOT/'planning'/f'{name}.json').read_text())
    assert d['failures']==0, name
    results[name]=len(d['tests'])
assert json.loads((ROOT/'planning/audio_test_results.json').read_text())['passed']
assert json.loads((ROOT/'planning/browser_test_results.json').read_text())['passed']
exe=(ROOT/'builds/Project_HINA.exe').read_bytes()
pe=struct.unpack_from('<I',exe,0x3c)[0]
assert exe[:2]==b'MZ' and exe[pe:pe+4]==b'PE\0\0'
assert struct.unpack_from('<H',exe,pe+4)[0]==0x8664
# Validate embedded pack footer, not just the executable's extension.
size,magic=struct.unpack_from('<QI',exe,len(exe)-12)
assert magic==0x43504447 and exe[len(exe)-12-size:][:4]==b'GDPC'
verification={'engine':'Godot 4.6.3','functional_checks':results,'total_checks':sum(results.values()),'failures':0,'audio_mixer_passed':True,'windows_pe_x86_64':True,'windows_embedded_pack_present':True,'windows_runtime_tested':False,'browser_keyboard_smoke_passed':True,'art':'Original procedural replacement sprites and scenery','audio':'Original synthesized music and SFX'}
(ROOT/'planning/build_verification.json').write_text(json.dumps(verification,indent=2))

def make_zip(name,entries):
    target=OUT/name
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for path,arc in entries:z.write(path,arc)
    with zipfile.ZipFile(target) as z:assert z.testzip() is None
    return {'name':name,'bytes':target.stat().st_size,'sha256':hashlib.file_digest(target.open('rb'),'sha256').hexdigest()}
reports=[]
shared=[(ROOT/'README.md','README.md'),(ROOT/'planning/build_verification.json','verification.json'),(ROOT/'assets/fonts/LICENSE.txt','FONT_LICENSE.txt')]
reports.append(make_zip('Project_HINA_Windows.zip',[(ROOT/'builds/Project_HINA.exe','Project_HINA.exe')]+shared))
reports.append(make_zip('Project_HINA_Web.zip',[(p,p.name) for p in sorted((ROOT/'builds/web').iterdir()) if p.is_file()]+shared))
source=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(ROOT)
    if any(x in rel.parts for x in ['.git','.godot','builds','__pycache__']):continue
    if rel.parts[0]=='planning' and p.suffix not in ['.json','.md']:continue
    if p.suffix=='.import':continue
    source.append((p,'Project_HINA/'+str(rel)))
reports.append(make_zip('Project_HINA_Source.zip',source))
(OUT/'SHA256SUMS.txt').write_text(''.join(f"{r['sha256']}  {r['name']}\n" for r in reports))
(OUT/'manifest.json').write_text(json.dumps({'artifacts':reports,'verification':verification},indent=2))
print(json.dumps(reports,indent=2))
