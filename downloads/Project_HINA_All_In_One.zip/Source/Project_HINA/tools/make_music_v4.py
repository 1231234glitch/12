"""Original arcade march-rock score, offline General MIDI sample rendering.

Requires libfluidsynth and the bundled TimGM6mb soundfont. The YouTube recording
is a mood reference, not sampled or transcribed. Run with Python + numpy + ffmpeg.
"""
from pathlib import Path
import ctypes as C, ctypes.util, numpy as np, json, wave, subprocess
P=Path(__file__).resolve().parents[1];SR=44100
lib=C.CDLL(ctypes.util.find_library('fluidsynth') or 'libfluidsynth.so.3')
def api(name,restype,args):
 f=getattr(lib,name);f.restype=restype;f.argtypes=args;return f
ptr=C.c_void_p;I=C.c_int
new_settings=api('new_fluid_settings',ptr,[])
setting=api('fluid_settings_setnum',I,[ptr,C.c_char_p,C.c_double])
setting_int=api('fluid_settings_setint',I,[ptr,C.c_char_p,I])
new_synth=api('new_fluid_synth',ptr,[ptr])
sfload=api('fluid_synth_sfload',I,[ptr,C.c_char_p,I])
program=api('fluid_synth_program_change',I,[ptr,I,I])
cc=api('fluid_synth_cc',I,[ptr,I,I,I])
on=api('fluid_synth_noteon',I,[ptr,I,I,I]);off=api('fluid_synth_noteoff',I,[ptr,I,I])
write=api('fluid_synth_write_float',I,[ptr,I,ptr,I,I,ptr,I,I])
delete=api('delete_fluid_synth',None,[ptr]);delete_settings=api('delete_fluid_settings',None,[ptr])

def compose(name,bpm,bars,boss=False,menu=False):
 events=[];beat=60/bpm
 def note(ch,pitch,t,dur,vel):
  events.append((round(t*beat*SR),1,ch,pitch,vel))
  events.append((round((t+dur)*beat*SR),0,ch,pitch,0))
 # D-minor -> Bb -> F -> C, contrasting G minor / A sections.
 roots=[38,38,46,46,41,41,36,36,43,43,46,46,38,36,45,45]
 motif=[[74,0,77,76,74,69,72,74],[77,0,81,79,77,76,74,72],
        [70,74,77,0,79,77,74,70],[72,0,76,79,77,76,72,69],
        [79,77,74,0,72,74,77,79],[81,79,77,76,74,72,69,0],
        [77,76,74,72,69,72,74,77],[73,76,81,0,79,76,73,69]]
 for bar in range(bars):
  t=bar*4;section=(bar//8)%4;root=roots[bar%16]
  if boss:root=[38,38,39,36,38,43,46,45][bar%8]
  intro=bar<4
  # Active electric bass / palm-muted rhythm guitar.
  for k in range(8):
   pitch=root+[0,0,12,0,7,0,10,12][k]
   note(0,pitch,t+k*.5,.36,96 if k%2==0 else 78)
   note(9,42 if k%4!=3 else 46,t+k*.5,.12,55 if k%2 else 76)
   if not menu:
    for p in [root+12,root+19]:note(2,p,t+k*.5,.19,58 if k%2 else 74)
  for k in ([0,1.5,2,2.75] if boss else [0,2,2.5]):note(9,36,t+k,.15,110)
  for k in [1,3]:note(9,38,t+k,.16,110)
  if bar%4==0:note(9,49,t,.6,87)
  # Snare rudiments and tom turnarounds, rather than a fixed synthetic tick.
  if bar%4==3:
   for k in range(8):note(9,[38,38,48,47,45,45,41,38][k],t+3+k*.125,.1,55+k*7)
  else:
   for k in [2.75,3.75]:note(9,38,t+k,.08,35)
  chord=[root+24,root+27,root+31] if root not in [41,36,45] else [root+24,root+28,root+31]
  for p in chord:note(3,p,t,3.7,42 if menu else 34)
  # Brass ensemble off-beat punches, then trumpet call / guitar response.
  for k in [.0,1.5,2.5]:
   for p in chord:note(4,p,t+k,.28,58 if intro else 72)
  if not intro or menu:
   line=motif[(bar+section*2)%len(motif)]
   ch=1 if section in [0,2] else 5
   if menu:ch=1
   for k,p in enumerate(line):
    if not p:continue
    if boss:p-=12
    note(ch,p,t+k*.5,.42 if k%2 else .32,93 if k%2==0 else 82)
    if section==2 and not menu:note(6,p-12,t+k*.5,.35,56)
  if section==3 and bar%2==0:
   for k in range(16):note(7,chord[k%3]+12,t+k*.25,.13,38)
 total=round(bars*4*beat*SR)
 st=new_settings();setting(st,b'synth.sample-rate',SR);setting(st,b'synth.gain',.55)
 setting(st,b'synth.reverb.room-size',.28);setting(st,b'synth.reverb.level',.15)
 setting_int(st,b'synth.chorus.active',0);setting_int(st,b'synth.polyphony',192)
 sy=new_synth(st)
 assert sfload(sy,str(P/'tools/soundfont/TimGM6mb.sf2').encode(),1)>=0
 # GM: finger bass, trumpet, overdriven guitar, strings, brass, lead guitar, trombone, piano.
 programs=[33,56,29,48,61,30,57,0]
 pans=[64,48,28,82,78,80,40,96];volumes=[103,96,60,54,78,80,70,52]
 for ch,pr in enumerate(programs):program(sy,ch,pr);cc(sy,ch,10,pans[ch]);cc(sy,ch,7,volumes[ch])
 cc(sy,9,7,110)
 events.sort();mix=np.zeros((total,2),np.float32);cursor=0
 def render(end):
  nonlocal cursor
  end=min(end,total)
  if end<=cursor:return
  chunk=mix[cursor:end]
  write(sy,len(chunk),chunk.ctypes.data,0,2,chunk.ctypes.data,1,2);cursor=end
 for at,kind,ch,p,vel in events:
  render(at)
  if at>=total:break
  on(sy,ch,p,vel) if kind else off(sy,ch,p)
 render(total);delete(sy);delete_settings(st)
 # Gentle mastering, no hard clipping; short loop boundary fades.
 mix=np.tanh(mix*1.35);mix*=.86/max(float(np.abs(mix).max()),.01)
 fade=220;mix[:fade]*=np.linspace(0,1,fade)[:,None];mix[-fade:]*=np.linspace(1,0,fade)[:,None]
 wav=P/'assets/sounds'/f'bgm_{name}.wav';ogg=wav.with_suffix('.ogg')
 with wave.open(str(wav),'wb') as w:
  w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes((mix*32767).astype('<i2').tobytes())
 subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(wav),'-c:a','libvorbis','-q:a','6',str(ogg)],check=True);wav.unlink()
 record={'seconds':total/SR,'bpm':bpm,'bars':bars,'peak':float(np.abs(mix).max()),'rms':float(np.sqrt(np.mean(mix**2))),'instruments':programs,'original_composition':True}
 print(name,record,flush=True);return record

if __name__=='__main__':
 report=json.loads((P/'planning/audio_assets.json').read_text())
 for name,bpm,bars in [('coast',156,40),('boss',172,32),('menu',128,16)]:
  report['bgm_'+name]=compose(name,bpm,bars,name=='boss',name=='menu')
 (P/'planning/audio_assets.json').write_text(json.dumps(report,indent=2))

