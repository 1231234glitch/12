"""Original procedural arcade score and layered SFX. Development tool, not required by EXE."""
from pathlib import Path
import numpy as np, wave, subprocess, json
P=Path(__file__).resolve().parents[1]; O=P/'assets/sounds';O.mkdir(exist_ok=True)
SR=44100;rng=np.random.default_rng(20261016)
def freq(n):return 440*2**((n-69)/12)
def note(n,dur,kind='lead'):
 t=np.arange(int(SR*dur))/SR;f=freq(n)
 if kind=='bass':y=sum(np.sin(2*np.pi*f*k*t)/k for k in range(1,6))*.5
 elif kind=='pad':y=np.sin(2*np.pi*f*t)*.6+np.sin(2*np.pi*f*1.003*t)*.3+np.sin(2*np.pi*f*2*t)*.1
 else:y=sum(np.sin(2*np.pi*f*k*t)*(1 if k%4<2 else -.5)/k for k in range(1,9))*.6
 env=np.minimum(1,t/.009)*np.minimum(1,(dur-t)/(.09 if kind=='pad' else .035));return y*env

def drum(kind):
 d={'kick':.24,'snare':.17,'hat':.065,'crash':.65}[kind];t=np.arange(int(SR*d))/SR;noise=rng.normal(0,1,len(t));hp=noise-np.roll(noise,1)
 if kind=='kick':y=np.sin(2*np.pi*(44*t+85*.025*(1-np.exp(-t/.025))))*np.exp(-t*19)+hp*.09*np.exp(-t*100)
 elif kind=='snare':y=hp*.23*np.exp(-t*28)+np.sin(2*np.pi*185*t)*.3*np.exp(-t*35)
 elif kind=='hat':y=hp*.12*np.exp(-t*70)
 else:y=hp*.13*np.exp(-t*7)
 return y

def save(name,y,ogg=False):
 y=np.asarray(y);peak=float(np.max(np.abs(y)));y=np.tanh(y*1.1);y=y/max(.98,float(np.max(np.abs(y))))*.9
 path=O/(name+'.wav')
 with wave.open(str(path),'wb') as w:
  w.setnchannels(1 if y.ndim==1 else 2);w.setsampwidth(2);w.setframerate(SR);w.writeframes((np.clip(y,-1,1)*32767).astype('<i2').tobytes())
 if ogg:
  subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(path),'-c:a','libvorbis','-q:a','5',str(O/(name+'.ogg'))],check=True);path.unlink()
 return {'seconds':len(y)/SR,'peak':float(np.max(np.abs(y))),'rms':float(np.sqrt(np.mean(y*y)))}

def song(name,bpm,bars,boss=False):
 beat=60/bpm;total=bars*4*beat;mix=np.zeros((int(total*SR),2));dr={k:drum(k) for k in ['kick','snare','hat','crash']}
 def add(sound,at,gain,pan=0):
  i=int(at*SR);n=min(len(sound),len(mix)-i)
  if i<0 or n<=0:return
  mix[i:i+n,0]+=sound[:n]*gain*(1-pan*.45);mix[i:i+n,1]+=sound[:n]*gain*(1+pan*.45)
 roots=[40,36,43,38] if not boss else [40,40,41,38]
 melody=[[76,0,79,81,83,81,79,76],[74,76,79,0,76,74,72,74],[79,0,83,86,83,81,79,76],[78,81,83,81,78,76,74,0]]
 for bar in range(bars):
  start=bar*4*beat;root=roots[(bar//2)%4]
  for k in range(8):
   add(note(root+(12 if k%4==3 else 0),beat*.43,'bass'),start+k*.5*beat,.23,-.05)
   add(dr['hat'],start+k*.5*beat,.3 if k%2 else .22,.5 if k%2 else -.5)
  for k in [0,2]:add(dr['kick'],start+k*beat,.7)
  for k in [1,3]:add(dr['snare'],start+k*beat,.53,-.12)
  if bar%8==0:add(dr['crash'],start,.5,.35)
  for j,n in enumerate([root+24,root+27,root+31]):add(note(n,beat*3.9,'pad'),start,.055,(j-1)*.7)
  if bar>=2 or boss:
   for k,n in enumerate(melody[bar%4]):
    if n:
     n+=12 if bar%16>=12 else 0
     if boss:n-=12
     tone=note(n,beat*.41);add(tone,start+k*.5*beat,.22,-.15);add(tone,start+k*.5*beat+.16,.055,.7)
  if bar%8==7:
   for k in range(6):add(dr['snare'],start+3*beat+k*beat/6,.12+k*.035,(k-2.5)/4)
 # Gentle boundary fade only; rhythmic section loops on exact bar boundary.
 fade=int(.012*SR);mix[:fade]*=np.linspace(0,1,fade)[:,None];mix[-fade:]*=np.linspace(1,0,fade)[:,None]
 return save(name,mix,True)
report={}
report['bgm_coast']=song('bgm_coast',144,32)
report['bgm_boss']=song('bgm_boss',168,24,True)
report['bgm_menu']=song('bgm_menu',112,8)
for name,bpm in [('desert',132),('rail',156),('night',120),('reactor',150)]:
 report['bgm_'+name]=song('bgm_'+name,bpm,40)

def tone_sfx(name,dur,fn):
 t=np.arange(int(SR*dur))/SR;noise=rng.normal(0,1,len(t));y=fn(t,noise)*np.minimum(1,t/.002)*np.minimum(1,(dur-t)/.015);report[name]=save(name,y)
tone_sfx('shot',.14,lambda t,n:(n*.32*np.exp(-t*48)+np.sin(2*np.pi*(125*t+85*.012*(1-np.exp(-t/.012))))*.7*np.exp(-t*33)+np.sin(2*np.pi*1900*t)*.12*np.exp(-t*75)))
tone_sfx('enemy_shot',.18,lambda t,n:n*.25*np.exp(-t*30)+np.sin(2*np.pi*180*t)*.5*np.exp(-t*27))
tone_sfx('hit',.20,lambda t,n:n*.25*np.exp(-t*26)+np.sin(2*np.pi*(450*t-600*t*t))*.4*np.exp(-t*20))
tone_sfx('armor_hit',.25,lambda t,n:(np.sin(2*np.pi*1800*t)+np.sin(2*np.pi*2810*t))*.3*np.exp(-t*30)+n*.1*np.exp(-t*40))
tone_sfx('ricochet',.18,lambda t,n:np.sin(2*np.pi*(2200*t-4000*t*t))*.28*np.exp(-t*30))
tone_sfx('footstep',.07,lambda t,n:n*.12*np.exp(-t*55)+np.sin(2*np.pi*110*t)*.12*np.exp(-t*40))
tone_sfx('land',.17,lambda t,n:n*.18*np.exp(-t*30)+np.sin(2*np.pi*75*t)*.32*np.exp(-t*25))
tone_sfx('jump',.16,lambda t,n:np.sin(2*np.pi*(300*t+1300*t*t))*.22*np.exp(-t*18))
tone_sfx('explosion',.75,lambda t,n:n*.45*np.exp(-t*7)+np.sin(2*np.pi*(42*t+55*.06*(1-np.exp(-t/.06))))*.65*np.exp(-t*7))
tone_sfx('charge',.84,lambda t,n:(np.sin(2*np.pi*(170*t+650*t*t))*.23+np.sin(2*np.pi*(250*t+950*t*t))*.12)*np.minimum(1,t*5))
tone_sfx('special',1.0,lambda t,n:(n*.3+np.sin(2*np.pi*(55*t+180*t*t))*.5)*np.exp(-t*4)+(np.sin(2*np.pi*920*t)+np.sin(2*np.pi*1380*t))*.13*np.exp(-t*5))
tone_sfx('death',.5,lambda t,n:np.sin(2*np.pi*(440*t-390*t*t))*.3*np.exp(-t*5)+n*.16*np.exp(-t*12))
for name,notes in [('pickup',[76,83,88]),('respawn',[64,71,76,83]),('clear',[72,76,79,84,88]),('ui',[79,83]),('boss',[40,40,43,40])]:
 length=.09 if name=='ui' else .12;y=np.zeros(int(SR*(length*len(notes)+.15)))
 for i,n in enumerate(notes):
  a=note(n,length+.12)*.35;off=int(SR*i*length);y[off:off+len(a)]+=a[:len(y)-off]
 report[name]=save(name,y)
(P/'planning/audio_assets.json').write_text(json.dumps(report,indent=2));print('Audio generated:',len(report),'assets')


for i in range(1,6):
 save("stage_clear_%d"%i, np.tile(note(72+i, .35), 8))
