from pathlib import Path
p=Path(__file__).resolve().parents[1];f=p/'scripts/actors/boss.gd';s=f.read_text()
s=s.replace('var textures: Array = []','''var textures: Array = []
var anchor := Vector2.ZERO
var movement_target := Vector2.ZERO
var attack_motion := 0.0
var defeat_time := 0.0
var mesh: Polygon2D
var rest_vertices := PackedVector2Array()
var mesh_indices: Array[PackedInt32Array] = []
''')
s=s.replace('\tgame.sound("boss")','\tanchor=position;movement_target=position\n\tbuild_mesh()\n\tgame.sound("boss")',1)
s=s.replace('if dead or game.player.hp<=0:return','''if game.player.hp<=0:return
\tif dead:
\t\tdefeat_time+=delta
\t\tmesh.modulate.a=clampf(1-defeat_time/2.0,0,1)
\t\tmesh.position.y+=delta*10
\t\tif int(defeat_time*8)!=int((defeat_time-delta)*8) and defeat_time<1.5:
\t\t\tgame.explode(position+Vector2(randf_range(-75,65),randf_range(-170,-25)),35,0,self)
\t\treturn''')
s=s.replace('\tclock+=delta;flash=maxf(0,flash-delta)','\tclock+=delta;flash=maxf(0,flash-delta)\n\tattack_motion=maxf(0,attack_motion-delta)\n\tupdate_movement(delta)')
s=s.replace('\ttimer-=delta','\tupdate_mesh()\n\ttimer-=delta',1)
s=s.replace('func perform_attack() -> void:\n','func perform_attack() -> void:\n\tattack_motion=.65\n\tchoose_movement()\n')
s=s.replace('position.x=game.stage_length-500+slot*190','position.x=game.stage_length-500+slot*190\n\tanchor=position;movement_target=position')
s=s.replace('game.score+=5000;game.explode','defeat_time=0\n\t\tgame.score+=5000;game.explode')
s+='''
func build_mesh() -> void:
\tmesh=Polygon2D.new();mesh.texture=sprite.texture;mesh.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
\tvar size:=sprite.texture.get_size()
\tvar uv:=PackedVector2Array()
\tfor row in range(7):
\t\tfor col in range(13):
\t\t\tvar point:=Vector2(size.x*col/12.0,size.y*row/6.0)
\t\t\tuv.append(point);rest_vertices.append(point-size/2)
\tfor row in range(6):
\t\tfor col in range(12):
\t\t\tvar a:=row*13+col
\t\t\tmesh_indices.append(PackedInt32Array([a,a+1,a+14]));mesh_indices.append(PackedInt32Array([a,a+14,a+13]))
\tmesh.polygon=rest_vertices;mesh.uv=uv;mesh.polygons=mesh_indices
\tadd_child(mesh);sprite.visible=false
\tupdate_mesh()

func choose_movement() -> void:
\t# Shift between attacks; all telegraphed hazards stay locked in world space.
\tvar sign_x:=1.0 if pattern%2==0 else -1.0
\tmatch game.stage_index:
\t\t0:movement_target=anchor+Vector2(-45+sign_x*40,0)
\t\t1:movement_target=anchor+Vector2(-30+sign_x*30,0)
\t\t2:movement_target=anchor+Vector2(-35+sign_x*35,0)
\t\t3:movement_target=anchor+Vector2(sign_x*22,0)
\t\t4:movement_target=anchor+Vector2(sign_x*20,0)
\tmovement_target.x=clampf(movement_target.x,game.stage_length-530,game.stage_length-95)

func update_movement(delta: float) -> void:
\tif state in ["INTRO","RECOVER"]:
\t\tposition=position.move_toward(movement_target,delta*(32 if game.stage_index==2 else 48))

func update_mesh() -> void:
\tif mesh==null:return
\tmesh.texture=sprite.texture;mesh.scale=sprite.scale
\tmesh.position=sprite.position
\tmesh.modulate=sprite.modulate
\tvar points:=rest_vertices.duplicate()
\tvar kick:=sin(clampf(attack_motion/.65,0,1)*PI)
\tfor i in range(points.size()):
\t\tvar v:Vector2=rest_vertices[i]
\t\tvar top:=clampf(-v.y/100.0+.5,0,1)
\t\tmatch game.stage_index:
\t\t\t0: # Snake vertebrae undulate with a delayed wave, head retracts to fire.
\t\t\t\tpoints[i].x+=sin(clock*2.6+v.y*.035)*4*top+kick*9*top
\t\t\t\tpoints[i].y+=sin(clock*2.2+v.x*.025)*2*top
\t\t\t1: # Weight on feet, breathing belly, head anticipation and landing squash.
\t\t\t\tpoints[i].y-=absf(sin(clock*2))*2.5*top+kick*8*top
\t\t\t\tpoints[i].x+=v.x*.012*sin(clock*2.0)*(1-top)
\t\t\t2: # Heavy grounded chassis, upper antenna/turret recoil.
\t\t\t\tpoints[i].x+=kick*6*top
\t\t\t\tpoints[i].y+=sin(clock*8)*.6*(1-top)
\t\t\t3: # Floating magician with trailing cloth.
\t\t\t\tpoints[i].x+=sin(clock*3+v.y*.045)*3*(1-top)
\t\t\t\tpoints[i].y+=sin(clock*1.7)*5+kick*5*top
\t\t\t4: # Levitation and breathing armored core panels.
\t\t\t\tpoints[i].x+=signf(v.x)*sin(clock*1.6)*2.5
\t\t\t\tpoints[i].y+=sin(clock*1.8)*4+sin(clock*3+absf(v.x)*.025)*2
\tmesh.polygon=points
'''
f.write_text(s)

