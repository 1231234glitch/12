from PIL import Image
from pathlib import Path
import numpy as np
from scipy.ndimage import label
p=Path(__file__).resolve().parents[1]
im=Image.open(p/'assets/atlases/props_source_v9.png').convert('RGBA')
xs=[[0,380,750,1110,1536],[0,395,775,1210,1536],[0,360,770,1140,1536]];ys=[0,344,650,1024]
for j in range(3):
 for i in range(4):
  a=np.array(im.crop((xs[j][i],ys[j],xs[j][i+1],ys[j+1])));mask=a[:,:,3]>210
  lab,n=label(mask);sizes=np.bincount(lab.ravel());sizes[0]=0
  # Keep substantial components, discard neighboring sprite slivers.
  mask &= sizes[lab]>max(100,sizes.max()*.015);a[:,:,3]=mask*255
  c=Image.fromarray(a);c=c.crop(c.getbbox());c.thumbnail((256,192),Image.Resampling.NEAREST);c.save(p/'assets/props_v9'/f'prop_{j*4+i:02d}.png')
out=Image.new('RGB',(768,420),(42,49,58))
for k in range(12):
 c=Image.open(p/'assets/props_v9'/f'prop_{k:02d}.png');c.thumbnail((180,125));out.paste(c,(k%4*192,k//4*140),c)
out.save(p/'planning/Props_v9.png')

