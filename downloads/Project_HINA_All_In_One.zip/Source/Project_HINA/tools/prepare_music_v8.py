"""Licensed full-production recordings, loudness matched; not generated MIDI.
Source URLs and licenses in LICENSES/MUSIC_v8.md. Requires ffmpeg/numpy.
"""
from pathlib import Path
import subprocess,json,numpy as np
P=Path(__file__).resolve().parents[1];root=Path('/tmp/hina-music');pack=root/'Alexander Ehlers - Free Music Pack'
tracks={'coast':('Great mission','Alexander Ehlers',pack/'Alexander Ehlers - Great mission.mp3'),'desert':('Full On','Kevin MacLeod',root/'full_on.mp3'),'rail':('Metalmania','Kevin MacLeod',root/'metalmania.mp3'),'night':('Warped','Alexander Ehlers',pack/'Alexander Ehlers - Warped.mp3'),'reactor':('Doomed','Alexander Ehlers',pack/'Alexander Ehlers - Doomed.mp3'),'boss':('Waking the devil','Alexander Ehlers',pack/'Alexander Ehlers - Waking the devil.mp3'),'menu':('Flags','Alexander Ehlers',pack/'Alexander Ehlers - Flags.mp3')}
report=json.loads((P/'planning/audio_assets.json').read_text());metadata={}
for name,(title,author,path) in tracks.items():
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-f','f32le','-ar','44100','-ac','2','-'])
 a=np.frombuffer(raw,dtype='<f4').reshape(-1,2).copy();sr=44100
 # Trim only long digital silence; keep the composed introductions and endings.
 envelope=np.max(abs(a),axis=1);nz=np.where(envelope>.001)[0]
 a=a[max(0,nz[0]-2205):min(len(a),nz[-1]+2205)]
 # A short cyclic equal-power overlap removes a hard restart click.
 fade=min(11025,len(a)//20);theta=np.linspace(0,np.pi/2,fade)[:,None]
 seam=a[-fade:]*np.cos(theta)+a[:fade]*np.sin(theta)
 a=np.concatenate([seam,a[fade:-fade]])
 temp=root/(name+'.wav')
 subprocess.run(['ffmpeg','-v','error','-y','-f','f32le','-ar',str(sr),'-ac','2','-i','-','-c:a','pcm_s16le',str(temp)],input=a.astype('<f4').tobytes(),check=True)
 probe=subprocess.run(['ffmpeg','-hide_banner','-i',str(temp),'-af','loudnorm=I=-18:TP=-1.5:LRA=10:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
 data=json.loads(probe.stderr[probe.stderr.rfind('{'):])
 af=f"loudnorm=I=-18:TP=-1.5:LRA=10:measured_I={data['input_i']}:measured_TP={data['input_tp']}:measured_LRA={data['input_lra']}:measured_thresh={data['input_thresh']}:offset={data['target_offset']}:linear=true"
 out=P/'assets/sounds'/('bgm_'+name+'.ogg')
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(temp),'-af',af,'-ar',str(sr),'-c:a','libvorbis','-q:a','7','-metadata',f'title={title}','-metadata',f'artist={author}',str(out)],check=True)
 record={'title':title,'author':author,'license':'CC BY 4.0' if author=='Kevin MacLeod' else 'CC0 1.0','seconds':len(a)/sr,'arrangement_version':8,'original_composition':False,'source_recording':True,'loudness_target_lufs':-18,'peak_ceiling_dbtp':-1.5,'loop_overlap_seconds':.25}
 report['bgm_'+name]=record;metadata[name]=record;print(name,title,round(len(a)/sr,1),flush=True)
(P/'planning/audio_assets.json').write_text(json.dumps(report,indent=2));(P/'data/music_credits.json').write_text(json.dumps(metadata,indent=2))
# Short composed fanfare excerpt, with attribution to the same CC0 author.
subprocess.run(['ffmpeg','-v','error','-y','-ss','8','-i',str(pack/'Alexander Ehlers - Flags.mp3'),'-t','4.6','-af','loudnorm=I=-18:TP=-2:LRA=9,afade=t=in:d=0.06,afade=t=out:st=3.8:d=0.8','-ar','44100','-ac','2',str(P/'assets/sounds/clear.wav')],check=True)

