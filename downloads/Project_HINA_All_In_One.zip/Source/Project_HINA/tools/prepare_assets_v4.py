"""Pack generated sprite art onto fixed pivots; no independent frame stretching."""
from pathlib import Path
from PIL import Image, ImageDraw
import json
P=Path(__file__).resolve().parents[1]
out=P/'assets/player_v4';out.mkdir(exist_ok=True)
records=[]
def pack(source,name,air=False):
 im=Image.open(P/'assets/atlases'/source).convert('RGBA')
 frames=[]
 # Reviewed gutters at actual 1254px source resolution, not nominal prompt size.
 xs=[0,330,642,950,1254];ys=[0,332,640,940,1254]
 px=[185,499,813,1127];py=[316,622,925,1224]
 for i in range(16):
  r,c=divmod(i,4);box=(xs[c],ys[r],xs[c+1],ys[r+1])
  crop=im.crop(box);alpha=crop.getchannel('A').point(lambda a:255 if a>=160 else 0)
  crop.putalpha(alpha)
  scale=.205
  crop=crop.resize((round(crop.width*scale),round(crop.height*scale)),Image.Resampling.NEAREST)
  canvas=Image.new('RGBA',(128,128))
  pivot_y=py[r]
  # Down-fire toes sit above muzzle. Keep actor feet at y100 and barrel below.
  if air and r==1:pivot_y=598
  canvas.alpha_composite(crop,(round(64-(px[c]-box[0])*scale),round(100-(pivot_y-box[1])*scale)))
  f=out/f'{name}_{i:02}.png';canvas.save(f)
  muzzle=[27,-20]
  if air:
   if r==1:muzzle=[5,6]
   elif r==3:muzzle=([8,-54] if c<2 else [18,-49])
   else:muzzle=[27,-20]
  elif i==10:muzzle=[23,-19]
  elif i==11:muzzle=[25,-16]
  rec={'file':str(f.relative_to(P)),'pivot':[64,100],'muzzle':muzzle,'source_rect':list(box)}
  frames.append(rec);records.append(rec)
 return frames
g=pack('hina_motion_v4.png','ground');a=pack('hina_air_v4.png','air',True)
m={}
def anim(name,frames,fps=12,loop=True):m[name]={'fps':fps,'loop':loop,'frames':frames}
anim('idle',g[8:10],4);anim('walk',g[:8],14);anim('walk_shoot',g[:8],14)
anim('jump',a[:4],12);anim('jump_rise',a[:4],12);anim('jump_apex',a[:4],12);anim('fall',a[:4],12)
anim('land',[g[11],g[8]],18,False);anim('shoot',g[8:10],16)
anim('crouch',[g[10]],8);anim('crouch_shoot',[g[10]],12)
anim('shoot_up',a[12:14],8);anim('shoot_diagonal',a[14:16],8)
anim('air_down',a[4:8],12);anim('air_shoot',a[8:12],12)
anim('special',[g[12],g[12],g[13],g[13],g[8]],6,False)
anim('hurt',[g[14]],12,False);anim('down',[g[15]],12,False)
anim('get_up',[g[11],g[8]],12,False);anim('death',g[14:16],12,False)
(P/'data/animation_manifest.json').write_text(json.dumps(m,indent=2))
sheet=Image.new('RGBA',(1024,512));review=Image.new('RGB',(1024,576),'#344755');d=ImageDraw.Draw(review)
for i,f in enumerate(records):
 x=(i%8)*128;y=(i//8)*128;im=Image.open(P/f['file']);sheet.alpha_composite(im,(x,y))
 yy=i//8*144;review.paste(im,(x,yy),im);d.text((x+5,yy+129),Path(f['file']).stem,fill='white')
sheet.save(P/'planning/Hina_SpriteSheet_v0.4.png');review.save(P/'planning/v4_sprite_review.png')
(P/'planning/sprite_sheet_layout.json').write_text(json.dumps({'cell':[128,128],'columns':8,'frames':records},indent=2))
print('Packed',len(records),'frames',len(m),'states')

