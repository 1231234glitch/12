extends Node2D
# Attackable raid objects are separate from ordinary one-hit enemies.
var raid: Node2D
var kind := "automata"
var dead := false
var hp := 1.0
var age := 0.0
var shot_timer := 3.0
var radius := 20.0
var center_offset := Vector2(0,-24)
var flash := 0.0
var sprite: Sprite2D

func _ready() -> void:
	sprite=Sprite2D.new();sprite.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	if kind=="peroro":
		sprite.texture=load("res://assets/bosses_v7/boss_1.png");sprite.scale=Vector2.ONE*.29;sprite.position.y=-30
	elif kind=="clone":
		sprite.texture=load("res://assets/bosses_v7/boss_3.png");sprite.scale=Vector2.ONE*.65;sprite.position.y=-66
		radius=57;center_offset=Vector2(0,-66)
	elif kind=="pillar":
		hp=3;radius=30;center_offset=Vector2(0,-36)
	else:
		sprite.texture=load("res://assets/enemies_v8/military_0.png");sprite.position.y=-40
	add_child(sprite)

func _physics_process(delta: float) -> void:
	if dead or raid.dead or raid.game.player.hp<=0:return
	age+=delta;flash=maxf(0,flash-delta)
	sprite.modulate=Color(2,1,1) if flash>0 else Color.WHITE
	if kind=="automata":
		position.x=maxf(raid.game.stage_length-590,position.x-12*delta)
		sprite.texture=load("res://assets/enemies_v8/military_%d.png"%(int(age*8)%3))
		shot_timer-=delta
		if shot_timer<=0:
			shot_timer=3.5
			raid.game.fire(position+Vector2(-15,-24),Vector2(-120,0),false,1)
		if age>=20:
			raid.add_blast(position+Vector2(0,-20),48,1.2)
			die(false)
	elif kind=="pillar" and age>2:
		# Expanding corrosion has a bright rim; jumping clears its floor hitbox.
		var spread:=minf(100,(age-2)*12)
		var player_rect:=Rect2(raid.game.player.position+Vector2(-8,-35),Vector2(16,35))
		if Rect2(position+Vector2(-spread,-8),Vector2(spread*2,8)).intersects(player_rect):raid.game.player.take_damage(1)
	queue_redraw()

func take_damage(amount: float,_direction:=Vector2.RIGHT) -> void:
	if dead:return
	flash=.12
	if kind=="clone":
		raid.game.sound("ricochet");return
	hp-=amount
	if hp<=0:die(true)
	else:raid.game.sound("armor_hit")

func die(by_player: bool) -> void:
	if dead:return
	dead=true
	raid.game.sound("robot_down" if kind in ["pillar","automata"] else "enemy_down")
	raid.game.particles(position+center_offset,Color("ffc076"),12,95)
	raid.target_destroyed(self,by_player)
	# Collapse and fade before freeing, with collision removed immediately.
	var tween=create_tween().set_parallel(true)
	tween.tween_property(sprite,"position",sprite.position+Vector2(12,12),.3)
	tween.tween_property(sprite,"rotation",.55,.3)
	tween.tween_property(sprite,"modulate:a",0.0,.4)
	tween.chain().tween_callback(queue_free)

func _draw() -> void:
	if dead:return
	if kind=="pillar":
		var spread:=minf(100,maxf(0,age-2)*12)
		draw_rect(Rect2(-spread,-8,spread*2,8),Color(.1,.6,1,.35))
		draw_line(Vector2(-spread,-8),Vector2(spread,-8),Color("84ebff"),2)
		draw_colored_polygon(PackedVector2Array([Vector2(-23,0),Vector2(-17,-63),Vector2(0,-81),Vector2(17,-63),Vector2(23,0)]),Color("293d58"))
		draw_rect(Rect2(-21,-12,42,12),Color("151f35"))
		draw_rect(Rect2(-16,-59,32,44),Color("3d5977"))
		draw_rect(Rect2(-11,-56,22,38),Color("102134"))
		draw_rect(Rect2(-7,-65,14,54),Color("76e2ff"))
		draw_rect(Rect2(-2,-60,4,45),Color("e2ffff"))
		for y in [-55,-30,-12]:
			draw_rect(Rect2(-20,y,40,4),Color("647d95"))
			for x in [-17,14]:draw_rect(Rect2(x,y,3,3),Color("d3b27a"))
		for i in range(3):draw_circle(Vector2(-12+i*12,-85),3,Color("ffcb70") if hp<=i else Color("70dfff"))
	elif kind=="clone":
		draw_rect(Rect2(-8,-160,16,22),Color("ff426b"));draw_string(ThemeDB.fallback_font,Vector2(-4,-144),"♦",HORIZONTAL_ALIGNMENT_LEFT,-1,16,Color.WHITE)
	elif kind=="automata" and age>18.8:
		draw_arc(Vector2(0,-24),28,0,TAU,24,Color("ff6655"),2)

