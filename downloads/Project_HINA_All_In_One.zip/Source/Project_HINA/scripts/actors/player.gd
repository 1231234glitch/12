extends CharacterBody2D

var game: Node2D
var stats: Dictionary = {}
var hp := 1
var facing := 1
var stock := 3
var invulnerable := 0.0
var coyote := 0.0
var jump_buffer := 0.0
var fire_timer := 0.0
var kick_time := 0.0
var kick_hit := false
var kick_air := false
var special_time := 0.0
var special_fired := false
var hurt_time := 0.0
var land_time := 0.0
var was_grounded := false
var clock := 0.0
var state := "idle"
var last_state := ""
var animation_time := 0.0
var gait := 0.0
var wing_time := 0.0
var wing_frame := 0
var frame_index := 0
var sprite: Sprite2D
var hitbox: RectangleShape2D
var textures: Dictionary = {}
var animations: Dictionary = {}
var footsteps := 0.0
var shots := 0
var muzzle := Vector2.ZERO
var aim := Vector2.RIGHT
var muzzle_offset := Vector2(25,-20)
var last_safe_position := Vector2(80,310)

func _ready() -> void:
	z_index=5 # Keep Hina readable when she crosses a large boss sprite.
	stats = JSON.parse_string(FileAccess.get_file_as_string("res://data/player_stats.json"))
	hp = 1
	stock = int(stats.special_stock)
	collision_layer = 2
	collision_mask = 1
	hitbox = RectangleShape2D.new()
	hitbox.size = Vector2(16,35)
	var collision := CollisionShape2D.new()
	collision.shape = hitbox
	collision.position = Vector2(0,-17.5)
	add_child(collision)
	sprite = Sprite2D.new()
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	sprite.position = Vector2(0,-36)
	add_child(sprite)
	animations = JSON.parse_string(FileAccess.get_file_as_string("res://data/animation_manifest.json"))
	for animation in animations:
		textures[animation] = []
		for frame in animations[animation].frames:
			textures[animation].append(load("res://"+frame.file))
	update_visual(false)

func _physics_process(delta: float) -> void:
	if hp<=0: return
	clock += delta
	animation_time += delta
	invulnerable=maxf(0,invulnerable-delta)
	land_time=maxf(0,land_time-delta)
	fire_timer=maxf(0,fire_timer-delta)
	hurt_time=maxf(0,hurt_time-delta)
	var grounded:=is_on_floor()
	if grounded: wing_time=0.0
	else: wing_time+=delta
	wing_frame=int(wing_time*12.0)%4
	coyote=.08 if grounded else maxf(0,coyote-delta)
	jump_buffer=.10 if Input.is_action_just_pressed("jump") else maxf(0,jump_buffer-delta)
	var movement:=Input.get_axis("left","right")
	var crouch:=grounded and Input.is_action_pressed("down")
	if movement!=0 and special_time<=0 and kick_time<=0: facing=int(signf(movement))
	if Input.is_action_just_pressed("special") and stock>0 and special_time<=0 and kick_time<=0:
		stock-=1; special_time=1.7; special_fired=false
		invulnerable=maxf(invulnerable,1.7);game.sound("charge")
	velocity.y=minf(velocity.y+float(stats.gravity)*delta,float(stats.max_fall_speed))
	if special_time>0:
		var previous:=special_time
		special_time=maxf(0,special_time-delta);velocity.x=0
		if previous>.85 and special_time<=.85 and not special_fired:
			special_fired=true;game.special_attack(position,facing)
	else:
		velocity.x=movement*float(stats.speed) if not crouch else 0.0
		if jump_buffer>0 and coyote>0:
			velocity.y=float(stats.jump_velocity);jump_buffer=0;coyote=0;game.sound("jump")
	if kick_time>0:
		kick_time=maxf(0,kick_time-delta)
		if grounded:velocity.x=0
		if kick_time<=.32 and not kick_hit:
			kick_hit=true;perform_kick()
	move_and_slide()
	position.x=clampf(position.x,game.camera.position.x-308,game.stage_length-14)
	if game.boss_active: position.x=maxf(position.x,game.stage_length-630)
	if is_on_floor() and not was_grounded:
		land_time=.11;game.sound("land");game.particles(position,Color("b2a6a0"),5,45)
	was_grounded=is_on_floor()
	crouch=is_on_floor() and Input.is_action_pressed("down")
	hitbox.size.y=22 if crouch else 35
	get_child(0).position.y=-hitbox.size.y/2
	if is_on_floor(): last_safe_position=position
	if position.y>450:
		take_damage(1,true);return
	if is_on_floor() and absf(velocity.x)>0:
		gait+=absf(velocity.x)*delta/float(stats.speed)*14.0
		footsteps-=delta
		if footsteps<=0: footsteps=.27;game.sound("footstep")
	aim=Vector2(facing,0)
	if Input.is_action_pressed("up"):
		aim=Vector2(movement,-1).normalized()
	elif not is_on_floor() and Input.is_action_pressed("down"):
		aim=Vector2.DOWN
	update_visual(crouch)
	muzzle=position+Vector2(muzzle_offset.x*facing+sprite.position.x,muzzle_offset.y)
	if Input.is_action_pressed("shoot") and fire_timer<=0 and special_time<=0:
		if kick_time>0:return
		if melee_target():
			kick_time=.44;kick_hit=false;kick_air=not is_on_floor();fire_timer=.44
			game.sound("kick_swing");update_visual(crouch);queue_redraw();return
		shots+=1;fire_timer=float(game.weapon_stats.fire_interval)
		# The longer barrel must not spawn shots through nearby cover.
		var barrel_query:=PhysicsRayQueryParameters2D.create(position+Vector2(0,-20),muzzle,1)
		var barrel_hit:=get_world_2d().direct_space_state.intersect_ray(barrel_query)
		if barrel_hit.is_empty():
			game.fire(muzzle,aim*float(game.weapon_stats.bullet_speed),true,int(game.weapon_stats.damage))
		else:
			game.particles(barrel_hit.position,Color("ffc888"),3,40);game.sound("ricochet")
		game.sound("shot");game.particles(muzzle,Color("ffe7ac"),3,45)
		game.particles(position+Vector2(0,-22),Color("d4b074"),1,75)
	queue_redraw()

func update_visual(crouch: bool) -> void:
	var shooting:=Input.is_action_pressed("shoot")
	state="idle"
	if special_time>0:
		state="special"
	elif kick_time>0:
		state="air_kick" if kick_air else "kick"
	elif aim.y>.5 and not is_on_floor():
		state="air_down"
	elif aim.y<-.5:
		state="shoot_up" if absf(aim.x)<.1 else "shoot_diagonal"
	elif not is_on_floor():
		state="air_shoot" if shooting else ("jump_rise" if velocity.y< -40 else ("jump_apex" if velocity.y<40 else "fall"))
	elif crouch:
		state="crouch_shoot" if shooting else "crouch"
	elif land_time>0:
		state="land"
	elif absf(velocity.x)>1:
		state="walk_shoot" if shooting else "walk"
	elif shooting:
		state="shoot"
	if state!=last_state:
		animation_time=0;last_state=state
	var definition: Dictionary=animations[state]
	var index:=int(animation_time*float(definition.fps))
	if state in ["walk","walk_shoot"]: index=int(gait)
	if state in ["shoot_up","shoot_diagonal","shoot"]:
		index=(1 if fire_timer>.035 else 0) if shooting else 0
	# Airborne poses share a continuous wing clock across aim/state changes.
	# Recoil stays on the sprite position; it must never freeze the flap cycle.
	if not is_on_floor() and special_time<=0 and kick_time<=0:
		if state in ["shoot_up","shoot_diagonal"]: index=0 if wing_frame<2 else 1
		else: index=wing_frame
	if state in ["kick","air_kick"]:index=int((.44-kick_time)*16)
	if state=="special":index=0 if special_time>.85 else (2 if special_time>.15 else 4)
	frame_index=index%textures[state].size() if definition.loop else mini(index,textures[state].size()-1)
	sprite.texture=textures[state][frame_index]
	var frame: Dictionary=definition.frames[frame_index]
	muzzle_offset=Vector2(float(frame.muzzle[0]),float(frame.muzzle[1]))
	sprite.flip_h=facing<0
	sprite.position=Vector2(-facing if shooting and fire_timer>.055 else 0,-36)
	sprite.modulate.a=.55 if invulnerable>0 and special_time<=0 and int(clock*14)%2==0 else 1.0

func _draw() -> void:
	if hp<=0:return
	if special_time>.85:
		var radius:=6+(1.7-special_time)*22
		draw_arc(Vector2(0,-38),radius,clock*5,clock*5+TAU*.85,28,Color("d56bff"),2)
	if fire_timer>.035 and special_time<=0 and kick_time<=0:
		var point:=Vector2(muzzle_offset.x*facing+sprite.position.x,muzzle_offset.y)
		var side:=Vector2(-aim.y,aim.x)
		draw_colored_polygon(PackedVector2Array([point-side*3,point+aim*12,point+side*3,point-aim*2]),Color("ffdda6"))
		draw_line(point,point+aim*8,Color.WHITE,2)

func respawn(at: Vector2) -> void:
	position=at;hp=1;velocity=Vector2.ZERO
	stock=int(stats.special_stock);invulnerable=2.5
	kick_time=0;kick_hit=false;kick_air=false
	special_time=0;special_fired=false;hurt_time=0;fire_timer=0
	jump_buffer=0;coyote=0;land_time=0;was_grounded=false
	animation_time=0;last_state="";sprite.modulate=Color.WHITE
	wing_time=0;wing_frame=0
	aim=Vector2(facing,0);set_physics_process(true);update_visual(false)
	queue_redraw()

func take_damage(amount: int,ignore_invulnerability:=false) -> void:
	if hp<=0 or amount<=0 or (invulnerable>0 and not ignore_invulnerability) or game.mode!="playing":return
	hp=0;special_time=0
	game.particles(position+Vector2(0,-20),Color("ff7594"),12,110)
	game.shake=4;game.sound("hit");game.player_died();queue_redraw()

func melee_target() -> bool:
	for enemy in game.enemies:
		if is_instance_valid(enemy) and not enemy.dead and kick_reaches(enemy.position):return true
	if is_instance_valid(game.boss) and not game.boss.dead:
		for target in game.boss.targets:
			if is_instance_valid(target) and not target.dead and target.kind!="clone" and kick_reaches(target.position):return true
	return false

func kick_reaches(target: Vector2) -> bool:
	var offset:=target-position
	if offset.x*facing<0 or offset.x*facing>54 or absf(offset.y)>30:return false
	var query:=PhysicsRayQueryParameters2D.create(position+Vector2(0,-22),target+Vector2(0,-22),1)
	return get_world_2d().direct_space_state.intersect_ray(query).is_empty()

func perform_kick() -> void:
	var connected:=false
	for enemy in game.enemies.duplicate():
		if is_instance_valid(enemy) and not enemy.dead and kick_reaches(enemy.position):
			enemy.take_damage(1,Vector2(facing,0));connected=true
	if is_instance_valid(game.boss) and not game.boss.dead:
		for target in game.boss.targets.duplicate():
			if is_instance_valid(target) and not target.dead and target.kind!="clone" and kick_reaches(target.position):
				target.take_damage(3,Vector2(facing,0));connected=true
	if connected:
		game.sound("kick_hit");game.shake=2
		game.particles(position+Vector2(facing*34,-20),Color("fff2bc"),9,90)

