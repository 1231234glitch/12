extends Node2D
const RaidTarget = preload("res://scripts/actors/raid_target.gd")
var game: Node2D
var hp := 240.0
var maximum_hp := 240.0
var phase := 1
var state := "INTRO"
var timer := 2.0
var pattern := -1
var clock := 0.0
var flash := 0.0
var dead := false
var sprite: Sprite2D
var telegraph := Vector2.ZERO
var attack := ""
var hint := ""
var targets: Array = []
var hazards: Array = []
var wave := 0
var wave_pending := false
var core_time := 0.0
var vulnerable_time := 0.0
var clone_round := 0
var textures: Array = []
var anchor := Vector2.ZERO
var movement_target := Vector2.ZERO
var attack_motion := 0.0
var defeat_time := 0.0
var mesh: Polygon2D
var rest_vertices := PackedVector2Array()
var mesh_indices: Array[PackedInt32Array] = []


func _ready() -> void:
	maximum_hp=240+game.stage_index*100;hp=maximum_hp
	for i in range(6):textures.append(load("res://assets/bosses_v7/boss_%d.png"%i))
	sprite=Sprite2D.new();sprite.texture=textures[game.stage_index]
	sprite.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;sprite.position.y=-102;add_child(sprite)
	anchor=position;movement_target=position
	build_mesh()
	game.sound("boss")

func _physics_process(delta: float) -> void:
	if game.player.hp<=0:return
	if dead:
		defeat_time+=delta
		mesh.modulate.a=clampf(1-defeat_time/2.0,0,1)
		mesh.position.y+=delta*10
		if int(defeat_time*8)!=int((defeat_time-delta)*8) and defeat_time<1.5:
			game.explode(position+Vector2(randf_range(-75,65),randf_range(-170,-25)),35,0,self)
		return
	clock+=delta;flash=maxf(0,flash-delta)
	attack_motion=maxf(0,attack_motion-delta)
	update_movement(delta)
	phase=2 if hp<=maximum_hp*.5 else 1
	sprite.position.y=(-66 if game.stage_index==3 and phase==2 else -102)+sin(clock*1.8)*3
	sprite.modulate=Color("ffb5d4") if flash>0 else Color.WHITE
	vulnerable_time=maxf(0,vulnerable_time-delta)
	update_hazards(delta)
	if game.stage_index==4:
		update_core(delta)
		sprite.texture=textures[5 if core_time>0 else 4]
	update_mesh()
	timer-=delta
	if timer<=0:
		if state in ["INTRO","RECOVER"]:prepare()
		elif state=="WARN":
			perform_attack();state="RECOVER";timer=1.8 if phase==1 else 1.35
	queue_redraw()

func prepare() -> void:
	state="WARN";timer=1.1;pattern+=1;telegraph=game.player.position+Vector2(0,-18)
	match game.stage_index:
		0:
			var sequence: Array=["laser","laser","missiles"] if phase==1 else ["laser","laser","missiles","laser","sandstorm"]
			attack=sequence[pattern%sequence.size()]
			if attack=="laser":
				hint="LASER / MOVE AFTER THE LOCK"
				var origin:=position+Vector2(-65,-150)
				var direction:Vector2=(telegraph-origin).normalized()
				hazards.append({"type":"beam","a":origin,"b":origin+direction*760,"width":8.0,"delay":timer,"life":.38})
			elif attack=="missiles":
				hint="MISSILES / LEAVE THE MARKED LANES"
				for offset in [-110,0,110]:
					var x:=clampf(telegraph.x+offset,game.stage_length-605,game.stage_length-35)
					add_rect(Rect2(x-22,95,44,215),timer,.4)
			else:
				hint="SANDSTORM / JUMP"
				add_rect(Rect2(game.stage_length-640,294,640,16),timer,.3)
		1:
			attack="peroro" if pattern%2==0 else "eye"
			if attack=="peroro":hint="PERORO / DEFEAT THE SMALL ONES"
			else:
				hint="EYE BEAM / LEAVE THE LOCKED HEIGHT"
				var y:=clampf(telegraph.y,130,290)
				hazards.append({"type":"beam","a":position+Vector2(20,-150),"b":Vector2(game.stage_length-650,y),"width":12.0,"delay":timer,"life":.5})
		2:
			attack="pillars" if count_targets("pillar")==0 and vulnerable_time<=0 else "pulse"
			hint="PILLARS / SHOOT 3 TIMES OR USE KICK / EX" if attack=="pillars" else "HOD PULSE / JUMP"
			if attack=="pulse":add_rect(Rect2(game.stage_length-640,298,640,12),timer,.3)
		3:
			if phase==2 and pattern%2==0:shuffle_clones()
			attack="train" if pattern%2==0 else "bombs"
			hint="SCREAM RIDER / JUMP OVER THE TRAIN" if attack=="train" else "BOMBS / MOVE OUT OF THE CIRCLES"
			if attack=="train":
				hazards.append({"type":"train","rect":Rect2(game.stage_length+30,272,104,38),"delay":timer,"life":2.8,"velocity":Vector2(-300,0)})
			else:
				for offset in [-85,85]:add_blast(Vector2(clampf(telegraph.x+offset,game.stage_length-590,game.stage_length-30),290),40,timer)
		4:
			attack="core"
			if core_time>0:hint="CORE OPEN / ATTACK NOW"
			elif not wave_pending and count_targets("automata")==0:
				attack="wave";hint="CHESED / CLEAR FOUR WAVES TO OPEN THE CORE"
			else:hint="CLEAR THE AUTOMATA / CORE %d OF 4"%wave
	game.sound("charge")

func perform_attack() -> void:
	attack_motion=.65
	choose_movement()
	match attack:
		"peroro":
			if count_targets("peroro")==0:
				for n in range(3):spawn_target("peroro",Vector2(game.stage_length-390+n*95,310))
		"pillars":
			for n in range(2):spawn_target("pillar",Vector2(game.stage_length-380+n*150,310))
		"wave":
			if core_time<=0 and count_targets("automata")==0:
				wave_pending=true
				for n in range(3):spawn_target("automata",Vector2(game.stage_length-340+n*80,310))
	if attack not in ["core","wave","peroro","pillars"]:game.sound("explosion")

func spawn_target(kind: String,at: Vector2) -> Node2D:
	var target=RaidTarget.new();target.raid=self;target.kind=kind;target.position=at
	game.world.add_child(target);targets.append(target);return target

func count_targets(kind: String) -> int:
	var count:=0
	for target in targets:
		if is_instance_valid(target) and not target.dead and target.kind==kind:count+=1
	return count

func target_destroyed(target: Node2D,by_player: bool) -> void:
	if dead:return
	if target.kind=="peroro" and by_player:take_damage(28)
	if target.kind=="pillar" and count_targets("pillar")==0:
		vulnerable_time=6;hint="HOD STAGGERED / ATTACK NOW";game.sound("boss")
	if target.kind=="automata" and not by_player:
		# A self-detonated wave does not earn a core-opening charge.
		wave_pending=false

func update_core(delta: float) -> void:
	if core_time>0:
		core_time=maxf(0,core_time-delta)
		if core_time<=0:wave=0;timer=.3;state="RECOVER";hint="CORE CLOSED"
	elif wave_pending and count_targets("automata")==0:
		wave_pending=false;wave+=1
		if wave>=4:
			core_time=5;hazards.clear();hint="CORE OPEN / ATTACK NOW";game.sound("boss")
		else:timer=.35;state="RECOVER";hint="CORE CHARGE %d / 4"%wave

func shuffle_clones() -> void:
	for target in targets:
		if is_instance_valid(target) and target.kind=="clone":target.dead=true;target.queue_free()
	var slot:=clone_round%3;clone_round+=1
	sprite.scale=Vector2.ONE*.65;sprite.position.y=-66
	position.x=game.stage_length-500+slot*190
	anchor=position;movement_target=position
	for n in range(3):
		if n!=slot:spawn_target("clone",Vector2(game.stage_length-500+n*190,310))

func add_rect(rect: Rect2,delay: float,life: float) -> void:
	hazards.append({"type":"rect","rect":rect,"delay":delay,"life":life})

func add_blast(at: Vector2,radius: float,delay: float) -> void:
	hazards.append({"type":"circle","at":at,"radius":radius,"delay":delay,"life":.35})

func update_hazards(delta: float) -> void:
	var player_center:Vector2=game.player.position+Vector2(0,-17)
	var player_rect:=Rect2(game.player.position+Vector2(-8,-34),Vector2(16,34))
	for hazard in hazards.duplicate():
		if hazard.delay>0:
			hazard.delay-=delta;continue
		hazard.life-=delta
		if hazard.life<=0:hazards.erase(hazard);continue
		var hits:=false
		match hazard.type:
			"rect":hits=hazard.rect.intersects(player_rect)
			"circle":hits=player_center.distance_to(hazard.at)<hazard.radius+12
			"beam":hits=Geometry2D.get_closest_point_to_segment(player_center,hazard.a,hazard.b).distance_to(player_center)<hazard.width+12
			"train":
				hazard.rect.position+=hazard.velocity*delta
				hits=hazard.rect.intersects(player_rect)
		if hits:game.player.take_damage(1)

func take_damage(amount: float,_direction:=Vector2.RIGHT) -> void:
	if dead or state=="INTRO":return
	if game.stage_index==4 and core_time<=0:
		game.sound("ricochet");return
	var multiplier:=1.0
	if game.stage_index==2:multiplier=1.5 if vulnerable_time>0 else .3
	if game.stage_index==4:multiplier=3.0
	hp=maxf(0,hp-amount*multiplier);flash=.08;game.sound("armor_hit")
	game.particles(position+Vector2(-50,-100),Color("ffbb6e"),4,100)
	if hp<=0:
		dead=true;hazards.clear()
		for target in targets:
			if is_instance_valid(target):target.dead=true;target.queue_free()
		defeat_time=0
		game.score+=5000;game.explode(position+Vector2(0,-100),140,0,self);game.stage_cleared()

func collision_center() -> Vector2:
	return position+Vector2(0,-66 if game.stage_index==3 and phase==2 else -100)

func collision_radius() -> float:
	return 57.0 if game.stage_index==3 and phase==2 else 90.0

func weakpoint() -> Rect2:
	return Rect2(collision_center()-Vector2.ONE*collision_radius(),Vector2.ONE*collision_radius()*2)

func _draw() -> void:
	if dead:return
	var warn:=Color(1,.25,.35,.4+.15*sin(clock*20))
	for h in hazards:
		var color:=warn if h.delay>0 else Color(1,.75,.4,.9)
		match h.type:
			"beam":
				draw_line(h.a-position,h.b-position,color,2 if h.delay>0 else h.width*2)
				if h.delay<=0:draw_line(h.a-position,h.b-position,Color.WHITE,3)
			"rect":
				var rect:Rect2=h.rect;rect.position-=position;draw_rect(rect,color)
				if h.delay>0:draw_rect(rect,Color("ffadb4"),false,1)
			"circle":
				draw_circle(h.at-position,h.radius,color,false,2)
				if h.delay<=0:draw_circle(h.at-position,h.radius*.8,color)
			"train":
				if h.delay>0:
					draw_line(Vector2(game.stage_length-640,306)-position,Vector2(game.stage_length,306)-position,warn,4)
				else:
					var r:Rect2=h.rect;r.position-=position
					draw_rect(r,Color("231f35"));draw_rect(r.grow(-3),Color("884db1"))
					for n in range(3):draw_rect(Rect2(r.position+Vector2(10+n*28,6),Vector2(18,14)),Color("ffc667"))
					for n in range(4):draw_circle(r.position+Vector2(12+n*25,34),7,Color("292132"))
	if game.stage_index==3 and phase==2:
		draw_rect(Rect2(-8,-160,16,22),Color("171726"));draw_rect(Rect2(-8,-160,16,22),Color.WHITE,false,1)
	if game.stage_index==4:
		for n in range(4):draw_circle(Vector2(-30+n*20,-220),5,Color("ffcd73") if n<wave else Color("444b5a"))
	var text:=hint
	if game.stage_index==3 and phase==2:text="BLACK CARD = REAL GOZ / "+hint
	draw_string(ThemeDB.fallback_font,Vector2(game.stage_length-625,76)-position,text,HORIZONTAL_ALIGNMENT_LEFT,610,11,Color("ffe6ad"))

func build_mesh() -> void:
	mesh=Polygon2D.new();mesh.texture=sprite.texture;mesh.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	var size:=sprite.texture.get_size()
	var uv:=PackedVector2Array()
	for row in range(7):
		for col in range(13):
			var point:=Vector2(size.x*col/12.0,size.y*row/6.0)
			uv.append(point);rest_vertices.append(point-size/2)
	for row in range(6):
		for col in range(12):
			var a:=row*13+col
			mesh_indices.append(PackedInt32Array([a,a+1,a+14]));mesh_indices.append(PackedInt32Array([a,a+14,a+13]))
	mesh.polygon=rest_vertices;mesh.uv=uv;mesh.polygons=mesh_indices
	add_child(mesh);sprite.visible=false
	update_mesh()

func choose_movement() -> void:
	# Shift between attacks; all telegraphed hazards stay locked in world space.
	var sign_x:=1.0 if pattern%2==0 else -1.0
	match game.stage_index:
		0:movement_target=anchor+Vector2(-45+sign_x*40,0)
		1:movement_target=anchor+Vector2(-55+sign_x*30,0)
		2:movement_target=anchor+Vector2(-50+sign_x*35,0)
		3:movement_target=anchor+Vector2(sign_x*22,0)
		4:movement_target=anchor+Vector2(sign_x*20,0)
	movement_target.x=clampf(movement_target.x,game.stage_length-530,game.stage_length-95)

func update_movement(delta: float) -> void:
	if state in ["INTRO","RECOVER"]:
		position=position.move_toward(movement_target,delta*(32 if game.stage_index==2 else 48))

func update_mesh() -> void:
	if mesh==null:return
	mesh.texture=sprite.texture;mesh.scale=sprite.scale
	mesh.position=sprite.position
	mesh.modulate=sprite.modulate
	var points:=rest_vertices.duplicate()
	var kick:=sin(clampf(attack_motion/.65,0,1)*PI)
	for i in range(points.size()):
		var v:Vector2=rest_vertices[i]
		var top:=clampf(-v.y/100.0+.5,0,1)
		match game.stage_index:
			0: # Snake vertebrae undulate with a delayed wave, head retracts to fire.
				points[i].x+=sin(clock*2.6+v.y*.035)*4*top+kick*9*top
				points[i].y+=sin(clock*2.2+v.x*.025)*2*top
			1: # Weight on feet, breathing belly, head anticipation and landing squash.
				points[i].y-=absf(sin(clock*2))*2.5*top+kick*8*top
				points[i].x+=v.x*.012*sin(clock*2.0)*(1-top)
			2: # Heavy grounded chassis, upper antenna/turret recoil.
				points[i].x+=kick*6*top
				points[i].y+=sin(clock*8)*.6*(1-top)
			3: # Floating magician with trailing cloth.
				points[i].x+=sin(clock*3+v.y*.045)*3*(1-top)
				points[i].y+=sin(clock*1.7)*5+kick*5*top
			4: # Levitation and breathing armored core panels.
				points[i].x+=signf(v.x)*sin(clock*1.6)*2.5
				points[i].y+=sin(clock*1.8)*4+sin(clock*3+absf(v.x)*.025)*2
	mesh.polygon=points

