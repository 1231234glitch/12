extends CharacterBody2D

var game: Node2D
var faction := "helmet"
var kind := 0
var hp := 1.0
var maximum_hp := 1.0
var facing := -1
var state := "PATROL"
var timer := 0.0
var hurt := 0.0
var clock := 0.0
var dead := false
var home := 0.0
var sprite: Sprite2D
var frames: Array = []
var death_frames: Array = []
var death_time := 0.0
var death_direction := 1.0
var gait := 0.0
var recoil := 0.0
var walk_frames: Array=[]
var visual_id := "helmet"
var is_tank := false
var body_size := Vector2(28,48)
var base_sprite_y := -40.0
var muzzle_height := -32.0

func _ready() -> void:
	visual_id=str(game.enemy_stats.types[kind].get("visual","helmet"))
	is_tank=visual_id in ["tank","railgun"]
	faction="automata" if visual_id in ["military","shield","tank","railgun"] else "helmet"
	body_size=Vector2(108,44) if is_tank else Vector2(28,48)
	home = position.x
	hp = float(game.enemy_stats.types[kind].hp)
	maximum_hp = hp
	collision_layer = 4
	collision_mask = 1
	var collision := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = body_size
	collision.shape = shape
	collision.position.y = -body_size.y/2
	add_child(collision)
	sprite = Sprite2D.new()
	for i in range(4): frames.append(load("res://assets/enemies_v8/%s_%d.png"%[visual_id,i]))
	for i in range(4):death_frames.append(load("res://assets/enemies_v8/%s_death_%d.png"%[visual_id,i]))
	sprite.texture = frames[0]
	sprite.position.y = base_sprite_y
	sprite.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(sprite)
	for i in range(6):
		var path:="res://assets/enemies_v9/%s_walk_%d.png"%[visual_id,i]
		if ResourceLoader.exists(path):walk_frames.append(load(path))
	timer = randf_range(.2,1.1)

func _physics_process(delta: float) -> void:
	if dead:
		death_time+=delta
		velocity.y=minf(velocity.y+900*delta,450)
		velocity.x=move_toward(velocity.x,0,180*delta)
		move_and_slide()
		sprite.texture=death_frames[0 if death_time<.1 else (1 if death_time<.25 else (2 if death_time<.48 else 3))]
		sprite.position.y=base_sprite_y
		sprite.rotation=0
		sprite.modulate=Color(1.6,1.6,1.6,1) if death_time<.05 else Color(1,1,1,clampf((.95-death_time)/.25,0,1))
		if death_time>=.95:queue_free()
		return
	if dead or not is_instance_valid(game.player) or game.player.hp<=0: return
	clock += delta
	recoil=maxf(0,recoil-delta)
	var previous_speed:=velocity.x
	hurt = maxf(0,hurt-delta)
	var distance: Vector2 = game.player.position-position
	if absf(distance.x)>760:
		return
	facing = 1 if distance.x > 0 else -1
	sprite.flip_h = facing > 0
	velocity.y = minf(velocity.y+1050*delta,600)
	timer -= delta
	var query := PhysicsRayQueryParameters2D.create(position+Vector2(0,-25),game.player.position+Vector2(0,-25),1)
	var visible_player := get_world_2d().direct_space_state.intersect_ray(query).is_empty()
	if state == "PATROL":
		velocity.x = sin(clock*.6)*(12 if is_tank else 25)
		if absf(distance.x)<(420 if is_tank else 320) and visible_player:
			state = "DETECT"; timer = .3
	elif state == "DETECT":
		velocity.x = 0
		if timer <= 0: state = "CHASE"
	elif state == "CHASE":
		var melee := kind in [1,7]
		velocity.x = facing*(100 if melee else (22 if is_tank else 38)) if absf(distance.x)>(30 if melee else (280 if is_tank else 190)) else 0.0
		if absf(distance.x)<(40 if melee else (430 if is_tank else 300)) and visible_player:
			state = "ATTACK"; timer = 1.0 if is_tank else (.75 if kind in [2,6,7] else .45)
	elif state == "ATTACK":
		velocity.x = 0
		if timer <= 0:
			attack(distance)
			state = "RECOVER"; timer = 2.2 if is_tank else (1.5 if kind in [2,6] else 1.05)
	elif state == "RECOVER":
		velocity.x = 0
		if timer <= 0: state = "CHASE"
	if hurt > 0: velocity.x *= .3
	# Stable lane spacing prevents stacked enemies shooting from one position.
	for other in game.enemies:
		if other != self and is_instance_valid(other) and not other.dead and absf(other.position.y-position.y)<30:
			var dx: float = position.x-other.position.x
			if absf(dx)<(135 if is_tank or other.is_tank else 40): velocity.x += (1 if dx>=0 else -1)*30
	velocity.x=move_toward(previous_speed,velocity.x,(160 if is_tank else 420)*delta)
	move_and_slide()
	gait+=absf(velocity.x)*delta/(9.0 if is_tank else 8.0)
	if recoil>0:sprite.texture=frames[3]
	elif absf(velocity.x)>4 and not walk_frames.is_empty():sprite.texture=walk_frames[int(gait)%walk_frames.size()]
	else:sprite.texture=frames[[0,1,2,1][int(gait)%4] if absf(velocity.x)>4 else 0]
	var bounce:=absf(sin(gait*PI/3))*(.6 if is_tank else 1.0) if absf(velocity.x)>4 else sin(clock*2)*.35
	sprite.position=Vector2(-facing*recoil*(14 if is_tank else 8),base_sprite_y-bounce)
	sprite.rotation=0 if is_tank else clampf(-velocity.x*.0003,-.025,.025)
	if is_tank and hp<maximum_hp*.45 and int(clock*10)!=int((clock-delta)*10):game.particles(position+Vector2(10,-45),Color("59616c"),1,12)
	sprite.modulate = Color("ffb7c7") if hurt > 0 else Color.WHITE
	if position.y > 450: die()
	queue_redraw()

func attack(distance: Vector2) -> void:
	recoil=.22
	game.sound("enemy_shot")
	if is_tank:
		var origin:=position+Vector2(facing*65,muzzle_height)
		var aim:Vector2=(game.player.position+Vector2(0,-20)-origin).normalized()
		game.fire(origin,aim*(240 if visual_id=="railgun" else 150),false,1)
		game.particles(origin,Color("8ae4ff") if visual_id=="railgun" else Color("ffb267"),12,95)
		game.sound("explosion");game.shake=2
		return
	if kind == 7:
		game.explode(position+Vector2(0,-20),58,2,self)
		die(); return
	if kind == 1:
		if distance.length()<60: game.player.take_damage(1)
		return
	var direction := (distance+Vector2(0,-20)).normalized()
	var count := 3 if kind in [2,5,6] else 1
	for n in range(count):
		game.fire(position+Vector2(facing*30,muzzle_height),direction.rotated((n-(count-1)/2.0)*.16)*170,false,1)

func take_damage(amount: float, direction: Vector2 = Vector2.RIGHT) -> void:
	if dead or amount<=0: return
	# Infantry dies in one hit; vehicles retain armor durability.
	death_direction=1 if direction.x>=0 else -1
	hp=maxf(0,hp-amount) if is_tank else 0.0
	hurt = .12
	game.particles(position+Vector2(0,-25),Color("e5b6fa"),4,70)
	game.sound("armor_hit" if faction=="automata" or kind==3 else "hit")
	if hp <= 0: die()

func die() -> void:
	if dead: return
	dead = true
	hp=0
	collision_layer = 0
	collision_mask=1
	velocity=Vector2.ZERO if is_tank else Vector2(death_direction*80,-65)
	if is_tank:game.explode(position+Vector2(0,-25),65,0,self)
	game.score += 100+kind*25
	game.particles(position+Vector2(0,-25),Color("b9b8d0") if faction == "automata" else Color("ee927f"),14,110)
	game.sound("robot_down" if faction=="automata" else "enemy_down")
	if randf()<float(game.enemy_stats.drop_chance): game.spawn_item(position, randi()%4)
	game.enemies.erase(self)
	queue_redraw()

func _draw() -> void:
	if dead:return
	if state=="ATTACK" and is_tank:
		draw_line(Vector2(facing*60,muzzle_height),Vector2(facing*190,muzzle_height),Color(1,.3,.2,.4),1)
	if state == "ATTACK" and timer<.12:
		draw_rect(Rect2(facing*(65 if is_tank else 31)-2,muzzle_height-2,5,4),Color("ffda72"))


func damage_rect() -> Rect2:
	return Rect2(position+Vector2(-body_size.x/2,-body_size.y),body_size)

