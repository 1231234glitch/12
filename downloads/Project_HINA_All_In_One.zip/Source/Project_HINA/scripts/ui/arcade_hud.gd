extends Control
## Native-resolution bitmap typography. Draws in logical pixels, independent of camera shake.
var game: Node
const INK = Color("152733")
const WHITE = Color("f4f3d9")
const GOLD = Color("ffd355")
const GLYPHS = {
"0":["01110","11011","11011","11011","11011","11011","01110"],
"1":["00100","01100","00100","00100","00100","00100","01110"],
"2":["01110","11011","00011","00110","01100","11000","11111"],
"3":["11110","00011","00011","01110","00011","00011","11110"],
"4":["00011","00111","01111","11011","11111","00011","00011"],
"5":["11111","11000","11000","11110","00011","00011","11110"],
"6":["01110","11000","11000","11110","11011","11011","01110"],
"7":["11111","00011","00110","00110","01100","01100","01100"],
"8":["01110","11011","11011","01110","11011","11011","01110"],
"9":["01110","11011","11011","01111","00011","00011","01110"],
"A":["01110","11011","11011","11111","11011","11011","11011"],
"B":["11110","11011","11011","11110","11011","11011","11110"],
"C":["01111","11000","11000","11000","11000","11000","01111"],
"D":["11110","11011","11011","11011","11011","11011","11110"],
"E":["11111","11000","11000","11110","11000","11000","11111"],
"F":["11111","11000","11000","11110","11000","11000","11000"],
"G":["01111","11000","11000","11011","11011","11011","01111"],
"H":["11011","11011","11011","11111","11011","11011","11011"],
"I":["11111","00100","00100","00100","00100","00100","11111"],
"J":["00111","00011","00011","00011","11011","11011","01110"],
"K":["11011","11010","11100","11000","11100","11010","11011"],
"L":["11000","11000","11000","11000","11000","11000","11111"],
"M":["10001","11011","11111","10101","10001","10001","10001"],
"N":["11001","11001","11101","11111","11011","11011","11001"],
"O":["01110","11011","11011","11011","11011","11011","01110"],
"P":["11110","11011","11011","11110","11000","11000","11000"],
"Q":["01110","11011","11011","11011","11111","00110","00011"],
"R":["11110","11011","11011","11110","11100","11010","11011"],
"S":["01111","11000","11000","01110","00011","00011","11110"],
"T":["11111","00100","00100","00100","00100","00100","00100"],
"U":["11011","11011","11011","11011","11011","11011","01110"],
"V":["11011","11011","11011","11011","11011","01110","00100"],
"W":["10001","10001","10001","10101","11111","11011","10001"],
"X":["11011","11011","01110","00100","01110","11011","11011"],
"Y":["11011","11011","01110","00100","00100","00100","00100"],
"Z":["11111","00011","00110","00100","01100","11000","11111"],
"-":["00000","00000","00000","11111","00000","00000","00000"],
"=":["00000","11111","00000","11111","00000","00000","00000"],
"/":["00001","00011","00110","00100","01100","11000","10000"],
":" :["00000","00100","00100","00000","00100","00100","00000"]
}

func _ready() -> void:
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func _process(_delta: float) -> void: queue_redraw()

func lettering(text: String, at: Vector2, scale_px: int=1, color: Color=WHITE) -> void:
	# Outline and offset shadow remain one logical pixel at every integer scale.
	for offset in [Vector2(2,2),Vector2(-1,0),Vector2(1,0),Vector2(0,-1),Vector2(0,1)]:
		glyphs(text,at+offset,scale_px,INK,false)
	glyphs(text,at,scale_px,color,true)

func glyphs(text: String, at: Vector2, s: int, color: Color, shade: bool) -> void:
	var x:=at.x
	for ch in text:
		if GLYPHS.has(ch):
			var rows: Array=GLYPHS[ch]
			for y in range(7):
				for col in range(5):
					if rows[y][col]=="1":
						var tint:=color.darkened(.28) if shade and y>=4 else color
						draw_rect(Rect2(x+col*s,at.y+y*s,s,s),tint)
		x+=6*s

func plate(rect: Rect2) -> void:
	draw_rect(rect,Color("173747a0"))
	draw_rect(rect,Color("a1b7b8"),false,1)
	draw_line(rect.position+Vector2(1,rect.size.y-2),rect.end-Vector2(2,2),Color("263b45"),1)
	for x in [rect.position.x+2,rect.end.x-3]:draw_rect(Rect2(x,rect.position.y+2,1,1),WHITE)

func _draw() -> void:
	if game==null:return
	if game.mode=="menu":
		lettering("OPERATION GEHENNA",Vector2(224,209),2,GOLD)
		lettering("1 INSERT COIN   CREDIT %02d"%game.credits,Vector2(235,346),1,WHITE)
		return
	if not is_instance_valid(game.player):return
	# Left player / ammunition, centered clock, right high-score and mission.
	lettering("%07d"%game.score,Vector2(19,10),2)
	lettering("HINA",Vector2(20,30),1)
	lettering("1UP=%d"%maxi(0,game.lives),Vector2(20,42),2,GOLD)
	plate(Rect2(146,10,118,36))
	lettering("ARMS BOMB",Vector2(154,14),1)
	# Infinity symbol indicates the actual unlimited magazine.
	var loop_points:=PackedVector2Array([Vector2(158,32),Vector2(164,27),Vector2(170,27),Vector2(182,37),Vector2(188,37),Vector2(194,32),Vector2(188,27),Vector2(182,27),Vector2(170,37),Vector2(164,37),Vector2(158,32)])
	draw_polyline(loop_points,GOLD,2,false)
	lettering("%02d"%game.player.stock,Vector2(220,26),2,GOLD)
	lettering("TIME",Vector2(299,5),1)
	var timer_color: Color=GOLD if game.mission_time>10 or int(game.clock*4)%2==0 else Color("ff704f")
	lettering("%02d"%clampi(ceili(game.mission_time),0,99),Vector2(292,17),5,timer_color)
	lettering("HI-SCORE",Vector2(475,10),1,GOLD)
	lettering("%07d"%maxi(game.high_score,game.score),Vector2(472,23),2)
	lettering("MISSION %02d"%(game.stage_index+1),Vector2(474,44),1)
	lettering("COIN %02d  1 ADD"%game.coins_inserted,Vector2(18,343),1)
	lettering("J FIRE/KICK K JUMP  L BOMB",Vector2(386,343),1)
	if game.clear_timer>0:clear_card()
	if game.mode=="continue":continue_card()
	if game.coin_flash>0:lettering("COIN IN / 1UP",Vector2(246,78),2,GOLD)

func clear_card() -> void:
	var elapsed:float=game.CLEAR_DURATION-game.clear_timer
	var enter:=clampf(elapsed/.5,0,1)
	var ease:=1-pow(1-enter,3)
	var exit_alpha:=clampf(game.clear_timer/.35,0,1)
	var slide:float=(1-ease)*-650
	draw_rect(Rect2(0,0,640,360),Color(0.02,.035,.07,.66*ease*exit_alpha))
	draw_rect(Rect2(slide,105,640,165),Color(.04,.075,.12,.94*exit_alpha))
	for y in [104,268]:
		draw_line(Vector2(slide,y),Vector2(slide+640,y),Color("ffc746"),2)
		for n in range(27):
			var x:=slide+n*25
			draw_colored_polygon(PackedVector2Array([Vector2(x,y+3),Vector2(x+11,y+3),Vector2(x+5,y+8),Vector2(x-6,y+8)]),Color("a8792c"))
	var title:="STAGE %d"%(game.stage_index+1)
	lettering(title,Vector2(320-title.length()*12+slide,119),4,WHITE)
	var word:="CLEAR"
	for i in range(5):
		var delay:float=maxf(0,elapsed-.22-i*.065)
		var progress:=clampf(delay/.32,0,1)
		var bounce:float=sin(progress*PI)*-11
		var pos:=Vector2(158+i*66+slide,160+bounce+(1-progress)*-45)
		if delay<=0:continue
		for offset in [Vector2(5,6),Vector2(-2,0),Vector2(2,0),Vector2(0,-2),Vector2(0,2)]:glyphs(word[i],pos+offset,11,Color("090e19"),false)
		# Gold-to-orange bevel in individual pixel rows, plus moving white glint.
		var rows: Array=GLYPHS[word[i]]
		for y in range(7):
			var shade:Color=Color("fff7bd").lerp(Color("e88a22"),y/6.0)
			for col in range(5):
				if rows[y][col]!="1":continue
				var rect:=Rect2(pos+Vector2(col*11,y*11),Vector2(11,11))
				draw_rect(rect,shade)
				if y==0 or rows[y-1][col]=="0":draw_rect(Rect2(rect.position,Vector2(11,2)),Color("ffffe1"))
				if y==6 or rows[y+1][col]=="0":draw_rect(Rect2(rect.position+Vector2(0,9),Vector2(11,2)),Color("a74c1c"))
				var glint:=fposmod(elapsed*260,900)-100
				if absf(rect.position.x-glint)<15:draw_rect(rect,Color(1,1,.9,.45))
	lettering("MISSION COMPLETE",Vector2(225+slide,247),2,WHITE)
	if elapsed>.9:
		lettering("SCORE %07d"%game.score,Vector2(242,292),2,GOLD)
		lettering("NEXT OPERATION" if game.stage_index<4 else "ALL OPERATIONS COMPLETE",Vector2(278 if game.stage_index<4 else 250,321),1,WHITE)
	if elapsed<.14:draw_rect(Rect2(0,0,640,360),Color(1,.95,.7,(1-elapsed/.14)*.6))

func continue_card() -> void:
	draw_rect(Rect2(0,0,640,360),Color(0,.02,.05,.72))
	lettering("CONTINUE?",Vector2(160,98),6,GOLD)
	lettering("%02d"%int(ceil(game.continue_timer)),Vector2(267,164),9,WHITE)
	lettering("PRESS 1 TO INSERT COIN",Vector2(190,254),2,GOLD)
	lettering("1 COIN = 1 LIFE / RESUME HERE",Vector2(236,282),1,WHITE)
	lettering("ESC TO END",Vector2(290,308),1,WHITE)

