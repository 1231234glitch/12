extends Node2D

const PlayerScript = preload("res://scripts/actors/player.gd")
const EnemyScript = preload("res://scripts/actors/enemy.gd")
const BossScript = preload("res://scripts/actors/boss.gd")
const STAGE_NAMES = ["COASTAL LANDING", "DESERT RELIC", "IRON RAILWAY", "NIGHT GEHENNA", "REACTOR ABYSS"]
const SAVE_PATH = "user://hina_save.json"
var player: CharacterBody2D
var camera: Camera2D
var world: Node2D
var hud: CanvasLayer
var hud_label: Label
var arcade_hud: Control
var mission_time := 99.0
var banner: Label
var boss_label: Label
var menu_panel: PanelContainer
var menu_box: VBoxContainer
var menu_scroll: ScrollContainer
var weapon_stats: Dictionary = {}
var enemy_stats: Dictionary = {}
var stage_data: Array = []
var mode := "menu"
var stage_index := 0
var stage_length := 2800.0
var lives := 3
var coins_inserted := 0
var credits := 0
var continue_timer := 0.0
var title_time := 0.0
var sector := 0
var coin_flash := 0.0
var score := 0
var unlocked := 1
var high_score := 0
var respawn_position := Vector2(80,310)
var boss_active := false
var boss: Node2D
var enemies: Array = []
var bullets: Array = []
var particles_pool: Array = []
var items: Array = []
var objects: Array = []
var platforms: Array = []
var danger: Array = []
var waves: Array = []
var explosions: Array = []
var shake := 0.0
var clock := 0.0
var special_fx := 0.0
var special_origin := Vector2.ZERO
var special_facing := 1
var message_timer := 0.0
var death_timer := 0.0
const CLEAR_DURATION := 4.8
var clear_timer := 0.0
var music_tail: AudioStreamPlayer
var music_fade: Tween
var prop_textures: Array=[]
var debris: Array=[]
var sounds: Dictionary = {}
var audio_pool: Array = []
var audio_index := 0
var bgm: AudioStreamPlayer
var music_tracks: Dictionary = {}
var music_track := ""
var sfx_events: Dictionary = {}
var settings := {"master": .8, "sfx": .75, "music": .65, "shake": true, "fullscreen": false, "scale": 2, "keys": {}}
var coast_texture = preload("res://assets/backgrounds/coast.png")
var level_textures: Array = []
var ground_textures: Array = []
var title_texture = preload("res://assets/backgrounds_v9/title.png")
var sand_texture = preload("res://assets/backgrounds/sand.png")
var ex_textures: Array = []
var pending_bind := ""
var test_mode := false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	get_tree().auto_accept_quit = false
	test_mode = "--self-test" in OS.get_cmdline_user_args()
	load_save()
	weapon_stats = JSON.parse_string(FileAccess.get_file_as_string("res://data/weapon_stats.json"))
	enemy_stats = JSON.parse_string(FileAccess.get_file_as_string("res://data/enemy_stats.json"))
	stage_data = JSON.parse_string(FileAccess.get_file_as_string("res://data/stages.json"))
	for i in range(5):
		level_textures.append(load("res://assets/backgrounds_v6/stage_%d.png"%i))
		ground_textures.append(load("res://assets/backgrounds_v6/ground_%d.png"%i))
	configure_input()
	for i in range(4): ex_textures.append(load("res://assets/effects/ex_%d.png"%i))
	setup_audio()
	camera = Camera2D.new()
	camera.position = Vector2(320,180)
	camera.limit_left = 0; camera.limit_top = 0; camera.limit_bottom = 360
	add_child(camera)
	setup_ui()
	apply_settings()
	if test_mode:
		start_game()
	else:
		show_main_menu()

func configure_input() -> void:
	var bindings := {"left":[KEY_A,KEY_LEFT],"right":[KEY_D,KEY_RIGHT],"up":[KEY_W,KEY_UP],"down":[KEY_S,KEY_DOWN],"jump":[KEY_K],"shoot":[KEY_J],"special":[KEY_L]}
	for action in bindings:
		if not InputMap.has_action(action): InputMap.add_action(action)
		InputMap.action_erase_events(action)
		var keys: Array = bindings[action]
		if settings.keys.has(action): keys = [int(settings.keys[action])]
		for key in keys:
			var event := InputEventKey.new()
			event.physical_keycode = key
			InputMap.action_add_event(action,event)

func setup_audio() -> void:
	for bus_name in ["Music","SFX"]:
		if AudioServer.get_bus_index(bus_name)<0:
			AudioServer.add_bus()
			AudioServer.set_bus_name(AudioServer.bus_count-1,bus_name)
	if AudioServer.get_bus_effect_count(0)==0:
		var limiter:=AudioEffectLimiter.new()
		limiter.ceiling_db=-.5
		AudioServer.add_bus_effect(0,limiter)
	for i in range(12):prop_textures.append(load("res://assets/props_v9/prop_%02d.png"%i))
	for name in ["shot","enemy_shot","hit","armor_hit","ricochet","footstep","jump","land","explosion","charge","special","pickup","boss","clear","death","respawn","ui","kick_swing","kick_hit","enemy_down","robot_down"]:
		sounds[name]=load("res://assets/sounds/"+name+".wav")
	for n in range(24):
		var audio:=AudioStreamPlayer.new()
		audio.bus="SFX";add_child(audio);audio_pool.append(audio)
	for name in ["coast","desert","rail","night","reactor","boss","menu"]:
		var stream=load("res://assets/sounds/bgm_"+name+".ogg")
		stream.loop=true
		music_tracks[name]=stream
	bgm=AudioStreamPlayer.new();bgm.bus="Music";add_child(bgm)
	music_tail=AudioStreamPlayer.new();music_tail.bus="Music";add_child(music_tail)
	for n in range(1,6):sounds["stage_clear_%d"%n]=load("res://assets/sounds/stage_clear_%d.wav"%n)

func play_music(track: String) -> void:
	if music_track==track and bgm.playing:return
	if music_fade!=null and music_fade.is_valid():music_fade.kill()
	var old_stream=bgm.stream
	var old_position:=bgm.get_playback_position()
	var was_playing:=bgm.playing
	music_tail.stop()
	if was_playing and old_stream!=null:
		music_tail.stream=old_stream;music_tail.volume_db=bgm.volume_db;music_tail.play(old_position)
	music_track=track;bgm.stream=music_tracks[track];bgm.volume_db=-36;bgm.play()
	music_fade=create_tween().set_parallel(true)
	music_fade.tween_property(bgm,"volume_db",0.0,.4)
	music_fade.tween_property(music_tail,"volume_db",-60.0,.4)
	music_fade.chain().tween_callback(music_tail.stop)

func sound(name: String) -> void:
	if not sounds.has(name):return
	var audio: AudioStreamPlayer=audio_pool[audio_index]
	audio_index=(audio_index+1)%audio_pool.size()
	audio.stream=sounds[name]
	var gains:={"footstep":.12,"land":.35,"jump":.32,"shot":.55,"enemy_shot":.32,"ricochet":.22,"armor_hit":.38,"hit":.42,"ui":.22,"pickup":.4,"charge":.48,"explosion":.6,"special":.7}
	audio.volume_db=linear_to_db(float(gains.get(name,.55)))
	audio.pitch_scale=randf_range(.96,1.04) if name in ["shot","footstep","enemy_shot","explosion"] else 1.0
	audio.play()
	sfx_events[name]=int(sfx_events.get(name,0))+1

func reset_audio() -> void:
	settings.master=.8;settings.sfx=.75;settings.music=.65
	apply_settings()
	if not bgm.playing:play_music("boss" if boss_active else ("menu" if mode=="menu" else str(stage_data[stage_index].music)))
	sound("respawn");save_game()

func setup_ui() -> void:
	hud = CanvasLayer.new(); add_child(hud)
	arcade_hud=preload("res://scripts/ui/arcade_hud.gd").new()
	arcade_hud.game=self;hud.add_child(arcade_hud)
	hud_label = Label.new(); hud_label.position = Vector2(16,12)
	hud_label.add_theme_font_size_override("font_size",13)
	hud_label.add_theme_color_override("font_shadow_color",Color("142d39"))
	hud_label.add_theme_constant_override("shadow_offset_x",1)
	hud_label.add_theme_constant_override("shadow_offset_y",1)
	hud.add_child(hud_label)
	hud_label.hide()
	banner = Label.new(); banner.position = Vector2(70,75); banner.size = Vector2(500,70)
	banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	banner.add_theme_font_size_override("font_size",20); hud.add_child(banner)
	boss_label = Label.new(); boss_label.position = Vector2(185,335)
	boss_label.add_theme_font_size_override("font_size",12); hud.add_child(boss_label)
	boss_label.hide()
	menu_panel = PanelContainer.new()
	menu_panel.position = Vector2(136,96); menu_panel.size = Vector2(368,233)
	var style := StyleBoxFlat.new(); style.bg_color = Color("18323bef")
	style.border_color = Color("bac2a8"); style.set_border_width_all(2)
	style.content_margin_left = 22; style.content_margin_right = 22
	style.content_margin_top = 15; style.content_margin_bottom = 15
	menu_panel.add_theme_stylebox_override("panel",style)
	hud.add_child(menu_panel)
	menu_box = VBoxContainer.new(); menu_box.add_theme_constant_override("separation",6)
	menu_scroll = ScrollContainer.new()
	menu_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	menu_scroll.follow_focus = true
	menu_panel.add_child(menu_scroll)
	menu_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	menu_scroll.add_child(menu_box)

func reset_menu(title: String) -> void:
	menu_panel.position=Vector2(136,96);menu_panel.size=Vector2(368,233)
	menu_panel.modulate=Color.WHITE
	menu_box.add_theme_constant_override("separation",6)
	var standard:=StyleBoxFlat.new();standard.bg_color=Color("18323bef")
	standard.border_color=Color("bac2a8");standard.set_border_width_all(2)
	standard.content_margin_left=22;standard.content_margin_right=22
	standard.content_margin_top=15;standard.content_margin_bottom=15
	menu_panel.add_theme_stylebox_override("panel",standard)
	for child in menu_box.get_children():
		menu_box.remove_child(child); child.queue_free()
	var heading := Label.new(); heading.text = title
	heading.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	heading.add_theme_font_size_override("font_size",18)
	menu_box.add_child(heading)
	menu_scroll.scroll_vertical = 0
	menu_panel.show()

func add_button(text: String, callback: Callable, disabled := false) -> Button:
	var button := Button.new(); button.text = text
	for state_name in ["normal","hover","pressed","focus"]:
		var style:=StyleBoxFlat.new()
		style.bg_color=Color("48524b") if state_name in ["hover","focus"] else Color("263d42")
		style.border_color=Color("ffd355") if state_name in ["hover","focus"] else Color("718980")
		style.set_border_width_all(1);style.content_margin_top=2;style.content_margin_bottom=2
		button.add_theme_stylebox_override(state_name,style)
	button.add_theme_font_size_override("font_size",13)
	button.disabled = disabled; button.pressed.connect(func(): sound("ui"); callback.call())
	menu_box.add_child(button)
	if menu_box.get_child_count() == 2: button.grab_focus()
	return button

func show_main_menu() -> void:
	play_music("menu")
	get_tree().paused = true
	mode = "menu"
	hud_label.text = ""
	banner.text = ""; boss_label.text = ""
	reset_menu("")
	menu_box.get_child(0).hide()
	menu_panel.position=Vector2(208,230);menu_panel.size=Vector2(224,106)
	menu_box.add_theme_constant_override("separation",0)
	var title_style:=StyleBoxEmpty.new()
	menu_panel.add_theme_stylebox_override("panel",title_style)
	add_button("출격 / START",start_game)
	add_button("작전 선택 / STAGE %d"%unlocked,func(): start_game(unlocked-1))
	add_button("설정 / OPTIONS",func(): show_settings("menu"))
	add_button("음악 / CREDITS",show_music_credits)
	add_button("종료 / EXIT",exit_game)
	for button in menu_box.get_children():
		if button is Button:
			button.add_theme_font_size_override("font_size",12)
			for state_name in ["normal","hover","pressed","focus"]:
				var style:=StyleBoxFlat.new();style.bg_color=Color(0,0,0,0)
				if state_name in ["focus","hover"]:
					style.bg_color=Color(.75,.55,.18,.22);style.border_color=Color("dac17c");style.border_width_left=2;style.border_width_right=2
				button.add_theme_stylebox_override(state_name,style)

func start_game(index := 0) -> void:
	score = 0; lives = 3+credits;credits=0;continue_timer=0
	stage_index = clampi(index,0,stage_data.size()-1)
	load_stage()

func load_stage() -> void:
	play_music(stage_data[stage_index].music)
	get_tree().paused = false; mode = "playing"
	menu_panel.hide(); boss_label.text = ""
	if is_instance_valid(world):
		remove_child(world); world.queue_free()
	world = Node2D.new(); world.process_mode = Node.PROCESS_MODE_PAUSABLE; add_child(world)
	enemies.clear(); bullets.clear(); items.clear(); objects.clear(); platforms.clear(); danger.clear(); particles_pool.clear()
	boss = null; boss_active = false
	stage_length = float(stage_data[stage_index].length)
	camera.limit_right = int(stage_length)
	camera.position = Vector2(320,180)
	camera.reset_smoothing()
	special_fx = 0; death_timer = 0; clear_timer = 0
	mission_time=99.0;sector=0
	make_platform(Rect2(0,310,stage_length,70))
	for rect_data in stage_data[stage_index].platforms:
		make_platform(Rect2(rect_data[0],rect_data[1],rect_data[2],rect_data[3]))
	waves=stage_data[stage_index].waves.duplicate(true)
	explosions.clear()
	player = PlayerScript.new(); player.game = self; player.position = Vector2(80,270); player.invulnerable=1.5
	world.add_child(player)
	for n in range(3):spawn_enemy(430+n*105,int(stage_data[stage_index].opening[n]))
	debris.clear()
	for prop in stage_data[stage_index].props:
		objects.append({"rect":Rect2(float(prop.x),310-float(prop.height),float(prop.width),float(prop.height)),"hp":3.0,"barrel":int(prop.style)==1,"style":int(prop.style),"dead":false})
	for n in range(4): spawn_item(Vector2(520+n*(stage_length-1000)/4,250),n)
	message("STAGE %d / %s"%[stage_index+1,STAGE_NAMES[stage_index]],2.8)

func spawn_enemy(x: float, kind: int) -> void:
	var enemy=EnemyScript.new();enemy.game=self;enemy.kind=kind
	enemy.faction="helmet" if kind<4 else "automata"
	var floor_y:=310.0
	for platform in platforms:
		if x>=platform.body.position.x and x<=platform.body.position.x+platform.size.x:
			floor_y=minf(floor_y,platform.body.position.y)
	enemy.position=Vector2(x,floor_y-2);world.add_child(enemy);enemies.append(enemy)

func update_waves() -> void:
	if boss_active:return
	for wave in waves:
		if wave.get("spawned",false) or player.position.x<float(wave.trigger):continue
		wave["spawned"]=true
		for n in range(wave.kinds.size()):
			spawn_enemy(minf(float(wave.spawn_x)+n*155,stage_length-640),int(wave.kinds[n]))

func make_platform(rect: Rect2,moving := false) -> void:
	var terrain: PhysicsBody2D = AnimatableBody2D.new() if moving else StaticBody2D.new()
	terrain.position = rect.position
	terrain.collision_layer = 1; terrain.collision_mask = 0
	var collision := CollisionShape2D.new(); var shape := RectangleShape2D.new()
	shape.size = rect.size; collision.shape = shape; collision.position = rect.size/2
	terrain.add_child(collision); world.add_child(terrain)
	if moving: terrain.sync_to_physics = false
	platforms.append({"body":terrain,"size":rect.size,"origin":rect.position,"moving":moving})

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.physical_keycode in [KEY_1,KEY_KP_1]:
		if pending_bind=="":
			insert_coin();get_viewport().set_input_as_handled()

func insert_coin() -> void:
	coins_inserted+=1;coin_flash=1.2;sound("pickup")
	if mode in ["playing","pause"]:
		lives+=1
	elif mode=="continue":
		lives+=1;continue_timer=0;mode="playing";menu_panel.hide();get_tree().paused=false;respawn_player()
	elif mode=="gameover":
		credits+=1;start_game(stage_index);lives=1
	else:credits+=1

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if pending_bind != "":
			if event.physical_keycode in [KEY_1,KEY_KP_1]:
				reset_menu("1번은 코인 전용입니다. 다른 키를 누르세요.");return
			settings.keys[pending_bind] = event.physical_keycode
			pending_bind = ""; configure_input(); save_game(); show_keys()
			get_viewport().set_input_as_handled(); return
		if event.keycode == KEY_ESCAPE:
			if mode == "playing": show_pause()
			elif mode == "pause": resume_game()
			elif mode == "continue":finish_game_over()

func show_pause() -> void:
	mode = "pause"; get_tree().paused = true
	reset_menu("일시정지")
	add_button("계속하기",resume_game)
	add_button("스테이지 재시작",func(): load_stage())
	add_button("설정",func(): show_settings("pause"))
	add_button("메인 메뉴",show_main_menu)

func resume_game() -> void:
	mode = "playing"; menu_panel.hide(); get_tree().paused = false

func show_settings(return_mode: String) -> void:
	reset_menu("설정")
	add_button("화면 모드: "+("전체 화면" if settings.fullscreen else "창 모드"),func(): settings.fullscreen=not settings.fullscreen; apply_settings(); show_settings(return_mode))
	add_button("화면 크기: %d배"%int(settings.scale),func(): settings.scale=int(settings.scale)%3+1; apply_settings(); show_settings(return_mode))
	add_button("화면 흔들림: "+("ON" if settings.shake else "OFF"),func(): settings.shake=not settings.shake; show_settings(return_mode))
	for key in ["master","sfx","music"]:
		var row := HBoxContainer.new(); menu_box.add_child(row)
		var label := Label.new(); label.text = key.to_upper(); label.custom_minimum_size.x=90
		label.add_theme_font_size_override("font_size",12); row.add_child(label)
		var slider := HSlider.new(); slider.min_value=0; slider.max_value=1; slider.step=.05
		slider.value=settings[key]; slider.custom_minimum_size.x=190; row.add_child(slider)
		slider.value_changed.connect(func(value): settings[key]=value; apply_settings())
	add_button("음향 기본값 복원 / 소리 테스트",func(): reset_audio(); show_settings(return_mode))
	add_button("키 설정",show_keys)
	add_button("뒤로",func(): save_game(); show_pause() if return_mode=="pause" else show_main_menu())

func show_keys() -> void:
	reset_menu("키 설정")
	for action in ["left","right","up","down","jump","shoot","special"]:
		var events := InputMap.action_get_events(action)
		var key_name := events[0].as_text() if events.size()>0 else "UNBOUND"
		add_button(action.to_upper()+": "+key_name,func(): pending_bind=action; reset_menu("새 키를 누르세요: "+action.to_upper()))
	add_button("기본값 복원",func(): settings.keys={}; configure_input(); show_keys())
	add_button("뒤로",func(): save_game(); show_settings("pause" if mode=="pause" else "menu"))

func apply_settings() -> void:
	for pair in [["Master","master"],["Music","music"],["SFX","sfx"]]:
		var bus:=AudioServer.get_bus_index(pair[0])
		if bus>=0:
			var value:=float(settings[pair[1]])
			AudioServer.set_bus_mute(bus,value<=.001)
			AudioServer.set_bus_volume_db(bus,linear_to_db(maxf(.001,value)))
	if DisplayServer.get_name() != "headless":
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if settings.fullscreen else DisplayServer.WINDOW_MODE_WINDOWED)
		if not settings.fullscreen: DisplayServer.window_set_size(Vector2i(640,360)*int(settings.scale))

func _physics_process(delta: float) -> void:
	clock+=delta;title_time+=delta;coin_flash=maxf(0,coin_flash-delta)
	if mode=="continue":
		continue_timer=maxf(0,continue_timer-delta)
		if continue_timer<=0:finish_game_over()
		queue_redraw();return
	if mode != "playing":
		queue_redraw();return
	shake = maxf(0,shake-delta*18)
	camera.offset = Vector2(randf_range(-shake,shake),randf_range(-shake,shake)) if settings.shake else Vector2.ZERO
	if death_timer > 0:
		death_timer -= delta
		player.sprite.texture=player.textures.death[0 if death_timer>.35 else 1]
		update_particles(delta)
		queue_redraw()
		if death_timer<=0:
			if lives>0: respawn_player()
			else: game_over()
		return
	if clear_timer > 0:
		clear_timer-=delta
		update_particles(delta);queue_redraw()
		if clear_timer<=0:
			if stage_index<stage_data.size()-1:
				stage_index+=1; load_stage()
			else: victory()
		return
	if message_timer>0:
		message_timer-=delta
		if message_timer<=0: banner.text=""
	mission_time=maxf(0,mission_time-delta)
	if mission_time<=0:
		player.take_damage(1,true)
		message("TIME OVER",.55)
		return
	for platform in platforms:
		if platform.moving:
			platform.body.position.y=platform.origin.y+sin(clock*1.2+platform.origin.x)*32
	if not boss_active:
		camera.position.x=maxf(camera.position.x,clampf(player.position.x+95,320,stage_length-320))
	if player.position.x>stage_length-600 and not boss_active: start_boss()
	for zone in danger:
		if zone.grow(3).has_point(player.position): player.take_damage(1)
	var next_sector:=int(player.position.x/1500)
	if next_sector>sector and not boss_active:
		sector=next_sector;mission_time=minf(99,mission_time+35);message("SECTOR %02d / TIME +35"%(sector+1),1.2)
	update_waves()
	update_debris(delta)
	update_bullets(delta)
	update_particles(delta)
	update_items(delta)
	special_fx=maxf(0,special_fx-delta)
	hud_label.text="목숨 %d   이스보셋 %d   점수 %06d\nSTAGE %d  %s"%[lives,player.stock,score,stage_index+1,STAGE_NAMES[stage_index]]
	queue_redraw()

func fire(origin: Vector2,velocity: Vector2,friendly: bool,damage: int) -> void:
	for bullet in bullets:
		if not bullet.active:
			bullet.merge({"active":true,"pos":origin,"previous":origin,"velocity":velocity,"friendly":friendly,"damage":damage,"life":float(weapon_stats.bullet_lifetime)},true)
			return
	if bullets.size()<int(weapon_stats.pool_limit):
		bullets.append({"active":true,"pos":origin,"previous":origin,"velocity":velocity,"friendly":friendly,"damage":damage,"life":float(weapon_stats.bullet_lifetime)})

func update_bullets(delta: float) -> void:
	for bullet in bullets:
		if not bullet.active: continue
		bullet.previous=bullet.pos
		var end: Vector2 = bullet.pos+bullet.velocity*delta
		var query := PhysicsRayQueryParameters2D.create(bullet.pos,end,1)
		var world_hit := get_world_2d().direct_space_state.intersect_ray(query)
		var segment_end: Vector2 = world_hit.position if not world_hit.is_empty() else end
		var closest := 2.0
		var target = null
		if bullet.friendly:
			for enemy in enemies:
				if not is_instance_valid(enemy) or enemy.dead: continue
				var hit = segment_rect_time(bullet.pos,segment_end,enemy.damage_rect())
				if hit>=0 and hit<closest: closest=hit; target=enemy
			if is_instance_valid(boss) and not boss.dead:
				var center: Vector2 = boss.collision_center()
				var hit = Geometry2D.segment_intersects_circle(bullet.pos,segment_end,center,boss.collision_radius())
				if hit>=0 and hit<closest: closest=hit; target=boss
				for raid_target in boss.targets:
					if not is_instance_valid(raid_target) or raid_target.dead:continue
					var target_hit=Geometry2D.segment_intersects_circle(bullet.pos,segment_end,raid_target.position+raid_target.center_offset,raid_target.radius)
					if target_hit>=0 and target_hit<closest:closest=target_hit;target=raid_target
			var hit_object:Dictionary={}
			for object in objects:
				if object.dead:continue
				var object_hit:=segment_rect_time(bullet.pos,segment_end,object.rect)
				if object_hit>=0 and object_hit<closest:closest=object_hit;hit_object=object;target=null
			if not hit_object.is_empty():
				hit_object.hp-=bullet.damage;bullet.active=false
				particles(bullet.pos.lerp(segment_end,closest),Color("d8be8b"),3,55)
				if hit_object.hp<=0:destroy_object(hit_object)
			elif target!=null:
				target.take_damage(bullet.damage,bullet.velocity.normalized());bullet.active=false
		else:
			var player_center: Vector2 = player.position+Vector2(0,-17)
			var radius := 10.0 if Input.is_action_pressed("down") and player.is_on_floor() else 17.0
			if Geometry2D.segment_intersects_circle(bullet.pos,segment_end,player_center,radius)>=0:
				player.take_damage(bullet.damage); bullet.active=false
		bullet.pos=end
		bullet.life-=delta
		if not world_hit.is_empty() or bullet.life<=0:
			if not world_hit.is_empty():
				particles(segment_end,Color("e0b5a2"),2,30)
				if bullet.friendly:sound("ricochet")
			bullet.active=false

func segment_intersects_rect(a: Vector2,b: Vector2,rect: Rect2) -> bool:
	if rect.has_point(a) or rect.has_point(b): return true
	var corners := [rect.position,rect.position+Vector2(rect.size.x,0),rect.end,rect.position+Vector2(0,rect.size.y)]
	for n in range(4):
		if Geometry2D.segment_intersects_segment(a,b,corners[n],corners[(n+1)%4])!=null: return true
	return false

func special_attack(origin: Vector2,facing: int) -> void:
	special_origin=origin; special_facing=facing; special_fx=.85
	shake=12; sound("special")
	var area := Rect2(origin+Vector2(0 if facing>0 else -520,-220),Vector2(520,220))
	for enemy in enemies.duplicate():
		if is_instance_valid(enemy) and in_special_cone(enemy.position+Vector2(0,-20),origin,facing):
			enemy.take_damage(20,Vector2(facing,0))
	if is_instance_valid(boss) and not boss.dead:
		for target in boss.targets.duplicate():
			if is_instance_valid(target) and not target.dead and area.has_point(target.position+target.center_offset):target.take_damage(20)
		if area.intersects(boss.weakpoint()):boss.take_damage(50)
	for object in objects:
		if not object.dead and area.intersects(object.rect): destroy_object(object)
	for n in range(10): particles(origin+Vector2(facing*(30+n*48),-60),Color("c660ff"),8,130)

func in_special_cone(point: Vector2, origin: Vector2, facing: int) -> bool:
	var offset := point-(origin+Vector2(20*facing,-31))
	var forward := offset.x*facing
	return forward>=0 and forward<=520 and absf(offset.y)<=20+forward*.28

func particles(origin: Vector2,color: Color,count: int,speed: float) -> void:
	for n in range(count):
		if particles_pool.size()>=550: break
		particles_pool.append({"pos":origin,"velocity":Vector2(randf_range(-speed,speed),randf_range(-speed,speed*.3)),"life":randf_range(.2,.65),"color":color,"size":randf_range(1,3)})

func update_particles(delta: float) -> void:
	for i in range(explosions.size()-1,-1,-1):
		explosions[i].age+=delta
		if explosions[i].age>.42:explosions.remove_at(i)
	for n in range(particles_pool.size()-1,-1,-1):
		var effect: Dictionary=particles_pool[n]
		effect.life-=delta; effect.pos+=effect.velocity*delta; effect.velocity.y+=240*delta
		if effect.life<=0: particles_pool.remove_at(n)

func spawn_item(origin: Vector2,kind: int) -> void:
	items.append({"pos":origin,"kind":kind,"clock":0.0,"active":true})

func update_items(delta: float) -> void:
	for item in items:
		if not item.active: continue
		item.clock+=delta
		if item.pos.distance_to(player.position+Vector2(0,-20))<35:
			match int(item.kind):
				0: score+=250
				1: player.stock=mini(9,player.stock+1)
				2: score+=500
				3: lives+=1
			item.active=false; sound("pickup")

func explode(origin: Vector2,radius: float,damage: int,source: Node) -> void:
	explosions.append({"pos":origin,"age":0.0,"radius":minf(radius,60)})
	particles(origin,Color("ffa25a"),32,180); shake=maxf(shake,7); sound("explosion")
	if damage<=0: return
	if is_instance_valid(player) and player.position.distance_to(origin)<radius+20: player.take_damage(damage)
	for enemy in enemies.duplicate():
		if is_instance_valid(enemy) and enemy!=source and enemy.position.distance_to(origin)<radius+25: enemy.take_damage(damage*3)
	for object in objects:
		if not object.dead and object.rect.get_center().distance_to(origin)<radius: destroy_object(object)

func destroy_object(object: Dictionary) -> void:
	if object.dead: return
	object.dead=true
	var style:=int(object.get("style",1 if object.barrel else 0))
	var texture:Texture2D=prop_textures[style]
	for n in range(6):
		debris.append({"pos":object.rect.get_center(),"velocity":Vector2(randf_range(-100,100),randf_range(-160,-65)),"angle":0.0,"spin":randf_range(-5,5),"life":1.2,"size":Vector2(10,9),"style":style,"source":Rect2(n%3*texture.get_width()/3,n/3*texture.get_height()/2,texture.get_width()/3,texture.get_height()/2)})
	var origin: Vector2=object.rect.get_center()
	if object.barrel: explode(origin,85,2,self)
	else:
		particles(origin,Color("b4a180"),12,100); spawn_item(origin,1 if randf()<.6 else 2)

func start_boss() -> void:
	play_music("boss")
	mission_time=99.0
	boss_active=true
	camera.position.x=stage_length-320
	boss=BossScript.new(); boss.game=self
	boss.position=Vector2(stage_length-125,310); world.add_child(boss)
	message("경고 / "+["비나 / 기계 뱀","페로로지라","호드","고즈","헤세드"][stage_index],2.0)

func player_died() -> void:
	if death_timer>0: return
	lives-=1; death_timer=.55; special_fx=0
	respawn_position=player.position
	if respawn_position.y>350: respawn_position=player.last_safe_position
	respawn_position.x=clampf(respawn_position.x,camera.position.x-300,stage_length-20)
	player.set_physics_process(false)
	player.sprite.modulate=Color.WHITE
	player.sprite.texture=player.textures.death[0]
	for enemy in enemies:
		if is_instance_valid(enemy): enemy.set_physics_process(false)
	if is_instance_valid(boss): boss.set_physics_process(false)
	for bullet in bullets: bullet.active=false
	sound("death"); message("RETIRE",.55)

func respawn_player() -> void:
	# Preserve world, enemy HP, boss HP, items, score and camera. Never reload stage here.
	death_timer=0
	mission_time=99.0
	player.respawn(respawn_position)
	for enemy in enemies:
		if is_instance_valid(enemy) and not enemy.dead:enemy.set_physics_process(true)
	if is_instance_valid(boss) and not boss.dead:boss.set_physics_process(true)
	message("재출격 / 2.5초 무적",.7);sound("respawn")

func stage_cleared() -> void:
	clear_timer=CLEAR_DURATION; special_fx=0
	player.invulnerable=CLEAR_DURATION+.5
	player.set_physics_process(false)
	for bullet in bullets: bullet.active=false
	for enemy in enemies:
		if is_instance_valid(enemy): enemy.set_physics_process(false)
	unlocked=mini(stage_data.size(),maxi(unlocked,stage_index+2))
	high_score=maxi(high_score,score); save_game()
	bgm.stop();music_tail.stop();sound("clear");sound("stage_clear_%d"%(stage_index+1));banner.text="";message_timer=0

func game_over() -> void:
	mode="continue";continue_timer=10.0;get_tree().paused=true
	menu_panel.hide();banner.text="";message_timer=0
	high_score=maxi(high_score,score);save_game()

func finish_game_over() -> void:
	mode="gameover";continue_timer=0;get_tree().paused=true
	reset_menu("GAME OVER / 점수 %d"%score)
	add_button("코인 투입 후 재도전 [1]",insert_coin)
	add_button("메인 메뉴",show_main_menu)

func victory() -> void:
	mode="victory"; get_tree().paused=true
	reset_menu("작전 완료")
	var label:=Label.new();label.text="점수 %d / 최고 기록 %d"%[score,high_score]
	label.add_theme_font_size_override("font_size",12);menu_box.add_child(label)
	add_button("메인 메뉴",show_main_menu)

func message(text: String,duration: float) -> void:
	banner.text=text;message_timer=duration

func save_game() -> void:
	var file:=FileAccess.open(SAVE_PATH,FileAccess.WRITE)
	if file: file.store_string(JSON.stringify({"version":3,"unlocked":unlocked,"high_score":high_score,"settings":settings}))

func load_save() -> void:
	if not FileAccess.file_exists(SAVE_PATH): return
	var parser := JSON.new()
	if parser.parse(FileAccess.get_file_as_string(SAVE_PATH)) != OK: return
	var data = parser.data
	if not data is Dictionary: return
	unlocked=clampi(int(data.get("unlocked",1)),1,5)
	high_score=maxi(0,int(data.get("high_score",0)))
	if data.get("settings") is Dictionary:
		for key in settings:
			if data.settings.has(key):
				var incoming = data.settings[key]
				if key in ["master","sfx","music","scale"] and (incoming is int or incoming is float):
					settings[key] = incoming
				elif typeof(incoming)==typeof(settings[key]):
					settings[key]=incoming
	if int(data.get("version",1)) < 2:
		settings.keys.erase("jump")
		settings.keys.erase("special")
	if int(data.get("version",1))<3 and is_equal_approx(float(settings.music),.25):
		settings.music=.65
	settings.master=clampf(float(settings.master),0,1)
	settings.sfx=clampf(float(settings.sfx),0,1)
	settings.music=clampf(float(settings.music),0,1)
	settings.scale=clampi(int(settings.scale),1,3)

func _draw() -> void:
	var left := camera.position.x-320 if is_instance_valid(camera) else 0.0
	draw_rect(Rect2(left-20,-20,700,410),Color("38a1b9"))
	var tint := Color.WHITE
	if mode=="menu":
		draw_texture_rect(title_texture,Rect2(left,0,640,360),false)
		for n in range(16):
			var at:=Vector2(left+fposmod(n*97+clock*7,640),340-fposmod(n*43+clock*(12+n%5),230))
			draw_rect(Rect2(at,Vector2(1,2)),Color(1,.7,.3,.25+.2*sin(clock+n)))
		return
	var scenery: Texture2D=level_textures[stage_index]
	var scenery_x:=left-clampf(left*.3,0,896)
	draw_texture_rect(scenery,Rect2(scenery_x,0,1536,310),false)
	if stage_index==0:
		for n in range(24):
			var x:=left+fposmod(n*43.0-clock*8-left*.18,680)-20
			draw_rect(Rect2(x,245+(n%5)*6,12,1),Color(.8,1,1,.3))
	elif stage_index==3:
		for n in range(80):
			var drop:=Vector2(left+fposmod(n*97.0-clock*60,660),fposmod(n*43+clock*240,310))
			draw_line(drop,drop+Vector2(-3,9),Color(.5,.7,1,.28),1)
	elif stage_index==4:
		for n in range(20):
			draw_circle(Vector2(left+fposmod(n*79,640),fposmod(n*37-clock*12,310)),1,Color(.3,1,1,.4))
	if platforms.is_empty():draw_texture_rect(ground_textures[stage_index],Rect2(left,310,768,60),false)
	for platform in platforms:
		var rect:=Rect2(platform.body.position,platform.size)
		if rect.size.x>600:
			for n in range(-1,3):
				var x:=left-fposmod(left,768.0)+n*768
				draw_texture_rect(ground_textures[stage_index],Rect2(x,310,768,60),false,tint)
		else:
			var style:=5 if stage_index==0 else (4 if stage_index in [2,4] else 7)
			var texture:Texture2D=prop_textures[style]
			# Tile horizontal platform art rather than squash an entire object.
			var tile_width:=rect.size.y*texture.get_width()/texture.get_height()
			var offset:=0.0
			while offset<rect.size.x:
				var w:=minf(tile_width,rect.size.x-offset)
				draw_texture_rect_region(texture,Rect2(rect.position+Vector2(offset,0),Vector2(w,rect.size.y)),Rect2(0,0,texture.get_width()*w/tile_width,texture.get_height()))
				offset+=w
			draw_line(rect.position,rect.position+Vector2(rect.size.x,0),Color("b0a682"),1)
	for zone in danger:
		for n in range(5):
			var point:Vector2=zone.position+Vector2(n*10,0)
			draw_colored_polygon(PackedVector2Array([point+Vector2(0,8),point+Vector2(5,-5),point+Vector2(10,8)]),Color("f7848f"))
	for decor in stage_data[stage_index].decor:
		var style:=int(decor.style)
		var tex:Texture2D=prop_textures[style]
		var h:=float(decor.get("height",42));var size:=Vector2(h*tex.get_width()/tex.get_height(),h)
		var at:=Vector2(float(decor.x),float(decor.get("baseline",302)))
		draw_texture_rect(tex,Rect2(at-Vector2(0,size.y),size),false,Color(.64,.69,.74,.9))
	for object in objects:
		if object.dead:
			draw_texture_rect(prop_textures[11],Rect2(object.rect.position.x,300,object.rect.size.x+12,10),false)
		else:
			var tex:Texture2D=prop_textures[int(object.get("style",1 if object.barrel else 0))]
			var h:float=object.rect.size.y;var w:=h*tex.get_width()/tex.get_height()
			draw_rect(Rect2(object.rect.position.x-3,307,object.rect.size.x+6,3),Color(0,0,0,.2))
			draw_texture_rect(tex,Rect2(object.rect.get_center().x-w/2,310-h,w,h),false)
	for piece in debris:
		draw_set_transform(piece.pos,piece.angle)
		draw_texture_rect_region(prop_textures[piece.style],Rect2(-piece.size/2,piece.size),piece.source)
		draw_set_transform(Vector2.ZERO)
	for item in items:
		if not item.active:continue
		var colors:=[Color("ff8baf"),Color("c984ff"),Color("ffe09c"),Color("8fe7ce")]
		var pos:Vector2=item.pos+Vector2(0,sin(item.clock*4)*3)
		draw_rect(Rect2(pos-Vector2(9,9),Vector2(18,18)),Color("253038"))
		draw_rect(Rect2(pos-Vector2(7,7),Vector2(14,14)),colors[int(item.kind)],false,2)
		if int(item.kind) in [0,2]:
			draw_circle(pos,4,Color("ffe09c"))
		elif int(item.kind)==1:
			draw_colored_polygon(PackedVector2Array([pos+Vector2(1,-6),pos+Vector2(-4,1),pos+Vector2(0,1),pos+Vector2(-1,6),pos+Vector2(4,-1),pos+Vector2(0,-1)]),Color("e8bcff"))
		else:
			draw_line(pos+Vector2(0,-5),pos+Vector2(0,5),Color("8fe7ce"),3)
	for bullet in bullets:
		if not bullet.active: continue
		if bullet.friendly:
			draw_line(bullet.pos-bullet.velocity.normalized()*10,bullet.pos,Color("fff0bb"),2)
		else:
			draw_circle(bullet.pos,4,Color("ff9b87"));draw_circle(bullet.pos,2,Color("ffedbf"))
	for blast in explosions:
		var progress:float=blast.age/.42
		var radius:float=blast.radius*(.2+progress)
		for ring in range(3):
			var color:Color=[Color("9b4234"),Color("ff8b36"),Color("fff0ad")][ring]
			color.a=1-progress
			draw_circle(blast.pos,radius*(1-ring*.26),color,false,4)
	for effect in particles_pool:
		draw_rect(Rect2(effect.pos,Vector2.ONE*effect.size),effect.color)
	if special_fx>0:
		var elapsed := .85-special_fx
		var origin := special_origin+Vector2(20*special_facing,-31)
		var alpha := minf(1,special_fx*3)
		for n in range(7):
			var angle := -.23+n*.075
			var ray := Vector2(special_facing*cos(angle),sin(angle))
			var distance := 70+fposmod(elapsed*900+n*67,430)
			var tip := origin+ray*distance
			draw_line(origin+ray*20,tip,Color(.62,.2,1,.45*alpha),7)
			draw_line(origin+ray*25,tip,Color(1,.7,1,.9*alpha),2)
			var texture: Texture2D=ex_textures[clampi(int(elapsed*6+n%2),0,3)]
			draw_texture_rect(texture,Rect2(tip-Vector2(32,32),Vector2(64,64)),false,Color(1,1,1,alpha))
		var frame := clampi(int(elapsed*6),0,3)
		draw_texture_rect(ex_textures[frame],Rect2(origin-Vector2(48,48),Vector2(96,96)),false,Color(1,1,1,alpha))

func _exit_tree() -> void:
	if music_fade!=null and music_fade.is_valid():music_fade.kill()
	if is_instance_valid(music_tail):music_tail.stop();music_tail.stream=null
	if is_instance_valid(bgm):
		bgm.stop()
		bgm.stream=null
	for audio in audio_pool:
		if is_instance_valid(audio):
			audio.stop()
			audio.stream=null

func exit_game() -> void:
	if mode=="exiting":return
	save_game()
	mode="exiting";get_tree().paused=true
	if is_instance_valid(bgm): bgm.stop(); bgm.stream=null
	for audio in audio_pool:
		if is_instance_valid(audio): audio.stop(); audio.stream=null
	await get_tree().create_timer(.15,true).timeout
	get_tree().quit()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		exit_game()

func update_debris(delta: float) -> void:
	for piece in debris.duplicate():
		piece.life-=delta
		if piece.life<=0:debris.erase(piece);continue
		piece.velocity.y+=450*delta;piece.pos+=piece.velocity*delta;piece.angle+=piece.spin*delta
		if piece.pos.y>306:piece.pos.y=306;piece.velocity.y*=-.25;piece.velocity.x*=.7

func segment_rect_time(a: Vector2,b: Vector2,rect: Rect2) -> float:
	if rect.has_point(a):return 0.0
	var low:=0.0
	var high:=1.0
	var direction:=b-a
	for axis in range(2):
		if absf(direction[axis])<.00001:
			if a[axis]<rect.position[axis] or a[axis]>rect.end[axis]:return -1.0
		else:
			var enter:float=(rect.position[axis]-a[axis])/direction[axis]
			var leave:float=(rect.end[axis]-a[axis])/direction[axis]
			low=maxf(low,minf(enter,leave));high=minf(high,maxf(enter,leave))
			if low>high:return -1.0
	return low

func show_music_credits() -> void:
	reset_menu("MUSIC / CREDITS")
	var credits:Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://data/music_credits.json"))
	var label:=Label.new()
	label.text=""
	for key in ["coast","desert","rail","night","reactor","boss","menu"]:
		var row:Dictionary=credits[key]
		label.text+="%s — %s\n%s / %s\n"%[key.to_upper(),row.title,row.author,row.license]
	label.text+="Original procedural arcade music and sound effects.\nNo external music recordings used.\nReplacement pixel art generated for this build.\nNoto Sans CJK: SIL Open Font License 1.1."
	label.add_theme_font_size_override("font_size",10);menu_box.add_child(label)
	add_button("돌아가기",show_main_menu)

