# PROJECT HINA: OPERATION GEHENNA

첨부된 `Project_HINA_v0.9_scripts.txt`의 Godot 게임 코드와 데이터를 복원한 싱글 플레이 횡스크롤 런앤건입니다. 메탈슬러그의 방향 사격, 한 번 피격되면 잔기 소모, 가까운 적 근접 공격, 코인 컨티뉴 방식의 플레이를 참고합니다.

## 실행

- **Windows**: Windows 배포 ZIP을 풀고 `Project_HINA.exe` 실행. 별도 Godot 설치가 필요 없습니다.
- **소스**: Godot **4.6.3**에서 이 폴더의 `project.godot`을 열고 F6 또는 F5. 터미널에서는 `godot --path .`.
- **브라우저 빌드**: Web ZIP을 풀고 그 폴더에서 `python3 -m http.server 8000` 실행 후 브라우저에서 접속합니다. HTML 파일을 직접 열면 WebAssembly 리소스를 읽을 수 없습니다. 데스크톱 키보드 사용을 권장합니다.

메뉴에서 **출격 / START**를 선택하면 시작합니다. 방향키로 메뉴 선택, Enter로 실행할 수 있습니다.

| 키 | 동작 |
|---|---|
| A / D 또는 ← / → | 좌우 이동 |
| W 또는 ↑ | 상단 조준, 이동과 함께 대각선 조준 |
| S 또는 ↓ | 지상 웅크리기 / 공중 아래 조준 |
| J (누르고 유지) | 연사 / 가까운 전방 적 자동 킥 |
| K | 점프 |
| L | 필살기, 초기 3회; 발동 중 무적 |
| 1 / 숫자패드 1 | 코인 투입, 잔기 추가 / 10초 내 컨티뉴 |
| Esc | 일시정지 / 계속 |

설정에서 키, 음량, 화면 크기, 전체 화면, 화면 흔들림을 변경할 수 있습니다. 해금, 최고 점수와 설정은 Godot `user://hina_save.json`에 저장합니다. 새 게임은 3잔기로 시작합니다.

## 콘텐츠

해안 상륙 → 사막 유적 → 철도 → 야간 시가 → 원자로의 5개 스테이지. 보병, 방패병, 저격수, 자동기계와 18/26 HP 전차가 등장합니다. 각 보스는 사전 경고와 별도 공략 기믹을 갖습니다. 장애물 파괴, 탄환 지형 충돌, 드롭, 점수, 연속 부활, 코인 컨티뉴를 포함합니다.

첨부 파일에는 이미지·음원 원본이 없었습니다. 본 빌드는 **직접 생성한 대체 픽셀 그래픽과 합성 음악·효과음**을 포함합니다. 메탈슬러그의 이미지나 음원을 사용하지 않았습니다. 첨부 문서의 외부 이미지 파일명과 영상 링크는 원본 리소스나 영상 검토 증거로 간주하지 않았습니다. 원본 코드의 캐릭터·보스 명칭과 게임 데이터를 유지했으며, 원본 미술을 재현한 빌드는 아닙니다.

## 개발 및 검증

게임 실행에는 Python 패키지가 필요 없습니다. 미술을 다시 생성할 때만 `Pillow`, 합성 음원을 다시 생성할 때만 `numpy`와 `ffmpeg`가 필요합니다.

```sh
python3 tools/generate_standalone_assets.py
python3 tools/make_audio_v3.py
python3 tools/make_sfx_v6.py
godot --headless --path . --editor --import --quit
godot --headless --path . --script tests/integration.gd
godot --headless --path . --script tests/raid.gd
godot --headless --path . --script tests/v9.gd
godot --headless --path . --script tests/audio_check.gd
```

아트 생성기의 타이틀 폰트는 Debian/Ubuntu의 DejaVu Sans를 사용합니다. 게임에 필요한 한국어 Noto Sans CJK 폰트는 이미 포함되어 있으며 라이선스는 `assets/fonts/LICENSE.txt`에 있습니다.

테스트 결과는 `planning/*test_results.json`에 기록합니다. `tests/render.gd`는 디스플레이 환경에서 게임과 보스전 화면을 캡처합니다. 첨부본의 `tests/v8.gd`는 이전 버전의 전차 원샷·외부 녹음 음원 가정을 검사하므로 현재 버전의 검증 대상이 아닙니다. 기존 `pack_v*.py`, `prepare_*`, `upgrade_*`는 누락된 원본 이미지·음원 또는 구버전 소스를 필요로 하는 첨부본 보관용 도구입니다. 현재 아트 생성에는 위의 `generate_standalone_assets.py`를 사용하세요.

Windows 재빌드는 Godot 4.6.3의 공식 export templates 설치 후 `bash tools/build_windows.sh`로 실행합니다. Linux와 Web은 각각 `godot --headless --path . --export-release Linux builds/Project_HINA.x86_64`, `godot --headless --path . --export-release Web builds/web/index.html`로 내보낼 수 있습니다. 출력 디렉터리를 먼저 만드세요. 스테이지 JSON은 export preset의 `include_filter`로 포함합니다.

Windows 빌드는 내보내기와 파일 구조를 검증했으며 이 Linux 환경에서 Windows 실행 자체는 검증하지 않았습니다. 실제 런타임·기능 검증은 Godot Linux에서 수행합니다.

검증을 완료한 Windows/Web/Source 배포 ZIP은 `python3 tools/package_standalone.py`로 `/workspace/outputs`에 생성합니다. 이 도구는 테스트 결과 파일이 모두 성공 상태인지 확인합니다. 첨부본의 `tools/package_release.py`는 이전 리소스·패키지 레이아웃 전용 보관본입니다.
