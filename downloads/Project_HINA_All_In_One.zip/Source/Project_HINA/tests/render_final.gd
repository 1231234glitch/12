extends SceneTree
var game
func _initialize() -> void:call_deferred("run")
func frames(n: int) -> void:
	for i in range(n):await physics_frame
func snap(name: String) -> void:
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("res://planning/"+name+".png")
func run() -> void:
	game=load("res://scenes/game.tscn").instantiate();root.add_child(game);await frames(3);await snap("menu_review")
	for stage in range(5):
		game.start_game(stage);await frames(3);game.player.position=Vector2(game.stage_length-530,310);game.player.invulnerable=9999
		game.start_boss();game.boss.set_physics_process(false);game.boss.state="RECOVER";game.banner.text=""
		if stage==3:game.boss.phase=2
		game.boss.prepare();game.boss.perform_attack();game.boss.queue_redraw()
		await frames(3);await snap("raid_%d_review"%(stage+1))
		if stage==4:
			for wave in range(4):
				if wave>0:game.boss.prepare();game.boss.perform_attack()
				for t in game.boss.targets.duplicate():
					if is_instance_valid(t) and not t.dead:t.take_damage(1)
				game.boss.update_core(.01)
			game.boss.sprite.texture=game.boss.textures[5];game.boss.queue_redraw()
			await frames(30);await snap("chesed_open_review")
	game.set_physics_process(false);game.world.process_mode=Node.PROCESS_MODE_DISABLED
	game.bgm.stop();game.bgm.stream=null
	for a in game.audio_pool:a.stop();a.stream=null
	await create_timer(.2,true).timeout
	game.queue_free();await process_frame;game=null;await process_frame;quit()

