extends SceneTree
var game
var results:Array=[]
var failures:=0
func _initialize():call_deferred("run")
func check(ok:bool,label:String):
	results.append({"name":label,"passed":ok})
	if not ok:failures+=1
	print("PASS " if ok else "FAIL ",label)
func frames(n:int):
	for i in range(n):await physics_frame
func run():
	game=load("res://scenes/game.tscn").instantiate();root.add_child(game);await frames(3)
	game.credits=0;game.start_game();await frames(3);game.player.invulnerable=9999
	var before:int=game.lives;var count:int=game.coins_inserted
	var key:=InputEventKey.new();key.physical_keycode=KEY_1;key.pressed=true
	game._input(key);check(game.lives==before+1 and game.coins_inserted==count+1,"coin_key_adds_exactly_one_life")
	key.echo=true;game._input(key);check(game.lives==before+1,"held_coin_key_does_not_repeat")
	game.show_pause();game.insert_coin();check(game.lives==before+2 and game.mode=="pause","coin_during_pause")
	game.resume_game();game.lives=1
	game.player.position=Vector2(900,310);game.score=1234
	var world_id:int=game.world.get_instance_id()
	game.player.invulnerable=0;game.player.take_damage(1,true);await frames(40)
	check(game.mode=="continue" and game.continue_timer>9,"last_life_opens_ten_second_countdown")
	var pos:Vector2=game.player.position;var frozen_time:float=game.mission_time
	await frames(30)
	check(game.player.position==pos and game.mission_time==frozen_time,"continue_freezes_world_and_mission_clock")
	game.insert_coin();check(game.mode=="playing" and game.lives==1 and game.player.hp==1,"coin_continues_with_one_life")
	check(game.world.get_instance_id()==world_id and game.score==1234,"continue_preserves_world_score")
	check(game.player.position.distance_to(pos)<1 and game.player.invulnerable>2,"continue_same_position_invulnerability")
	game.player.invulnerable=0;game.player.take_damage(1,true);await frames(40)
	game.continue_timer=.01;await frames(3)
	check(game.mode=="gameover","countdown_expires_to_gameover")
	game.insert_coin();check(game.mode=="playing" and game.lives==1,"coin_after_timeout_restarts_stage")
	game.player.invulnerable=9999;game.set_physics_process(false)
	for kind in range(10):
		game.spawn_enemy(1600,kind);var e=game.enemies.back();e.set_physics_process(false)
		e.take_damage(1)
		if kind<8:check(e.dead,"infantry_%d_one_hit"%kind)
		else:
			check(not e.dead and e.hp==e.maximum_hp-1,"tank_%d_survives_one_hit"%kind)
			e.take_damage(e.hp-1);check(not e.dead and e.hp==1,"tank_%d_retains_last_hp"%kind)
			e.take_damage(1);check(e.dead,"tank_%d_dies_at_zero"%kind)
	for stage in range(5):
		game.start_game(stage);game.set_physics_process(false);game.player.invulnerable=9999;game.player.set_physics_process(false)
		check(game.stage_length>4500,"stage_%d_extended"%stage)
		var spaces:=true
		for prop in game.stage_data[stage].props:
			for platform in game.stage_data[stage].platforms:
				if Rect2(prop.x,310-prop.height,prop.width,prop.height).intersects(Rect2(platform[0],platform[1],platform[2],platform[3])):spaces=false
		check(spaces,"stage_%d_cover_clear_of_platforms"%stage)
		game.start_boss();var b=game.boss;b.set_physics_process(false);b.state="RECOVER";b.pattern=0
		var origin:Vector2=b.position;b.choose_movement();b.update_movement(1)
		check(b.position.distance_to(origin)>0,"boss_%d_has_translation"%stage)
		var pose:PackedVector2Array=b.mesh.polygon.duplicate();b.clock+=.4;b.update_mesh()
		check(pose!=b.mesh.polygon,"boss_%d_has_articulated_motion"%stage)
		b.prepare();var hazards:Array=b.hazards.duplicate(true);b.update_movement(1)
		check(hazards==b.hazards,"boss_%d_telegraphs_stay_locked"%stage)
	var f=FileAccess.open("res://planning/v9_test_results.json",FileAccess.WRITE);f.store_string(JSON.stringify({"tests":results,"failures":failures},"\t"));f.close()
	if game.music_fade:game.music_fade.kill()
	game.music_tail.stop();game.music_tail.stream=null;game.bgm.stop();game.bgm.stream=null
	for a in game.audio_pool:a.stop();a.stream=null
	await create_timer(.25,true).timeout
	game.queue_free();game=null;await process_frame;await process_frame;quit(1 if failures else 0)
