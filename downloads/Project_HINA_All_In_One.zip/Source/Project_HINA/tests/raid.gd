extends SceneTree
var game
var results: Array=[]
var failures:=0
func _initialize() -> void:call_deferred("run")
func check(ok: bool,name: String) -> void:
	results.append({"name":name,"passed":ok})
	if not ok:failures+=1
	print("PASS " if ok else "FAIL ",name)
func frames(n: int) -> void:
	for i in range(n):await physics_frame
func setup(stage: int) -> void:
	game.start_game(stage);await frames(3)
	game.set_physics_process(false);game.player.set_physics_process(false)
	game.player.position=Vector2(game.stage_length-540,310);game.player.invulnerable=9999
	game.start_boss();game.boss.set_physics_process(false);game.boss.state="RECOVER"
	for e in game.enemies:e.set_physics_process(false)
func run() -> void:
	game=load("res://scenes/game.tscn").instantiate();root.add_child(game);await frames(3)
	await setup(0)
	var b=game.boss
	b.prepare();check(b.attack=="laser" and b.hazards.size()==1,"binah_starts_with_locked_laser")
	var endpoint:Vector2=b.hazards[0].b;game.player.position.x+=100
	check(b.hazards[0].b==endpoint,"laser_does_not_track_after_warning")
	game.player.invulnerable=0;b.update_hazards(.1)
	check(game.player.hp==1,"warning_does_not_damage")
	b.hazards.clear();b.pattern=1;b.prepare()
	check(b.attack=="missiles" and b.hazards.size()==3,"binah_missile_lanes")
	check(b.hazards[1].rect.position.x-b.hazards[0].rect.end.x>=60,"missile_lanes_leave_dodge_gap")
	b.phase=2;b.pattern=3;b.hazards.clear();b.prepare()
	check(b.attack=="sandstorm","binah_second_phase_sandstorm")
	game.player.position.y=245;b.hazards[0].delay=0;b.update_hazards(.01)
	check(game.player.hp==1,"jump_clears_sandstorm")
	game.player.position.y=310;b.update_hazards(.01)
	check(game.player.hp==0,"sandstorm_hits_grounded_player")
	await setup(1);b=game.boss;b.prepare();b.perform_attack()
	check(b.count_targets("peroro")==3,"perorodzilla_summons_three_minions")
	var before:float=b.hp;var minion=b.targets[0];minion.take_damage(1)
	check(minion.dead and b.hp==before-28,"peroro_one_hit_reflects_damage")
	minion.take_damage(1);check(b.hp==before-28,"reflected_damage_not_duplicated")
	b.hazards.clear();b.prepare();check(b.attack=="eye" and b.hazards[0].type=="beam","perorodzilla_eye_laser")
	# Fast bullet collides with the first miniature, not the boss behind it.
	game.bullets.clear();before=b.hp
	game.fire(Vector2(game.stage_length-450,286),Vector2(1000,0),true,1);game.update_bullets(.5)
	check(b.count_targets("peroro")==1 and b.hp==before-28,"bullet_hits_nearest_raid_object")
	await setup(2);b=game.boss;b.prepare();b.perform_attack()
	check(b.count_targets("pillar")==2,"hod_summons_invasion_pillars")
	before=b.hp;b.take_damage(10);check(is_equal_approx(b.hp,before-3),"hod_closed_armor_reduces_damage")
	var pillar=b.targets[0];pillar.take_damage(1)
	check(not pillar.dead and pillar.hp==2,"pillar_is_structure_with_three_hits")
	game.player.position=pillar.position-Vector2(30,0);game.player.facing=1;game.player.perform_kick()
	check(pillar.dead,"kick_breaks_pillar_as_cc")
	game.player.position=Vector2(game.stage_length-540,310);game.special_attack(game.player.position,1)
	check(b.count_targets("pillar")==0 and b.vulnerable_time==6,"ex_clears_pillars_and_staggers_hod")
	before=b.hp;b.take_damage(10);check(is_equal_approx(b.hp,before-15),"hod_stagger_damage_window")
	await setup(3);b=game.boss;b.prepare();check(b.attack=="train","goz_train_attack")
	var train=b.hazards[0];check(train.delay>=1,"train_has_warning_time")
	train.delay=0;var old_x:float=train.rect.position.x;b.update_hazards(.1)
	check(train.rect.position.x<old_x,"train_crosses_arena")
	b.phase=2;b.shuffle_clones();check(b.count_targets("clone")==2,"goz_has_two_false_clones")
	before=b.hp
	for t in b.targets:
		if is_instance_valid(t) and t.kind=="clone":t.take_damage(50)
	check(b.hp==before,"false_clones_do_not_share_hp")
	b.take_damage(10);check(b.hp==before-10,"real_goz_receives_damage")
	var real_x:float=b.position.x;b.shuffle_clones()
	check(b.position.x!=real_x and b.count_targets("clone")==2,"goz_shuffles_real_position_without_leaking_clones")
	check(b.collision_center()==b.position+Vector2(0,-66) and b.collision_radius()==57,"goz_hitbox_follows_smaller_real_sprite")
	await setup(4);b=game.boss
	before=b.hp;b.take_damage(50);check(b.hp==before,"chesed_closed_core_blocks_damage")
	for wave in range(4):
		b.prepare();b.perform_attack()
		check(b.count_targets("automata")==3,"chesed_wave_%d_spawns"%(wave+1))
		for t in b.targets.duplicate():
			if is_instance_valid(t) and not t.dead:t.take_damage(1)
		b.update_core(.01)
		check(b.wave==wave+1,"chesed_wave_%d_charge"%(wave+1))
	check(b.core_time==5,"chesed_core_opens_only_after_four_waves")
	before=b.hp;b.take_damage(10);check(b.hp==before-30,"open_core_damage_multiplier")
	b.update_core(5.1);check(b.core_time==0 and b.wave==0,"chesed_core_closes_and_resets_charge")
	b.prepare();b.perform_attack()
	for t in b.targets.duplicate():
		if is_instance_valid(t) and not t.dead:t.die(false)
	b.update_core(.01);check(b.wave==0,"expired_adds_do_not_charge_core")
	b.prepare();b.perform_attack();var first=b.targets.back();first.set_physics_process(false)
	var target_age:float=first.age;game.player.hp=0;first._physics_process(1)
	check(first.age==target_age and not first.dead,"raid_adds_freeze_on_player_death")
	b.core_time=3;var core_before:float=b.core_time;b._physics_process(1)
	check(b.core_time==core_before,"core_window_freezes_on_player_death")
	game.player.hp=1;b.state="RECOVER";b.core_time=5;b.take_damage(9999)
	check(b.dead and b.hazards.is_empty(),"boss_defeat_clears_raid_hazards")
	var live:=0
	for t in b.targets:
		if is_instance_valid(t) and not t.dead:live+=1
	check(live==0,"boss_defeat_clears_summons")
	var f=FileAccess.open("res://planning/raid_test_results.json",FileAccess.WRITE)
	f.store_string(JSON.stringify({"tests":results,"failures":failures},"\t"));f.close()
	if game.music_fade:game.music_fade.kill()
	game.music_tail.stop();game.music_tail.stream=null
	game.bgm.stop();game.bgm.stream=null
	for a in game.audio_pool:a.stop();a.stream=null
	await create_timer(.25,true).timeout
	game.queue_free();game=null;await process_frame;await process_frame;quit(1 if failures else 0)

