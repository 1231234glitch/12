extends SceneTree

var game: Node2D
var results: Array = []
var failures := 0
var initial_time := 0

func _initialize() -> void:
	call_deferred("run")

func check(condition: bool,name: String,details := "") -> void:
	results.append({"name":name,"passed":condition,"details":details})
	if not condition: failures+=1
	print(("PASS " if condition else "FAIL ")+name+" "+details)

func frames(count: int) -> void:
	for n in range(count): await physics_frame

func run() -> void:
	initial_time=Time.get_ticks_msec()
	var scene=load("res://scenes/game.tscn")
	game=scene.instantiate();root.add_child(game)
	await process_frame
	game.start_game()
	await frames(30)
	check(game.player.is_on_floor(),"player_lands_on_ground")
	game.settings.keys={};game.configure_input()
	check(InputMap.action_get_events("jump")[0].physical_keycode==KEY_K,"K_jump_binding")
	check(InputMap.action_get_events("special")[0].physical_keycode==KEY_L,"L_special_binding")
	check(InputMap.action_get_events("shoot")[0].physical_keycode==KEY_J,"J_attack_binding")
	Input.action_press("up");await frames(2)
	check(game.player.aim.is_equal_approx(Vector2.UP),"vertical_aim")
	check(game.player.state=="shoot_up","upward_gun_animation")
	Input.action_press("right");await frames(2)
	check(game.player.aim.x>0 and game.player.aim.y<0,"diagonal_aim")
	check(game.player.state=="shoot_diagonal","diagonal_gun_animation")
	Input.action_release("up");Input.action_release("right")
	Input.action_press("jump");await frames(3);Input.action_release("jump")
	Input.action_press("down");await frames(2)
	check(game.player.aim.is_equal_approx(Vector2.DOWN),"air_downward_aim")
	check(game.player.state=="air_down" and game.player.muzzle.y>game.player.position.y,"downward_pose_and_muzzle_below_body")
	Input.action_release("down");Input.action_press("shoot");await frames(2)
	check(game.player.state=="air_shoot","air_horizontal_shooting_pose")
	Input.action_release("shoot");await frames(55)
	game.bullets.clear()
	var terrain=game.stage_data[0].platforms[0]
	game.fire(Vector2(terrain[0]+20,terrain[1]-20),Vector2(0,250),true,1)
	game.update_bullets(.2)
	check(not game.bullets[0].active,"bullet_stops_at_terrain")
	var x:float=game.player.position.x
	Input.action_press("right");await frames(20);Input.action_release("right")
	check(game.player.position.x>x+45,"immediate_movement")
	await frames(2)
	check(absf(game.player.velocity.x)<.1,"immediate_stop")
	Input.action_press("jump");await frames(3);Input.action_release("jump")
	check(game.player.velocity.y<0,"jump_rise")
	await frames(55)
	check(game.player.is_on_floor(),"jump_landing")
	Input.action_press("down");await frames(2)
	check(game.player.state=="crouch" and game.player.hitbox.size.y==22,"crouch_collision")
	Input.action_release("down")
	for enemy in game.enemies:enemy.set_physics_process(false)
	var enemy=game.enemies[0]
	enemy.position=game.player.position+Vector2(140,0)
	var hp:float=enemy.hp
	Input.action_press("shoot");await frames(25);Input.action_release("shoot")
	check(not is_instance_valid(enemy) or enemy.hp<hp,"shooting_hits_enemy")
	var active:=0
	for bullet in game.bullets:
		if bullet.active:active+=1
	check(game.bullets.size()<=320,"bullet_pool_bounded",str(game.bullets.size()))
	var old_world:int=game.world.get_instance_id()
	var death_position:Vector2=game.player.position
	var saved_score:int=game.score
	var old_player:int=game.player.get_instance_id()
	game.player.invulnerable=0;game.player.take_damage(1)
	check(game.player.hp==0 and game.lives==2,"one_hit_retires")
	game.player.take_damage(1,true)
	check(game.lives==2,"duplicate_death_blocked")
	await frames(37)
	check(game.world.get_instance_id()==old_world and game.player.get_instance_id()==old_player,"respawn_keeps_world_and_actor")
	check(absf(game.player.position.x-death_position.x)<1 and absf(game.player.position.y-death_position.y)<3,"respawn_at_death_position")
	check(game.player.hp==1 and game.player.invulnerable>2,"respawn_invulnerability")
	check(game.score==saved_score,"respawn_preserves_score")
	check(game.player.stock==3,"respawn_restores_bomb_stock")
	game.player.hp=1
	game.player.invulnerable=9999
	var targets:Array=[]
	for n in range(3):
		var target=game.EnemyScript.new();target.game=game;target.position=game.player.position+Vector2(100+n*65,0)
		game.world.add_child(target);game.enemies.append(target);target.set_physics_process(false);targets.append(target)
	var stock:int=game.player.stock
	Input.action_press("special");await frames(2);Input.action_release("special")
	check(game.player.stock==stock-1,"special_consumes_one")
	await frames(65)
	check(targets.all(func(target):return not is_instance_valid(target) or target.dead),"special_area_damage")
	await frames(45)
	check(game.player.special_time<=0,"special_ends_cleanly")
	game.player.stock=0;Input.action_press("special");await frames(2);Input.action_release("special")
	check(game.player.special_time<=0,"special_empty_blocked")
	var pos:Vector2=game.player.position
	game.show_pause();await frames(10)
	check(game.player.position==pos,"pause_freezes_physics")
	game.resume_game()
	game.items.clear();game.player.hp=1;game.spawn_item(game.player.position+Vector2(0,-20),0);await frames(2)
	check(game.player.hp==1,"score_pickup_does_not_add_hp")
	game.player.stock=9;game.spawn_item(game.player.position+Vector2(0,-20),1);await frames(2)
	check(game.player.stock==9,"special_stock_cap")
	game.player.position=Vector2(game.stage_length*.5+10,270);await frames(3)
	check(game.world.get_instance_id()==old_world and not game.banner.text.contains("체크포인트"),"midpoint_has_no_checkpoint")
	game.player.position=Vector2(game.stage_length-500,270);await frames(3)
	check(game.boss_active and is_instance_valid(game.boss),"boss_arena_starts")
	check(game.music_track=="boss" and game.bgm.playing,"boss_music_switch")
	await frames(130)
	var boss_hp:float=game.boss.hp
	game.player.position=Vector2(game.stage_length-350,310)
	game.special_attack(game.player.position,1)
	check(game.boss.hp==boss_hp-50,"special_boss_damage_exactly_once")
	var old_boss:int=game.boss.get_instance_id()
	var preserved_hp:float=game.boss.hp
	var preserved_camera:Vector2=game.camera.position
	game.player.invulnerable=0;game.player.take_damage(1);await frames(37)
	check(game.boss.get_instance_id()==old_boss and game.boss.hp==preserved_hp,"respawn_preserves_boss_damage")
	check(game.camera.position==preserved_camera and game.boss_active,"respawn_preserves_boss_arena")
	check(game.music_track=="boss" and game.bgm.playing,"music_continues_through_respawn")
	game.player.invulnerable=9999
	game.boss.hp=game.boss.maximum_hp*.4;await frames(2)
	check(game.boss.phase==2,"boss_phase_two")
	game.boss.take_damage(9999)
	check(game.clear_timer>0 and game.unlocked>=2,"boss_defeat_unlock")
	await frames(310)
	check(game.stage_index==1 and game.mode=="playing","stage_two_transition")
	game.player.invulnerable=9999
	game.player.position=Vector2(game.stage_length-450,270);await frames(3)
	await frames(130);game.boss.take_damage(9999);await frames(310)
	check(game.stage_index==2,"stage_three_transition")
	game.player.invulnerable=9999
	game.player.position=Vector2(game.stage_length-450,270);await frames(3)
	await frames(130);game.boss.take_damage(9999);await frames(310)
	check(game.stage_index==3,"stage_four_transition")
	for stage in [3,4]:
		game.player.invulnerable=9999
		game.player.position=Vector2(game.stage_length-450,270);await frames(3)
		await frames(130)
		check(game.boss.sprite.texture.resource_path.ends_with("boss_%d.png"%stage),"stage_%d_unique_boss"%(stage+1))
		if stage==4:game.boss.core_time=5
		game.boss.take_damage(9999);await frames(310)
	check(game.mode=="victory","five_stage_victory")
	game.start_game();await frames(3)
	game.lives=1;game.player.invulnerable=0;game.player.take_damage(3,true);await frames(80)
	check(game.mode=="continue","last_life_continue")
	game.start_game();await frames(3)
	game.enemies.clear()
	for child in game.world.get_children():
		if child.get_script()==game.EnemyScript:child.queue_free()
	await frames(2)
	for n in range(20):
		var target=game.EnemyScript.new();target.game=game;target.kind=n%8;target.faction="helmet" if n%8<4 else "automata"
		target.position=Vector2(400+n*20,300);game.world.add_child(target);game.enemies.append(target)
	for n in range(100):game.fire(Vector2(350,50+n%15),Vector2(120,0),n%2==0,1)
	for n in range(10):game.particles(Vector2(350+n*10,180),Color.PURPLE,25,100)
	game.player.invulnerable=9999
	game.start_boss();game.special_attack(game.player.position,1)
	var start:=Time.get_ticks_usec();await frames(120)
	var elapsed:=Time.get_ticks_usec()-start
	check(game.bullets.size()<=320 and game.particles_pool.size()<=550,"stress_pool_limits","120 physics frames / %.2f ms elapsed"%(elapsed/1000.0))
	# Validate data and all extracted frames exist.
	var manifest=JSON.parse_string(FileAccess.get_file_as_string("res://data/animation_manifest.json"))
	check(game.player.textures.walk.size()==8,"eight_frame_walk_cycle")
	check(game.music_tracks.coast.get_length()>50 and game.music_tracks.boss.get_length()>30,"full_length_music_tracks")
	check(game.music_tracks.coast.loop and game.music_tracks.boss.loop,"music_tracks_loop")
	check(game.sounds.size()>=17 and game.sfx_events.get("shot",0)>0 and game.sfx_events.get("respawn",0)>0,"sfx_wired_to_gameplay")
	var resources_valid:=true
	for animation in manifest:
		for frame in manifest[animation].frames:
			if not ResourceLoader.exists("res://"+frame.file):resources_valid=false
	check(resources_valid,"animation_resource_paths")
	check(not game.in_special_cone(game.player.position+Vector2(-100,-20),game.player.position,1),"special_does_not_hit_behind")
	check(not game.in_special_cone(game.player.position+Vector2(100,-200),game.player.position,1),"special_does_not_hit_outside_visual_cone")
	var legacy:=FileAccess.open(game.SAVE_PATH,FileAccess.WRITE)
	legacy.store_string(JSON.stringify({"version":1,"settings":{"keys":{"jump":KEY_SPACE,"special":KEY_K}}}));legacy.close()
	game.load_save();game.configure_input()
	check(InputMap.action_get_events("jump")[0].physical_keycode==KEY_K and InputMap.action_get_events("special")[0].physical_keycode==KEY_L,"legacy_key_binding_migration")
	game.save_game();game.load_save()
	check(game.unlocked>=1 and game.unlocked<=5,"save_load_roundtrip")
	game.settings.scale=3;game.settings.master=.35;game.save_game()
	game.settings.scale=1;game.settings.master=.8;game.load_save()
	check(int(game.settings.scale)==3 and absf(game.settings.master-.35)<.001,"numeric_settings_persist")
	var saved:=FileAccess.get_file_as_string(game.SAVE_PATH)
	var corrupt:=FileAccess.open(game.SAVE_PATH,FileAccess.WRITE);corrupt.store_string("{broken");corrupt.close()
	game.load_save()
	check(game.unlocked>=1,"corrupt_save_does_not_crash")
	var restore:=FileAccess.open(game.SAVE_PATH,FileAccess.WRITE);restore.store_string(saved);restore.close()
	check(game.camera.position.x>=320 and game.camera.position.x<=game.stage_length-320,"camera_bounds")
	game.start_game();await frames(30)
	for actor in game.enemies:actor.set_physics_process(false)
	game.player.invulnerable=9999
	check(is_instance_valid(game.arcade_hud) and not game.hud_label.visible,"arcade_hud_replaces_legacy_overlay")
	Input.action_press("jump");await frames(2);Input.action_release("jump")
	var wing_frames: Dictionary={}
	for n in range(18):
		await frames(1);wing_frames[game.player.frame_index]=true
	check(wing_frames.size()==4,"jump_plays_four_wing_phases")
	var wing_clock:float=game.player.wing_time
	Input.action_press("down");Input.action_press("shoot");await frames(2)
	check(game.player.state=="air_down" and game.player.wing_time>wing_clock,"aim_change_preserves_wing_clock")
	var down_frames: Dictionary={}
	for n in range(17):
		await frames(1);down_frames[game.player.frame_index]=true
	check(down_frames.size()>=3,"downward_fire_keeps_flapping")
	Input.action_release("down");Input.action_release("shoot");await frames(30)
	check(game.player.is_on_floor() and game.player.wing_time==0,"wings_reset_on_landing")
	var remaining:float=game.mission_time
	game.show_pause();await frames(10)
	check(game.mission_time==remaining,"arcade_timer_pauses")
	game.resume_game();await frames(3)
	check(game.mission_time<remaining,"arcade_timer_counts_down")
	game.mission_time=.001;var previous_lives:int=game.lives
	await frames(2)
	check(game.player.hp==0 and game.lives==previous_lives-1,"time_over_retires_once")
	await frames(37)
	check(game.player.hp==1 and game.mission_time>98,"time_over_respawn_resets_clock")
	for kind in range(8):
		for side in [-1,1]:
			var target=game.EnemyScript.new();target.game=game;target.kind=kind
			target.faction="helmet" if kind<4 else "automata"
			target.position=Vector2(120,310);game.world.add_child(target);game.enemies.append(target)
			var previous_score:int=game.score
			target.take_damage(1,Vector2(side,0))
			check(target.dead and target.hp==0 and target.collision_layer==0,"one_hit_kind_%d_direction_%d"%[kind,side])
			target.take_damage(1,Vector2(side,0))
			check(game.score==previous_score+100+kind*25,"single_kill_reward_%d_direction_%d"%[kind,side])
	check(not FileAccess.get_file_as_string("res://scripts/ui/arcade_hud.gd").contains("boss.hp"),"hud_has_no_health_gauge")
	game.start_game();await frames(2)
	var first_count:int=game.enemies.size()
	game.player.position.x=float(game.waves[0].trigger)+1;game.update_waves()
	var wave_count:int=game.enemies.size()
	game.update_waves()
	check(wave_count>first_count and game.enemies.size()==wave_count,"encounter_wave_spawns_once")
	var old_wave_state=game.waves.duplicate(true)
	game.player.invulnerable=0;game.player.take_damage(1,true);await frames(37)
	check(game.waves==old_wave_state,"respawn_preserves_wave_progress")
	game.start_game();await frames(30)
	game.player.invulnerable=9999
	for actor in game.enemies:actor.queue_free()
	game.enemies.clear();await frames(2)
	game.spawn_enemy(game.player.position.x+40,0)
	var close_enemy=game.enemies.back();close_enemy.set_physics_process(false)
	close_enemy.position.y=game.player.position.y
	game.player.facing=1;game.player.fire_timer=0
	var old_shots:int=game.player.shots
	Input.action_press("shoot");await frames(2);Input.action_release("shoot")
	check(game.player.kick_time>0 and game.player.state=="kick","near_J_starts_kick")
	check(not close_enemy.dead and game.player.shots==old_shots,"kick_has_windup_no_bullet")
	await frames(8)
	check(close_enemy.dead and close_enemy.collision_layer==0,"kick_strikes_at_extension")
	check(game.sfx_events.get("kick_hit",0)>0,"kick_impact_audio")
	close_enemy.set_physics_process(true)
	await frames(24)
	check(is_instance_valid(close_enemy) and close_enemy.death_time>.3,"death_animation_persists")
	await frames(45)
	check(not is_instance_valid(close_enemy),"death_animation_cleans_up")
	game.spawn_enemy(game.player.position.x-35,4)
	var behind=game.enemies.back();behind.set_physics_process(false);behind.position.y=game.player.position.y
	game.player.fire_timer=0;Input.action_press("shoot");await frames(2);Input.action_release("shoot")
	check(game.player.kick_time==0 and game.player.shots>old_shots and not behind.dead,"behind_enemy_does_not_trigger_kick")
	game.player.facing=-1;game.player.fire_timer=0
	Input.action_press("shoot");await frames(2);Input.action_release("shoot");await frames(9)
	check(behind.dead,"left_facing_kick_hits")
	game.player.take_damage(1,true);await frames(37)
	check(game.player.kick_time==0,"respawn_resets_kick")
	for stage in range(5):
		game.start_game(stage);await frames(2)
		check(game.music_track==game.stage_data[stage].music and game.music_tracks[game.music_track].get_length()>50,"stage_%d_music"%(stage+1))
		check(game.level_textures[stage].resource_path.ends_with("stage_%d.png"%stage),"stage_%d_background"%(stage+1))
	var output={"engine":Engine.get_version_info().string,"platform":OS.get_name(),"renderer":DisplayServer.get_name(),"tests":results,"failures":failures,"duration_ms":Time.get_ticks_msec()-initial_time}
	var file:=FileAccess.open("res://planning/test_results.json",FileAccess.WRITE);file.store_string(JSON.stringify(output,"\t"));file.close()
	print("RESULT: %d tests, %d failures"%[results.size(),failures])
	game.set_physics_process(false)
	game.world.process_mode=Node.PROCESS_MODE_DISABLED
	if game.music_fade:game.music_fade.kill()
	game.music_tail.stop();game.music_tail.stream=null
	game.bgm.stop();game.bgm.stream=null
	for audio in game.audio_pool:audio.stop();audio.stream=null
	# Let the real audio mixer release voices even during fixed-FPS test runs.
	OS.delay_msec(250)
	await create_timer(.15,true).timeout
	game.queue_free();await process_frame;game=null;scene=null;await process_frame
	quit(1 if failures>0 else 0)

