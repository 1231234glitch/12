extends SceneTree
var game
func _initialize() -> void: call_deferred("run")
func snap(name: String) -> void:
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("res://planning/"+name+".png")
func frames(count: int) -> void:
	for n in range(count):await physics_frame
func run() -> void:
	game=load("res://scenes/game.tscn").instantiate();root.add_child(game)
	await frames(3);await snap("menu_review")
	game.start_game();await frames(95);game.player.invulnerable=0
	for e in game.enemies:e.set_physics_process(false)
	game.banner.text="";await frames(1);await snap("gameplay_review")
	Input.action_press("up");Input.action_press("shoot");await frames(3);await snap("aim_up_review")
	Input.action_press("right");await frames(3);await snap("aim_diagonal_review")
	Input.action_release("up");Input.action_release("right")
	Input.action_press("jump");await frames(3);Input.action_release("jump")
	Input.action_press("down");await frames(3);await snap("air_down_review")
	game.player.set_physics_process(false)
	game.player.position=Vector2(250,185);game.player.invulnerable=0
	for phase in range(4):
		game.player.wing_frame=phase;game.player.wing_time=phase/12.0
		game.player.update_visual(false)
		await snap("wing_phase_%d"%phase)
	game.player.set_physics_process(true)
	Input.action_release("down");await frames(3);await snap("air_shoot_review")
	Input.action_release("shoot");await frames(60)
	Input.action_press("right");Input.action_press("shoot")
	for i in range(8):
		await frames(4);await snap("walk_%02d"%i)
	Input.action_release("right");Input.action_release("shoot")
	game.player.invulnerable=9999;game.player.position=Vector2(game.stage_length-450,310)
	await frames(125);await snap("boss_review")
	game.player.stock=3;Input.action_press("special");await frames(2);Input.action_release("special")
	await frames(53);await snap("special_review")
	await frames(60);game.player.invulnerable=0;game.player.take_damage(1,true)
	await frames(20);await snap("death_review")
	await frames(18);await snap("respawn_review")
	game.show_pause();await frames(2);await snap("pause_review")
	game.show_settings("pause");await frames(2);await snap("settings_review")
	game.show_keys();await frames(2);await snap("keys_review")
	for stage in range(5):
		game.start_game(stage);await frames(30)
		game.player.invulnerable=9999;game.banner.text=""
		await snap("stage_%d_review"%(stage+1))
		game.player.position=Vector2(game.stage_length-450,310);await frames(125)
		await snap("boss_%d_review"%(stage+1))
	# Capture each raid mechanic independently of its encounter opening.
	for stage in range(5):
		game.start_game(stage);await frames(3);game.player.position=Vector2(game.stage_length-530,310);game.player.invulnerable=9999
		game.start_boss();game.boss.set_physics_process(false);game.boss.state="RECOVER";game.banner.text=""
		if stage==3:game.boss.phase=2;game.boss.shuffle_clones()
		game.boss.prepare();game.boss.perform_attack();game.boss.queue_redraw()
		await frames(3);await snap("raid_%d_review"%(stage+1))
		if stage==4:
			game.boss.core_time=4;game.boss.wave=4;game.boss.sprite.texture=game.boss.textures[5];game.boss.hint="CORE OPEN / ATTACK NOW";game.boss.queue_redraw()
			await snap("chesed_open_review")
	game.start_game();await frames(30);game.player.set_physics_process(false)
	game.player.kick_time=.28;game.player.kick_air=false;game.player.update_visual(false)
	await snap("kick_review")
	game.spawn_enemy(170,0)
	var fallen=game.enemies.back();fallen.take_damage(1,Vector2.RIGHT)
	for n in range(4):
		await frames(8);await snap("enemy_fall_%d"%n)
	game.set_physics_process(false);game.world.process_mode=Node.PROCESS_MODE_DISABLED
	game.bgm.stop();game.bgm.stream=null
	for a in game.audio_pool:a.stop();a.stream=null
	await create_timer(.15,true).timeout
	game.queue_free();await process_frame;game=null;await process_frame
	quit()

