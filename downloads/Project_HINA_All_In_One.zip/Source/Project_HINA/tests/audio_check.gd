extends SceneTree
var game
func _initialize() -> void:call_deferred("run")
func measure(buffer: PackedVector2Array) -> Dictionary:
	var peak:=0.0
	var energy:=0.0
	for sample in buffer:
		peak=maxf(peak,maxf(absf(sample.x),absf(sample.y)))
		energy+=sample.length_squared()*.5
	return {"frames":buffer.size(),"peak":peak,"rms":sqrt(energy/maxi(1,buffer.size()))}
func run() -> void:
	game=load("res://scenes/game.tscn").instantiate();root.add_child(game)
	await process_frame
	game.reset_audio();game.start_game()
	for enemy in game.enemies:enemy.set_physics_process(false)
	var captures:Dictionary={}
	for name in ["Music","SFX","Master"]:
		var effect:=AudioEffectCapture.new();effect.buffer_length=4.0
		AudioServer.add_bus_effect(AudioServer.get_bus_index(name),effect)
		captures[name]=effect
	for n in range(10):
		game.sound("shot")
		if n==4:game.sound("explosion")
		await create_timer(.12,true).timeout
	await create_timer(.3,true).timeout
	var report:Dictionary={}
	var failed:=false
	for name in captures:
		var effect:AudioEffectCapture=captures[name]
		var buffer:=effect.get_buffer(effect.get_frames_available())
		report[name]=measure(buffer)
		if int(report[name].frames)<1000 or float(report[name].rms)<.001:failed=true
		if name=="Master":
			var bytes:=PackedByteArray();bytes.resize(buffer.size()*4)
			for i in range(buffer.size()):
				bytes.encode_s16(i*4,clampi(int(buffer[i].x*32767),-32768,32767))
				bytes.encode_s16(i*4+2,clampi(int(buffer[i].y*32767),-32768,32767))
			var wav:=AudioStreamWAV.new();wav.format=AudioStreamWAV.FORMAT_16_BITS;wav.stereo=true;wav.mix_rate=int(AudioServer.get_mix_rate());wav.data=bytes
			wav.save_to_wav("res://planning/audio_mix_review.wav")
	report["passed"]=not failed
	var f:=FileAccess.open("res://planning/audio_test_results.json",FileAccess.WRITE);f.store_string(JSON.stringify(report,"\t"));f.close()
	print(JSON.stringify(report))
	if game.music_fade:game.music_fade.kill()
	game.music_tail.stop();game.music_tail.stream=null
	game.bgm.stop();game.bgm.stream=null
	for a in game.audio_pool:a.stop();a.stream=null
	for name in captures:
		var bus:=AudioServer.get_bus_index(name)
		AudioServer.remove_bus_effect(bus,AudioServer.get_bus_effect_count(bus)-1)
	captures.clear()
	await create_timer(.15,true).timeout
	game.queue_free();game=null;await process_frame;await process_frame
	quit(1 if failed else 0)

