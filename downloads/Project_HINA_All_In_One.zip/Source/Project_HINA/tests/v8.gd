extends SceneTree
var game
var results: Array=[]
var failures:=0
func _initialize():call_deferred("run")
func check(ok:bool,label:String):
	results.append({"name":label,"passed":ok})
	if not ok:failures+=1
	print("PASS " if ok else "FAIL ",label)
func run():
	game=load("res://scenes/game.tscn").instantiate();root.add_child(game)
	await process_frame
	game.start_game(0);game.set_physics_process(false);game.player.set_physics_process(false)
	for kind in range(10):
		game.spawn_enemy(1200,kind)
		var e=game.enemies.back();e.set_physics_process(false)
		check(e.frames.size()==4 and e.death_frames.size()==4,"enemy_%d_animation_frames"%kind)
		e.take_damage(1)
		check(e.dead,"enemy_%d_one_hit_death"%kind)
	var object=game.objects[0];object.barrel=false
	var before=game.debris.size();game.destroy_object(object)
	check(object.dead and game.debris.size()==before+6,"prop_break_creates_six_fragments")
	game.destroy_object(object)
	check(game.debris.size()==before+6,"destroyed_prop_not_duplicated")
	check(game.prop_textures.size()==12,"twelve_prop_textures_loaded")
	check(game.CLEAR_DURATION==4.8,"clear_card_duration")
	var credits=JSON.parse_string(FileAccess.get_file_as_string("res://data/music_credits.json"))
	for key in credits:
		check(credits[key].seconds>75 and credits[key].source_recording,"produced_music_"+key)
	check(not FileAccess.get_file_as_string("res://scripts/game.gd").contains("선생님"),"character_lines_removed")
	var f=FileAccess.open("res://planning/v8_test_results.json",FileAccess.WRITE)
	f.store_string(JSON.stringify({"tests":results,"failures":failures},"\t"));f.close()
	if game.music_fade:game.music_fade.kill()
	game.music_tail.stop();game.music_tail.stream=null;game.bgm.stop();game.bgm.stream=null
	for a in game.audio_pool:a.stop();a.stream=null
	await create_timer(.2,true).timeout
	game.queue_free();game=null;await process_frame;await process_frame
	quit(1 if failures else 0)

