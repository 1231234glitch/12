extends SceneTree
var game
func _initialize() -> void:call_deferred("run")
func frames(n: int) -> void:
	for i in range(n):await physics_frame
func snap(name: String) -> void:
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("res://planning/"+name+".png")
func run() -> void:
	game=load("res://scenes/game.tscn").instantiate();root.add_child(game)
	await frames(3);await snap("menu_v8")
	game.show_music_credits();await frames(3);await snap("credits_v8")
	for stage in range(5):
		game.start_game(stage);await frames(30);game.player.invulnerable=9999;game.banner.text=""
		for e in game.enemies:e.set_physics_process(false)
		game.player.position.x=250
		await frames(3);await snap("stage_%d_v8"%(stage+1))
	game.start_game();await frames(30);game.banner.text=""
	game.player.position=Vector2(60,310);game.player.set_physics_process(false);game.player.invulnerable=0
	game.player.update_visual(false)
	for e in game.enemies:e.queue_free()
	game.enemies.clear();game.objects.clear()
	for n in range(7):
		var kinds:=[0,1,2,3,4,8,9]
		game.spawn_enemy(140+n*70,kinds[n]);var e=game.enemies.back();e.position.y=310;e.set_physics_process(false)
	game.set_physics_process(false)
	await frames(3);await snap("enemy_lineup_v8")
	game.set_physics_process(true);game.start_game();await frames(30);game.player.invulnerable=9999
	game.start_boss();game.boss.dead=true;game.boss.set_physics_process(false)
	game.stage_cleared()
	await frames(15);await snap("clear_enter_v8")
	await frames(70);await snap("clear_hold_v8")
	game.set_physics_process(false);game.world.process_mode=Node.PROCESS_MODE_DISABLED
	if game.music_fade!=null:game.music_fade.kill()
	game.bgm.stop();game.bgm.stream=null;game.music_tail.stop();game.music_tail.stream=null
	for a in game.audio_pool:a.stop();a.stream=null
	await create_timer(.2,true).timeout
	game.queue_free();await process_frame;game=null;await process_frame;quit()

